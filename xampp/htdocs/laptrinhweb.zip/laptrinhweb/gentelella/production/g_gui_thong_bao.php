<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../production/css/Sass.css">
</head>
<body>
<div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <H4 class="modal-title" aria-labelledby="dnhap">FORM THÔNG BÁO</H4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                  <span aria-hidden="true">&times;</span>
              </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                    <form action="c_thong_bao.php" method="POST">
                        <label for="tentieude">Tiêu đề</label><<input type="text" class="form-control" name="tentieude"><br/>
                        <input type="text" class="form-control" name="link1" >
                     <div class="form-group col-xs-12">
                  <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>  
                 </div>
                    </form>      
                    </div>
                </div>
            </div>
        </div>
     
</body>
</html>