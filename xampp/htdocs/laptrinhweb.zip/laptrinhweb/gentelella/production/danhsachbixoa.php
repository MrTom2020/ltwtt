<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php
    
        $username = "root";
        $severname = "localhost";
        $dtname = "QLCT";
        $ss =$_POST['man'];
        $password = "";
        $conn = mysqli_connect($severname,$username,$password,$dtname);
        echo "<table border=1 cellspacing=0 cellpading=0>
        <tr><td width='70'>id</td>
        <td width='250'>hoten</td>
        <td width='100'>Usename</td>
        <td width='100'>password</td>
        <td width='100'>SDT</td>
        <td width='100'>DIACHI</td>
        </tr>
        </table>";
        $sql2 = "call hienthidanhsachtaikhoanbixoa()";
        $thuchien2 = mysqli_query($conn,$sql2);
        while($row2 = mysqli_fetch_array($thuchien2))
        {
            echo "<table border=1 cellspacing=0 cellpading=0>
            <tr><td width='70'>$row2[0]</td>
            <td width='250'>$row2[1]</td>
            <td width='100'>$row2[2]</td>
            <td width='100'>$row2[3]</td>
            <td width='100'>$row2[5]</td>
            <td width='100'>$row2[6]</td>
            </tr>
            </table>";
        }
       mysqli_close($conn);
 ?>
</head>
<body>
    
</body>
</html>