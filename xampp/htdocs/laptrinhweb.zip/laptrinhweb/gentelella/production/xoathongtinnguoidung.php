<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    $username = "root";
    $severname = "localhost";
    $dtname = "QLCT";
    $password = "";
    $conn = mysqli_connect($severname,$username,$password,$dtname);
    $sql3 = "call hienthitoanboidnguoidung()";
    $thuchien3 = mysqli_query($conn,$sql3);
    echo "<form action='thuchienxoa.php' method='POST'>";
    echo "<select name='man1'>";
    while($row3 = mysqli_fetch_array($thuchien3))
    {
       echo "<option  value='$row3[0]'>$row3[0]</option>";
    }
   echo "</select>";
   echo "<input type='submit'>";
   echo "</form>";
  
   mysqli_close($conn);
?>
</body>
</html>