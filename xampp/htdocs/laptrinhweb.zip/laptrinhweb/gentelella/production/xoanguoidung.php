<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php
    
        $username = "root";
        $severname = "localhost";
        $dtname = "QLCT";
        $ss =isset($_POST['man']) ? $_POST['man']:0;
        $password = "";
        $sql = "";
        $sql2="";
        $conn = mysqli_connect($severname,$username,$password,$dtname);
        $sql = "call hienthitoanboidnguoidung()";
        $thuchien = mysqli_query($conn,$sql);
        echo "<form action='#' method='POST'>";
        echo "<select name='man'>";
        while($row = mysqli_fetch_array($thuchien))
        {
           echo '<option  value="'.$row['id'].'">';
           echo $row['id'];
           echo '</option>';
        }
       echo "</select>";
       echo "<input type='submit'>";
       echo "</form>";
       mysqli_close($conn);
 ?>
</head>
<body>
    
</body>
</html>