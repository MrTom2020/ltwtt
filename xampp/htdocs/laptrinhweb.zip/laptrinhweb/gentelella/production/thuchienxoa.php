<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    $username = "root";
    $severname = "localhost";
    $dtname = "QLCT";
    $password = "";
    $s4 = $_POST['man1'];
    $conn = mysqli_connect($severname,$username,$password,$dtname);
    if($s4 != '' && $s4 != NULL)
    {
        //echo $s4;
         $sql4 = "call xoataikhoan($s4)";
         mysqli_query($conn,$sql4);
      header('location: http://localhost:8080/gentelella/production/tables.php');
      exit();
    }
   mysqli_close($conn);
?>
</body>
</html>