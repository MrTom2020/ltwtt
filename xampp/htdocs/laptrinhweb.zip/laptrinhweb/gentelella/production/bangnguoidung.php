<?php
    $usename ="root";
    $servername = "localhost";
    $password = "";
    $dataname ="QLCT";
    $conn = mysqli_connect($servername,$usename,$password,$dataname);
   $sql = "CALL hienthidanhsachkh()";
   $KETNOI = mysqli_query($conn,$sql);
   echo "<table border=1 cellspacing=0 cellpading=0>
    <tr> <td width='50'>Mã ID</td>
    <td width='200'>Họ tên</td>
    <td width='100'>Tên đăng nhập</td>
    <td width='200'>Mật khẩu</td>
    <td width='200'>Xác nhận mật khẩu</td>
    <td width='100'>Ngày sinh</td>
    <td width='100'>Địa chỉ</td>
    <td width='100'>GIỚI TÍNH</td>
    <td width='100'>Loại</td>
    <td width='100'>SDT</td>
    </tr>
    </table>";
   while($row = mysqli_fetch_array($KETNOI))
   {
    $date = date_create($row[4]); 
    $date2 = date_format($date,'d-m-Y'); 
    echo "<table border=1 cellspacing=0 cellpading=0>
    <tr><td width='50'>$row[0]</td>
    <td width='200'>$row[1]</td>
    <td width='100'>$row[2]</td>
    <td width='200'>$row[3]</td>
    <td width='200'>$row[8]</td>
    <td width='100'>$date2</td>
    <td width='100'>$row[6]</td>
    <td width='100'>$row[7]</td>
    <td width='100'>$row[9]</td>
    <td width='100'>$row[5]</td>
    </tr>
    </table>";
   }
?>