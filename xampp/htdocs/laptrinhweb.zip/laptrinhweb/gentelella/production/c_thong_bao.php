<?php
    session_start();
    $_SESSION['tentd'] = $_POST['tentieude'];
    $_SESSION['THONGBAO'] = $_POST['link1'];
    header('Location: http://localhost:8080/html/trangchu.php');
?>