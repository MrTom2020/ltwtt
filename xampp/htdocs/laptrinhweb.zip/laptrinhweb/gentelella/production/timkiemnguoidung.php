<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php
    
    $tk =isset($_POST["thongtintimkiem"]) ? $_POST["thongtintimkiem"]:0;
    $theo =isset($_POST["timkiemtheo"]) ? $_POST["timkiemtheo"]:0;
         $username = "root";
         $dtname = "QLCT";
        $serverN = "localhost";
         $password = "";
    $conn = mysqli_connect($serverN,$username,$password,$dtname);
        $sql = "";
        $conn = mysqli_connect($serverN,$username,$password,$dtname);
        if($tk != '' && $tk != NULL)
        {
          if($theo === 'theoten')
         {
          $sql = "call timTK('$tk')";
         }
         if($theo === 'theosdt')
         {
           $sql = "call timgandungsdtnguoidung($tk)";
         } 
         if($theo === "theodiachi")
         {
          $sql = "call timdiachigandung('$tk')";
         } 
         echo "<table border=1 cellspacing=0 cellpading=0>
           <tr><td width='70'>id</td>
           <td width='250'>hoten</td>
           <td width='100'>Usename</td>
           <td width='100'>password</td>
           <td width='100'>SDT</td>
           <td width='100'>DIACHI</td>
           </tr>
           </table>";
           $ketnoi10= mysqli_query($conn,$sql);
           while($row1 = mysqli_fetch_array($ketnoi10))
            {
             // $row1 = mysqli_fetch_array($ketnoi10);
               echo "<table border=1 cellspacing=0 cellpading=0>
               <tr><td width='70'>$row1[0]</td>
               <td width='250'>$row1[1]</td>
               <td width='100'>$row1[2]</td>
               <td width='100'>$row1[3]</td>
               <td width='100'>$row1[5]</td>
               <td width='100'>$row1[6]</td>
               </tr>
               </table>";
              
           } 
        }
        else
        {
          echo '';
        }
           mysqli_close($conn);
 ?>
</head>
<body>
    <form action="#" method="POST">
    <div class="container">
        <div class="col-sm-5">
          <label for="timkiemtheo">Tìm kiếm gần đúng theo</label>
          <select name="timkiemtheo" id="timkiemtheo">
              <option value="theoten">Theo tên người dùng</option>
              <option value="theodiachi">Theo tên địa chỉ</option>
              <option value="theosdt">Theo tên số điện thoại</option>
          </select>
        </div>
        <div class="col-sm-5">
          <input type="text" class="form-control" name="thongtintimkiem">
        </div>
       
        <div class="col-sm-5">
          <input type="submit">
        </div>
    </div>
    </form>
</body>
</html>