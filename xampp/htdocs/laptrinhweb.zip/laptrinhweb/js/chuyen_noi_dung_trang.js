function hinh1(s1) {
    document.images['hinh'].src = '../tainguyenkhac/hinh_anh/hinh/h' + 2 + '.png';
}

function hinh2(s1) {
    document.images['hinh'].src = '../tainguyenkhac/hinh_anh/hinh/h' + 3 + '.gif';
}

function hinh0(s1) {
    document.images['hinh'].src = '../tainguyenkhac/hinh_anh/hinh/h' + 1 + '.png';
}