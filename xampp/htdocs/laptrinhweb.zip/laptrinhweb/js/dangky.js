(function()
{
	var bt = document.getElementById('dangky');
	var favDialogy = document.getElementById('hienthifrmdangky');
	bt.addEventListener('click',function(){
		favDialogy.showModal();
	});
})();