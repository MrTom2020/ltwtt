<!doctype html>
 <html lang="vi">
 <head>
    <title>AAAA</title>
    <meta charset="utf-8"/>
 </head>
 <body>
 <?php 
  session_start();
  if($_SESSION["logged"] == true)
  {
      
  }
  ?>
 </body>
 </html>