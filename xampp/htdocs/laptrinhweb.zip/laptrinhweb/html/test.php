 <!doctype html>
 <html lang="vi">
 <head>
    <title>AAAA</title>
    <meta charset="utf-8"/>
 </head>
 <body>
 <form action="#" method="post">
 <input type="text" name="dangnhap"><br/>
 <input type="password" name="matkhau"><br/>
 <input type="submit">
 </form>
 </body>
 </html>