<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 63 85" fill="none" id="icon-taipei-gray">
<path d="M0.198486 73.0762H11.9397V84.8174H0.198486V73.0762Z" fill="#F4F4F4"></path>
<path d="M13.7012 61.335H21.92V84.8174H13.7012V61.335Z" fill="#F4F4F4"></path>
<path d="M23.6809 64.2705H33.661V84.8177H23.6809V64.2705Z" fill="#F4F4F4"></path>
<path d="M35.4221 56.0508H50.6857V84.8168H35.4221V56.0508Z" fill="#F4F4F4"></path>
<path d="M52.4468 70.7275H62.4268V84.817H52.4468V70.7275Z" fill="#F4F4F4"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M37.0462 17.1674H31.45V15.4062H37.0462V17.1674Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M37.5124 14.1665H30.9834V12.4053H37.5124V14.1665Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M37.9788 11.1655H30.5171V9.4043H37.9788V11.1655Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M35.1286 0.280273V8.28377H33.3674V0.280273H35.1286Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.9573 34.623H43.5384L42.1703 41.545L40.4425 41.2035L41.395 36.3842H27.1006L28.0531 41.2035L26.3254 41.545L24.9573 34.623Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.9573 26.4043H43.5384L42.1703 33.3263L40.4425 32.9848L41.395 28.1655H27.1006L28.0531 32.9848L26.3254 33.3263L24.9573 26.4043Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.9573 18.1855H43.5384L42.1703 25.1075L40.4425 24.766L41.395 19.9467H27.1006L28.0531 24.766L26.3254 25.1075L24.9573 18.1855Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.9573 43.4287H43.5384L42.1703 50.3507L40.4425 50.0092L41.395 45.1899H27.1006L28.0531 50.0092L26.3254 50.3507L24.9573 43.4287Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.9573 51.6484H43.5384L42.1703 58.5704L40.4425 58.2289L41.395 53.4096H27.1006L28.0531 58.2289L26.3254 58.5704L24.9573 51.6484Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.9573 60.4541H43.5384L42.1703 67.3761L40.4425 67.0346L41.395 62.2153H27.1006L28.0531 67.0346L26.3254 67.3761L24.9573 60.4541Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M26.4703 68.6729H42.0257L43.9284 84.7133L42.1795 84.9208L40.4611 70.434H28.035L26.3166 84.9208L24.5676 84.7133L26.4703 68.6729Z" fill="#BDBDBD"></path>
</svg>
</body>
</html>