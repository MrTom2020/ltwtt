<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../css/css_cua_trang_chu.css">
</head>
<body>
<article id="btrangchu1">
    <section class="container-fluid">
            <div class="col-sm-3" style="padding-bottom:10%;font-size:20px;"><button>Tin tức</button></div>
            <div class="col-sm-3" style="padding-bottom:10%;font-size:20px;"><button>Khuyến mãi</button></div>
            <div class="col-sm-3" style="padding-bottom:10%font-size:20px;"><button>Liên hệ</button></div>
            <div class="col-sm-3" style="padding-bottom:10%;font-size:20px;"><button>hỏi đáp</button></div>
            <div class="col-sm-3" style="padding-bottom:10%;font-size:20px;"><button>Mẹo vặt</button></div>
            <div class="col-sm-3" style="padding-bottom:10%;font-size:20px;"><button>I Love Amazing</button></div>
        </section>
    </article>
    <script type="text/javascript" src="../js/jquery-1.10.2.min.js">
    </script>
    <script type="text/javascript" src="../js/bootstrap.min.js">
    </script>
</body>
</html>
