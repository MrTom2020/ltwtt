<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 77" fill="none" id="icon-kualaLumpur-gray">
<path fill-rule="evenodd" clip-rule="evenodd" d="M5.28356 44.3535H16.4377V64.6468C17.1189 64.2477 17.8977 64.0201 18.786 64.0201C24.187 64.0201 26.32 67.5425 26.7113 69.3037C27.9833 68.2274 31.2904 66.4858 34.3431 68.1295C37.3959 69.7733 38.3547 74.4894 38.4526 76.6419H16.4377H12.0348H6.45768H5.28356H0V61.9654H5.28356V44.3535ZM69.2733 61.9654H65.751V54.9206H59.2933V71.0175C57.7785 69.7765 55.4707 68.6449 52.8356 69.3037C49.0784 70.243 47.3563 74.5872 46.965 76.6419H59.2933H60.7609H62.8156H65.751H69.2733V61.9654Z" fill="#F4F4F4"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M31.7246 76.6424L31.7246 19.1104L33.4858 19.1104L33.4858 76.6424L31.7246 76.6424Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M28.2026 76.6419V9.7168H29.9638V76.6419H28.2026Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.6802 76.6422V0.911133H26.4414V76.6422H24.6802Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M21.1577 76.6419V9.7168H22.9189V76.6419H21.1577Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.9053 76.6428V25.5684H19.6665V76.6428H17.9053Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M41.9983 76.6415L41.9983 19.1094L43.7595 19.1094L43.7595 76.6415L41.9983 76.6415Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M52.5889 76.6419V9.7168H54.3501V76.6419H52.5889Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M49.0667 76.6422V0.911133H50.8278V76.6422H49.0667Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M45.5442 76.6419V9.7168H47.3054V76.6419H45.5442Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M56.0879 76.6428V25.5684H57.8491V76.6428H56.0879Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M42.7323 46.954H33.2571V45.4863H42.7323V46.954Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M37.7528 45.8565C38.0095 45.8541 38.2488 45.986 38.3838 46.2043L43.7789 54.928L42.5307 55.7L37.773 48.007L33.4185 55.3536L32.156 54.6052L37.1284 46.2161C37.2593 45.9953 37.4961 45.8589 37.7528 45.8565Z" fill="#BDBDBD"></path>
</svg>
</body>
</html>