<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8"/>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 86 85" fill="none" id="icon-jakarta-gray">
<path d="M8.80591 71.1396H17.6118V84.6421H8.80591V71.1396Z" fill="#F4F4F4"></path>
<path d="M0 75.8359H7.04475V84.6419H0V75.8359Z" fill="#F4F4F4"></path>
<path d="M19.373 77.5977H25.8307V84.6424H19.373V77.5977Z" fill="#F4F4F4"></path>
<path d="M27.5918 73.4883H36.3977V84.6425H27.5918V73.4883Z" fill="#F4F4F4"></path>
<path d="M51.6614 73.4883H59.2932V84.6425H51.6614V73.4883Z" fill="#F4F4F4"></path>
<path d="M61.0544 75.8359H66.9251V84.6419H61.0544V75.8359Z" fill="#F4F4F4"></path>
<path d="M68.6863 77.5977H72.7957V84.6424H68.6863V77.5977Z" fill="#F4F4F4"></path>
<path d="M74.5569 81.1201H78.6663V84.6425H74.5569V81.1201Z" fill="#F4F4F4"></path>
<path d="M80.4275 77.5977H85.711V84.6424H80.4275V77.5977Z" fill="#F4F4F4"></path>
<path d="M36.3979 9.49805H52.8357V11.2592H36.3979V9.49805Z" fill="#BDBDBD"></path>
<path d="M34.6367 13.0205H54.5968V14.7817H34.6367V13.0205Z" fill="#BDBDBD"></path>
<path d="M36.9851 16.543H52.2487V18.3042H36.9851V16.543Z" fill="#BDBDBD"></path>
<path d="M28.179 75.8359H61.0544V77.5971H28.179V75.8359Z" fill="#BDBDBD"></path>
<path d="M31.1143 79.3584H58.1191V81.1196H31.1143V79.3584Z" fill="#BDBDBD"></path>
<path d="M34.0498 82.8809H55.184V84.642H34.0498V82.8809Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M37.2795 76.6726L40.2149 17.6729L41.9739 17.7604L39.0386 76.7601L37.2795 76.6726Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M49.0188 17.6726L51.9541 76.3788L50.1951 76.4668L47.2598 17.7606L49.0188 17.6726Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M45.4976 17.7166L45.4976 76.4229H43.7364L43.7364 17.7166H45.4976Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M44.6168 0L48.374 9.76874L46.7302 10.401L44.6168 4.9061L42.5034 10.401L40.8596 9.76874L44.6168 0Z" fill="#BDBDBD"></path>
</svg>
</body>
</html>