<!doctype html>
<html lang="vi">
    <head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
         <link rel="stylesheet" type="text/css" href="../css/css_cua_trang_chu.css">
    </head>
    <body>
    <ul id="menu" class="navbar navbar-default" style="background-color: #028c20; border:0;">
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/trangchu.php">Trang chủ</a></li>
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/trang_gioi_thieu.php">Giới thiệu</a></li>
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/goi_dich_vu.php">Gói dịch vụ</a></li>
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/so_giao_dich.php">Lập kế hoạch</a></li>
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/bao_cao.php">Báo cáo</a></li>
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/lap_ke_hoach.php">Sổ giao dịch</a></li>
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/taikhoan.php">Tài khoản</a></li>
        <li class="list-group-item"><a href="lethanhhiep.com:8080/html/so_giao_dich.php">Quay lại</a></li>
    </ul>    
    </body>
</html>