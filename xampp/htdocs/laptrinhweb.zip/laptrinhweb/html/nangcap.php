<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
</head>
<body>
<svg data-v-0698e127="" data-v-72379cd2="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" viewBox="0 0 24 24" aria-labelledby="test" version="1.1"><defs data-v-0698e127=""></defs> <g data-v-0698e127="" id="Icons/account/ic_account" stroke="none" stroke-width="1" fill="#BDBDBD" fill-rule="evenodd"><rect data-v-0698e127="" id="blue-background" fill-opacity="0" fill="#FFFFFF" x="0" y="0" width="24" height="24"></rect> <path data-v-72379cd2="" d="M2,10.0058587 C2,8.89805351 2.90017617,8 3.99201702,8 L11.007983,8 C12.1081436,8 13,8.89706013 13,10.0058587 L13,19.9941413 C13,21.1019465 12.0998238,22 11.007983,22 L3.99201702,22 C2.8918564,22 2,21.1029399 2,19.9941413 L2,10.0058587 Z M12.5482654,6.05054411 C12.6911723,6.01747057 12.8397304,6 12.992017,6 L20.007983,6 C21.1081436,6 22,6.89706013 22,8.00585866 L22,17.9941413 C22,19.1019465 21.0998238,20 20.007983,20 L15,20 L15,9.00012623 C15,7.52394198 13.9436521,6.30852264 12.5482654,6.05054411 Z M13,2 L20,2 L20,4 L13,4 L13,2 Z M4,4 L11,4 L11,6 L4,6 L4,4 Z" id="Combined-Shape" data-v-0698e127=""></path></g></svg>
</body>
</html>