<div class="modal-dialog" role="document" style="width:60%;">
                           <div class="modal-content">
                                <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Thông báo</h5>
                                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                       <span aria-hidden="true">&times;</span>
                                          </button>
                                   </div>
                          <div class="modal-body">
                     <?php   $ss = isset($_SESSION['baihat']) ? $_SESSION['baihat']:""; echo $ss;?> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Thoát</button>
       
      </div>
    </div>
  </div>