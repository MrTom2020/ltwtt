<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../css/css_cua_trang_chu.css">
</head>
<body>
    <input type="search" name="tim" value=""><<button type="commit">Tìm</button>
    <ul class="list-group col-sm-8" style="padding-left:30vw;">
    <li class="list-group-item"><a href="#">Khoản chi</a></li>
       <li class="list-group-item"><a href="#">Bạn bè & Người yêu</a></li>
       <li class="list-group-item"><a href="#">Bảo hiểm</a></li> 
       <li class="list-group-item"><a href="#">Chi phí</a></li> 
       <li class="list-group-item"><a href="#">Di chuyển</a></li>
       <li class="list-group-item"><a href="#">Bảo dưỡng</a></li> 
       <li class="list-group-item"><a href="#">Gửi xe</a></li> 
       <li class="list-group-item"><a href="#">Taxi</a></li> 
       <li class="list-group-item"><a href="#">Xăng dầu</a></li> 
       <li class="list-group-item"><a href="#">Du lịch</a></li> 
       <li class="list-group-item"><a href="#">Gia đình</a></li>
       <li class="list-group-item"><a href="#">Con cái</a></> 
       <li class="list-group-item"><a href="#">Dịch vụ gia đình</a></li> 
       <li class="list-group-item"><a href="#">Sửa chữa nhà cửa</a></li> 
       <li class="list-group-item"><a href="#">Vật nuôi</a></li> 
       <li class="list-group-item"><a href="#">Gia đình</a></li> 
       <li class="list-group-item"><a href="#">giáo dục</a></li> 
       <li class="list-group-item"><a href="#">Sách</a></li> 
       <li class="list-group-item"><a href="#">giải trí</a></li> 
       <li class="list-group-item"><a href="#">Phim ảnh</a></li> 
       <li class="list-group-item"><a href="#">Trò chơi</a></li> 
       <li class="list-group-item"><a href="#">Hóa đơn & Tiện ích</a></li> 
       <li class="list-group-item"><a href="#">Gas</a></li> 
       <li class="list-group-item"><a href="#">Nước</a></li> 
       <li class="list-group-item"><a href="#">Thuê nhà</a></li> 
       <li class="list-group-item"><a href="#">Tv</a></li> 
       <li class="list-group-item"><a href="#">Điện</a></li> 
       <li class="list-group-item"><a href="#">Điện thoại</a></li> 
       <li class="list-group-item"><a href="#">Kinh doanh</a></li> 
       <li class="list-group-item"><a href="#">giày dép</a></li> 
       <li class="list-group-item"><a href="#">Phụ kiện</a></li> 
       <li class="list-group-item"><a href="#">Quần áo</a></li> 
       <li class="list-group-item"><a href="#">Thiết bị điện tử</a></li> 
       <li class="list-group-item"><a href="#">Qùa tặng & Quyên góp</a></li> 
       <li class="list-group-item"><a href="#">Cưới hỏi</a></li> 
       <li class="list-group-item"><a href="#">Tang lễ</a></li> 
       <li class="list-group-item"><a href="#">Từ thiện</a></li> 
       <li class="list-group-item"><a href="#">Rút tiền</a></li> 
       <li class="list-group-item"><a href="#">Sức khỏe</a></li> 
       <li class="list-group-item"><a href="#">Chăm sóc cá nhân</a></li> 
       <li class="list-group-item"><a href="#">Thuốc</a></li> 
       <li class="list-group-item"><a href="#">Khám chữa bệnh</a></li> 
       <li class="list-group-item"><a href="#">Thể thao</a></li> 
       <li class="list-group-item"><a href="#">Ăn uống</a></li> 
       <li class="list-group-item"><a href="#">Cà phê</a></li> 
       <li class="list-group-item"><a href="#">Nhà hàng</a></li> 
       <li class="list-group-item"><a href="#">Đầu tư</a></li> 
       <li class="list-group-item"><a href="#">Khoản chi khác</a></li> 
       <li class="list-group-item"><a href="#">Khoản thu</a></li> 
       <li class="list-group-item"><a href="#">Bán đồ</a></li> 
       <li class="list-group-item"><a href="#">Lương</a></li> 
       <li class="list-group-item"><a href="#">Thưởng</a></li> 
       <li class="list-group-item"><a href="#">Tiền lãi</a></li> 
       <li class="list-group-item"><a href="#">Được tặng</a></li> 
       <li class="list-group-item"><a href="#">Khoản thu khác</a></li> 
       <li class="list-group-item"><a href="#">Đi vay & Cho vay </a></li> 
       <li class="list-group-item"><a href="#">Thu nợ</a></li> 
       <li class="list-group-item"><a href="#">Đi vay</a></li> 
       <li class="list-group-item"><a href="#">Cho vay</a></li> 
       <li class="list-group-item"><a href="#">Trả nợ</a></li> 
    </ul>
</body>
</html>