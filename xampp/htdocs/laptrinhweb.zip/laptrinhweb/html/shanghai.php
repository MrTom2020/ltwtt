<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8"/>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 58 86" fill="none" id="icon-shanghai-1-gray">
<path d="M0.587524 55.5361H10.5676V84.8892H0.587524V55.5361Z" fill="#F4F4F4"></path>
<path d="M12.3287 43.7949H22.3088V84.8893H12.3287V43.7949Z" fill="#F4F4F4"></path>
<path d="M24.0701 62.5811H34.0501V84.8894H24.0701V62.5811Z" fill="#F4F4F4"></path>
<path d="M35.8113 49.0781H45.7913V84.8889H35.8113V49.0781Z" fill="#F4F4F4"></path>
<path d="M47.5525 61.4072H57.5325V84.8897H47.5525V61.4072Z" fill="#F4F4F4"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M29.0601 22.9545C26.5292 22.9545 24.6572 24.7586 24.6572 26.7704H22.896C22.896 23.5967 25.7573 21.1934 29.0601 21.1934C32.363 21.1934 35.2243 23.5967 35.2243 26.7704H33.4631C33.4631 24.7586 31.5911 22.9545 29.0601 22.9545Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.6572 30.293C24.6572 32.3048 26.5292 34.1089 29.0601 34.1089C31.5911 34.1089 33.4631 32.3048 33.4631 30.293H35.2243C35.2243 33.4668 32.363 35.8701 29.0601 35.8701C25.7573 35.8701 22.896 33.4668 22.896 30.293H24.6572Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M36.1049 28.2377H22.0154V26.4766H36.1049V28.2377Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M36.1049 31.7602H22.0154V29.999H36.1049V31.7602Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M26.4183 22.6603V14.4414H28.1795V22.6603H26.4183Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M29.9407 22.6603V14.4414H31.7019V22.6603H29.9407Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M28.1794 10.3324V0.939453H29.9406V10.3324H28.1794Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M29.0601 11.2133C28.2496 11.2133 27.5925 11.8704 27.5925 12.681C27.5925 13.4916 28.2496 14.1486 29.0601 14.1486C29.8707 14.1486 30.5278 13.4916 30.5278 12.681C30.5278 11.8704 29.8707 11.2133 29.0601 11.2133ZM25.8313 12.681C25.8313 10.8978 27.2769 9.45215 29.0601 9.45215C30.8434 9.45215 32.289 10.8978 32.289 12.681C32.289 14.4642 30.8434 15.9098 29.0601 15.9098C27.2769 15.9098 25.8313 14.4642 25.8313 12.681Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M29.0569 53.4809C24.4929 53.4809 20.9343 56.8403 20.9343 60.8247H19.1731C19.1731 55.7209 23.6737 51.7197 29.0569 51.7197C34.4401 51.7197 38.9406 55.7209 38.9406 60.8247H37.1794C37.1794 56.8403 33.6209 53.4809 29.0569 53.4809Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M20.9406 63.1797C20.9406 67.1641 24.4992 70.5235 29.0632 70.5235C33.6272 70.5235 37.1858 67.1641 37.1858 63.1797H38.947C38.947 68.2835 34.4464 72.2847 29.0632 72.2847C23.68 72.2847 19.1794 68.2835 19.1794 63.1797H20.9406Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M40.2141 61.1762H17.9058V59.415H40.2141V61.1762Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M40.2141 64.5278H17.9058V62.7666H40.2141V64.5278Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M31.7019 53.1875V33.8145H33.4631V53.1875H31.7019Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M28.1794 53.1872V34.4746H29.9406V53.1872H28.1794Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M24.6571 53.1875V33.8145H26.4183V53.1875H24.6571Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M26.4185 85.6277V71.9736H28.1796V85.6277H26.4185Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M29.9408 85.6277V71.9736H31.702V85.6277H29.9408Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M14.464 85.1085L21.7519 69.2578L23.3521 69.9935L16.0641 85.8442L14.464 85.1085Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.9854 85.1105L24.7057 70.3672L26.3082 71.0977L19.5879 85.841L17.9854 85.1105Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M42.3536 85.8527L34.8574 70.002L36.4495 69.249L43.9457 85.0997L42.3536 85.8527Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M38.8302 85.8498L31.9017 71.1065L33.4957 70.3574L40.4242 85.1008L38.8302 85.8498Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M27.4947 80.9721H21.25V79.2109H27.4947V80.9721Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M36.2059 80.9721H29.9661V79.2109H36.2059V80.9721Z" fill="#BDBDBD"></path>
</svg>
</body>
</html>