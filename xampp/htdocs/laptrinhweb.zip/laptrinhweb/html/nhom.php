<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
</head>
<body>
<svg data-v-0698e127="" data-v-5cd9f210="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" viewBox="0 0 24 24" aria-labelledby="ic_category_manager" version="1.1">
<defs data-v-0698e127="">
</defs> <g data-v-0698e127="" id="Icons/account/ic_account" stroke="none" stroke-width="1" fill="#747474" fill-rule="evenodd">
<rect data-v-0698e127="" id="blue-background" fill-opacity="0" fill="#FFFFFF" x="0" y="0" width="24" height="24">
</rect> 
<path data-v-0698e127="" d="M11.5,12.25 L6.75,10 L6.75,5.25 L11.5,7.5 L11.5,12.25 Z M12.5,12.25 L12.5,7.5 L17.25,5.25 L17.25,10 L12.5,12.25 Z M6.75,4 L12,1.5 L17.25,4 L12,6.5 L6.75,4 Z" id="Path-83">
</path> 
<path data-v-0698e127="" d="M17.25,21.75 L12.5,19.5 L12.5,14.75 L17.25,17 L17.25,21.75 Z M18.25,21.75 L18.25,17 L23,14.75 L23,19.5 L18.25,21.75 Z M12.5,13.5 L17.75,11 L23,13.5 L17.75,16 L12.5,13.5 Z" id="Path-84">
</path> 
<path data-v-0698e127="" d="M5.75,21.75 L1,19.5 L1,14.75 L5.75,17 L5.75,21.75 Z M6.75,21.75 L6.75,17 L11.5,14.75 L11.5,19.5 L6.75,21.75 Z M1,13.5 L6.25,11 L11.5,13.5 L6.25,16 L1,13.5 Z" id="Path-85">
</path>
</g>
</svg>
</body>
</html>