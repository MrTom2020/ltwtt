<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
</head>
<body>
        <li class="list-group-item text-center" style="padding-bottom:2%;"><a href="http://lethanhhiep.com:8080/html/vitien.php">Tạo ví tiền</a>
        </li>
        <li class="list-group-item text-center" style="padding-bottom:2%;"><a href="http://lethanhhiep.com:8080/html/danhsachtaikhoandql.php">Danh sách ví được quản lý</a>
        </li>
        <li class="list-group-item text-center" style="padding-bottom:2%;"><a href="http://lethanhhiep.com:8080/html/viquanly.php">Thêm ví tiền quản lý</a>
        </li>
</body>
</html>