<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
</head>
<body>
        <li class="list-group-item text-center" style="padding-bottom:2%;"><a href="../html/vitien.php">Chia theo phần trăm</a>
        </li>
        <li class="list-group-item text-center" style="padding-bottom:2%;"><a href="../html/danhsachtaikhoandql.php">Chia đều</a>
        </li>
        <li class="list-group-item text-center" style="padding-bottom:2%;"><a href="../html/danhsachtaikhoandql.php">Chia theo chênh lệch</a>
        </li>
        <li class="list-group-item text-center" style="padding-bottom:2%;"><a href="../html/viquanly.php">Tùy biến cao cấp</a>
        </li>
</body>
</html>