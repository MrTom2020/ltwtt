<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<svg data-v-0698e127="" data-v-9f7a26d2="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" viewBox="0 0 24 24" aria-labelledby="test" version="1.1">
<defs data-v-0698e127="">
</defs> 
<g data-v-0698e127="" id="Icons/account/ic_account" stroke="none" stroke-width="1" fill="#BDBDBD" fill-rule="evenodd">
<rect data-v-0698e127="" id="blue-background" fill-opacity="0" fill="#FFFFFF" x="0" y="0" width="24" height="24">
</rect> 
<path data-v-9f7a26d2="" d="M8,18 C6.895,18 6.01,18.895 6.01,20 C6.01,21.105 6.895,22 8,22 C9.105,22 10,21.105 10,20 C10,18.895 9.105,18 8,18 L8,18 Z M2,2 L2,4 L4,4 L7.595,11.585 L6.245,14.035 C6.09,14.325 6,14.65 6,15 C6,16.105 6.895,17 8,17 L20,17 L20,15 L8.425,15 C8.285,15 8.175,14.89 8.175,14.75 C8.175,14.705 8.185,14.665 8.205,14.63 L9.1,13 L16.55,13 C17.3,13 17.955,12.585 18.3,11.97 L21.875,5.48 C21.955,5.34 22,5.175 22,5 C22,4.445 21.55,4 21,4 L6.215,4 L5.265,2 L2,2 L2,2 Z M18,18 C16.895,18 16.01,18.895 16.01,20 C16.01,21.105 16.895,22 18,22 C19.105,22 20,21.105 20,20 C20,18.895 19.105,18 18,18 L18,18 Z" data-v-0698e127="">
</path>
</g>
</svg>
</body>
</html>