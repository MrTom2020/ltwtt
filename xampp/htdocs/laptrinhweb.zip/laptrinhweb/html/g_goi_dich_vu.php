<html>
    <head>
        <meta charset="utf-8">
        <title>Amazing</title>
        <script type="text/javascript" async="" src="https://widget.intercom.io/widget/APP_ID">  </script>
    <script data-dapp-detection="">(function(){let e=!1;function n(){if(!e){const n=document.createElement("meta");n.name="dapp-detected",document.head.appendChild(n),e=!0}}if(window.hasOwnProperty("ethereum")){if(window.__disableDappDetectionInsertion=!0,void 0===window.ethereum)return;n()}else{var t=window.ethereum;Object.defineProperty(window,"ethereum",{configurable:!0,set:function(e){window.__disableDappDetectionInsertion||n(),t=e},get:function(){return window.__disableDappDetectionInsertion||n(),t}})}})();</script><link rel="shortcut icon" href="./static/favicon.ico"><link rel="stylesheet" href="//fonts.googleapis.com/icon?family=Material+Icons"><script>window.intercomSettings = {
        app_id: 'fbec7sf6'
      };</script>
      <script>(
        function()
      {var w=window;var ic=w.Intercom;
      if(typeof ic==="function")
      {ic('reattach_activator');ic('update',intercomSettings);}
      else{var d=document;var i=function(){i.c(arguments)};i.q=[];i.c=function(args){i.q.push(args)};w.Intercom=i;function l(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/APP_ID';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);}
      if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})()
      </script>
      <link href="/static/css/app.d314749bb942de86229a157d96cb5914.css?date=1596453085162" rel="stylesheet">
      
      </script>
      <style type="text/css">
#Amazing-app 
{
  font-family: 'Roboto', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style><style type="text/css">
.ml-appbar-top[data-v-4011d843]
 {
  -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,0.24), 0 1px 1px 0 rgba(0,0,0,0.12);
          box-shadow: 0 1px 1px 0 rgba(0,0,0,0.24), 0 1px 1px 0 rgba(0,0,0,0.12);
}
.ml-appbar-account[data-v-4011d843]
 {
  cursor: pointer;
}
.ml-appbar-title a img[data-v-4011d843]
 {
  vertical-align: top;
}
</style><style type="text/css">
.container 
{
  width: 960px;
  margin-left: auto;
  margin-right: auto;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}
@media screen and (min-width: 1200px) 
{
.container {
    width: 1170px;
}
}
.ml-container-view
 {
  padding-top: 48px;
  padding-bottom: 48px;
}
/* content */
.ml-content > .mu-paper,
.ml-content > .mu-paper > div 
{
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
  -ms-flex-wrap: wrap;
      flex-wrap: wrap;
}
.ml-content .ml-content-wrap {
  -webkit-box-flex: 0;
      -ms-flex: 0 0 calc(72.44444444%);
          flex: 0 0 calc(72.44444444%);
}
.ml-content .mu-content-block
 {
  padding: 32px 0;
  margin: 0 auto;
}
</style>
<style type="text/css">
.ml-navbar-title {
  margin-top: 0;
  color: #fff;
  font-weight: 500;
  line-height: 1.5;
}
.mu-item-text.ml-navbar-describe
{
  margin: 0;
  color: #fff;
  line-height: 1.5;
  max-height: inherit !important;
  font-size: 12px;
  word-break: break-word;
}
.ml-navbar-left .mu-list .mu-item 
{
  padding-left: 24px;
  padding-right: 24px;
}
.ml-navbar-left .mu-list .mu-item .mu-item-content 
{
  min-height: 60px;
  -webkit-box-align: start;
      -ms-flex-align: start;
          align-items: flex-start;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
      -ms-flex-direction: column;
          flex-direction: column;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
}
.ml-navbar-left .mu-list > div
 {
  background-size: auto 100%;
  background-position: center;
  background-repeat: no-repeat;
}
.ml-navbar-left .mu-list > div:nth-child(1)
 {
  background-color: #E65100;
  background-image: url(/static/img/navleft-bg-1.7caa7e9.svg);
}
.ml-navbar-left .mu-list > div:nth-child(2) 
{
  background-color: #00B29B;
  background-image: url(/static/img/navleft-bg-2.92a791b.svg);
}
.ml-navbar-left .mu-list > div:nth-child(3) 
{
  background-color: #BE69C2;
  background-image: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTIyN3B4IiBoZWlnaHQ9IjM2MHB4IiB2aWV3Qm94PSIwIDAgMTIyNyAzNjAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgc3R5bGU9ImJhY2tncm91bmQ6ICNCRTY5QzI7Ij4KICAgIDwhLS0gR2VuZXJhdG9yOiBTa2V0Y2ggNDYuMiAoNDQ0OTYpIC0gaHR0cDovL3d3dy5ib2hlbWlhbmNvZGluZy5jb20vc2tldGNoIC0tPgogICAgPHRpdGxlPkltYWdlcy9pbWdfc3RvcmVfcmVjZWlwdGNyZWRpdHM8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iSW1hZ2VzIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iSW1hZ2VzL2ltZ19zdG9yZV9yZWNlaXB0Y3JlZGl0cyI+CiAgICAgICAgICAgIDxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDQzNC4wMDAwMDAsIDAuMDAwMDAwKSI+CiAgICAgICAgICAgICAgICA8cmVjdCBpZD0iUmVjdGFuZ2xlLTgiIGZpbGwtb3BhY2l0eT0iMCIgZmlsbD0iI0ZGRkZGRiIgeD0iMCIgeT0iMCIgd2lkdGg9IjM2MCIgaGVpZ2h0PSIzNjAiPjwvcmVjdD4KICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0zMDgsNDQgQzMwOCwzNy4zNzI1ODMgMzAyLjYyNzQxNywzMiAyOTYsMzIgTDE1NiwzMiBDMTQ5LjM3MjU4MywzMiAxNDQsMzcuMzcyNTgzIDE0NCw0NCBMMTQ0LDIzMiBMMzA4LDIzMiBMMzA4LDQ0IFogTTI4NCwyMzIgTDI5NiwyMzIgTDI4NCwyNDQgTDI4NCwyMzIgWiBNMzA4LDIzMiBMMzA4LDI0NCBMMjk2LDIzMiBMMzA4LDIzMiBaIiBpZD0iQ29tYmluZWQtU2hhcGUtQ29weS0yIiBmaWxsPSIjOUQzOEI4Ij48L3BhdGg+CiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMTYxLDU4IEwyOTIsNTggTDI5Miw3NCBMMTYxLDc0IEwxNjEsNTggWiBNMTYxLDg1IEwyOTIsODUgTDI5MiwxMDEgTDE2MSwxMDEgTDE2MSw4NSBaIE0xNjEsMTEyIEwyOTIsMTEyIEwyOTIsMTI4IEwxNjEsMTI4IEwxNjEsMTEyIFogTTE2MSwxMzkgTDI5MiwxMzkgTDI5MiwxNTUgTDE2MSwxNTUgTDE2MSwxMzkgWiBNMTYxLDE2NiBMMjkyLDE2NiBMMjkyLDE4MiBMMTYxLDE4MiBMMTYxLDE2NiBaIE0xNjEsMTkzIEwyOTIsMTkzIEwyOTIsMjA5IEwxNjEsMjA5IEwxNjEsMTkzIFoiIGlkPSJDb21iaW5lZC1TaGFwZS1Db3B5IiBmaWxsPSIjQUE0QkJGIj48L3BhdGg+CiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMjUxLDczIEMyNTEsNjYuMzcyNTgzIDI0NS42Mjc0MTcsNjEgMjM5LDYxIEw3NSw2MSBMNzUsNzMgTDE1Nyw3MyBMODcsNzMgTDg3LDI2MSBMMjUxLDI2MSBMMjUxLDczIFogTTg3LDI2MSBMOTksMjYxIEw4NywyNzMgTDg3LDI2MSBaIE0xMTEsMjYxIEwxMTEsMjczIEw5OSwyNjEgTDExMSwyNjEgWiBNMTExLDI2MSBMMTIzLDI2MSBMMTExLDI3MyBMMTExLDI2MSBaIE0xMzUsMjYxIEwxMzUsMjczIEwxMjMsMjYxIEwxMzUsMjYxIFogTTEzNSwyNjEgTDE0NywyNjEgTDEzNSwyNzMgTDEzNSwyNjEgWiBNMTU5LDI2MSBMMTU5LDI3MyBMMTQ3LDI2MSBMMTU5LDI2MSBaIiBpZD0iQ29tYmluZWQtU2hhcGUiIGZpbGw9IiNCMDRGQzMiPjwvcGF0aD4KICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik0xMDQsODcgTDIzNSw4NyBMMjM1LDEwMyBMMTA0LDEwMyBMMTA0LDg3IFogTTEwNCwxMTQgTDIzNSwxMTQgTDIzNSwxMzAgTDEwNCwxMzAgTDEwNCwxMTQgWiBNMTA0LDE0MSBMMjM1LDE0MSBMMjM1LDE1NyBMMTA0LDE1NyBMMTA0LDE0MSBaIE0xMDQsMTY4IEwyMzUsMTY4IEwyMzUsMTg0IEwxMDQsMTg0IEwxMDQsMTY4IFogTTEwNCwxOTUgTDIzNSwxOTUgTDIzNSwyMTEgTDEwNCwyMTEgTDEwNCwxOTUgWiBNMTA0LDIyMiBMMjM1LDIyMiBMMjM1LDIzOCBMMTA0LDIzOCBMMTA0LDIyMiBaIiBpZD0iQ29tYmluZWQtU2hhcGUiIGZpbGw9IiNCOTY1Q0IiPjwvcGF0aD4KICAgICAgICAgICAgICAgIDxwYXRoIGQ9Ik02Myw3MyBDNjMsNjYuMzcyNTgzIDY4LjM3MjU4Myw2MSA3NSw2MSBDODEuNjI3NDE3LDYxIDg3LDY2LjM3MjU4MyA4Nyw3MyBMODcsMTM5IEw2MywxMzkgTDYzLDczIFogTTYzLDEzOSBMNzUsMTM5IEw2MywxNTEgTDYzLDEzOSBaIE04NywxMzkgTDg3LDE1MSBMNzUsMTM5IEw4NywxMzkgWiIgaWQ9IkNvbWJpbmVkLVNoYXBlIiBmaWxsPSIjOUQzOEI4Ij48L3BhdGg+CiAgICAgICAgICAgICAgICA8cmVjdCBpZD0iUmVjdGFuZ2xlLTUiIGZpbGw9IiM5RDM4QjgiIHg9IjE1MCIgeT0iMTEzIiB3aWR0aD0iMTI3IiBoZWlnaHQ9IjIxMCIgcng9IjIwIj48L3JlY3Q+CiAgICAgICAgICAgICAgICA8cmVjdCBpZD0iUmVjdGFuZ2xlLTUtQ29weSIgZmlsbD0iI0IwNEVDMyIgeD0iMTU3IiB5PSIxMTkiIHdpZHRoPSIxMjciIGhlaWdodD0iMjEwIiByeD0iMjAiPjwvcmVjdD4KICAgICAgICAgICAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGUtNiIgZmlsbD0iI0NCNzZERCIgb3BhY2l0eT0iMC40NjgzNTM3MTQiIHg9IjE3MSIgeT0iMTM0IiB3aWR0aD0iOTkiIGhlaWdodD0iMTUzIiByeD0iNiI+PC9yZWN0PgogICAgICAgICAgICAgICAgPGNpcmNsZSBpZD0iT3ZhbCIgZmlsbD0iIzlEMzhCOCIgY3g9IjIyMC41IiBjeT0iMTI3LjUiIHI9IjMuNSI+PC9jaXJjbGU+CiAgICAgICAgICAgICAgICA8cmVjdCBpZD0iUmVjdGFuZ2xlLTciIGZpbGw9IiNCOTY1Q0IiIHg9IjIwMSIgeT0iMjk5IiB3aWR0aD0iMzgiIGhlaWdodD0iMTciIHJ4PSI0Ij48L3JlY3Q+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==);
}
.ml-navbar-left .mu-list > div:nth-child(4)
 {
  background-color: #039BE5;
}
.ml-navbar-left .mu-list > div:first-child
 {
  border-top-left-radius: 8px;
}
.ml-navbar-left .mu-list > div:last-child 
{
  border-bottom-left-radius: 8px;
}
.ml-navbar-left .button-border 
{
  border-radius: 8px 0 0 8px;
  border: solid 1px rgba(0,0,0,0.12);
  border-right: none;
  width: 100%;
  text-transform: none;
  font-weight: 500;
  color: rgba(0,0,0,0.54);
  padding: 10px 24px;
  height: auto;
  line-height: 1.5;
  text-align: left;
  margin-top: 0.5em;
  position: relative;
  z-index: 0;
}
.ml-navbar-left .button-border::after {
  content: '';
  width: 1px;
  height: 110%;
  position: absolute;
  top: -5%;
  right: -1px;
  z-index: 1;
  -webkit-box-shadow: 0 0 2px rgba(0,0,0,0.12), 0 2px 2px rgba(0,0,0,0.24);
          box-shadow: 0 0 2px rgba(0,0,0,0.12), 0 2px 2px rgba(0,0,0,0.24);
}
.ml-navbar-left .button-border .mu-flat-button-wrapper {
  -webkit-box-pack: start;
      -ms-flex-pack: start;
          justify-content: flex-start;
}
.button-border-label {
  padding: 0;
  text-align: left;
}
.ml-navbar-footer {
  padding: 0 24px;
  color: rgba(0,0,0,0.54);
  margin-top: 1em;
  font-size: 12px;
}
.ml-navbar-footer p 
{
  margin: 0.5em 0;
}
.ml-navbar-footer a 
{
  color: rgba(0,0,0,0.54);
}
.ml-navbar-footer a:hover
 {
  color: rgba(0,0,0,0.54);
  text-decoration: underline;
}
.mu-list.ml-list-arrow 
{
  padding: 0;
  margin-bottom: 8px;
}
.hide-credit 
{
  display: none !important;
}
</style><style type="text/css">
.v-spinner
{
/*	  font-size: 10px; 

    width: 60px;
    height: 40px;*/
    /*margin: 25px auto;*/
    text-align: center;
}
.v-spinner .v-clip
{
    -webkit-animation: v-clipDelay 0.75s 0s infinite linear;
            animation: v-clipDelay 0.75s 0s infinite linear;
    -webkit-animation-fill-mode: both;
	          animation-fill-mode: both;

    display: inline-block;
}
@-webkit-keyframes v-clipDelay
{
0%
    {
        -webkit-transform: rotate(0deg) scale(1);
                transform: rotate(0deg) scale(1);
}
50%
    {
        -webkit-transform: rotate(180deg) scale(0.8);
                transform: rotate(180deg) scale(0.8);
}
100%
    {
        -webkit-transform: rotate(360deg) scale(1);
                transform: rotate(360deg) scale(1);
}
}
@keyframes v-clipDelay
{
0%
    {
        -webkit-transform: rotate(0deg) scale(1);
                transform: rotate(0deg) scale(1);
}
50%
    {
        -webkit-transform: rotate(180deg) scale(0.8);
                transform: rotate(180deg) scale(0.8);
}
100%
    {
        -webkit-transform: rotate(360deg) scale(1);
                transform: rotate(360deg) scale(1);
}
}
</style><style type="text/css">
.ml-media
 {
  text-align: center;
  margin-bottom: 16px;
}
.ml-media .ml-media-symbol
 {
  height: 70px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
      -ms-flex-align: center;
          align-items: center;
  -webkit-box-pack: center;
      -ms-flex-pack: center;
          justify-content: center;
}
.ml-media .ml-media-title 
{
  margin-bottom: 3px;
}
.ml-media .ml-media-body 
{
  text-align: center;
}
.ml-media .ml-media-body .ml-media-describe
 {
  margin-top: 0;
}
</style><style type="text/css">
.ml-table-price 
{
  width: 100%;
}
.ml-table-price > thead > tr > th
 {
  text-align: center;
  vertical-align: bottom;
  padding: 0 5px 32px 5px;
  font-size: 16px;
}
.ml-table-price tr > td:first-child
 {
  font-weight: 500;
}
.ml-table-price tr > td:not(:first-child)
 {
  text-align: center;
  color: rgba(0,0,0,0.54);
  padding-left: 16px;
  padding-right: 16px;
}
.ml-table-price tr > td 
{
  width: 33.33333333%;
  /* vertical-align: top; */
  padding-top: 8px;
  height: 50px;
}
.ml-table-price tr:not(:last-child) > td:not(:first-child):not(:last-child)
 {
  border-right: solid 1px rgba(0,0,0,0.12);
}
.ml-table-price tbody > tr:last-child > td
{
  padding-top: 24px;
}
.ml-icon-close 
{
  opacity: 0.26;
}
</style>
</head>
<body>
    <div id="Amazing-app">
    </div> 
            <div>
                <div class="ml-container-view">
                    <div class="container">
                <div class="mu-flexbox mu-flex-row" style="align-items: flex-start;">
            <div class="mu-flexbox-item" style="margin-left: 0px; flex: 0 0 calc(25% + 6px); order: 0;">
            </div> 
            <div class="mu-flexbox-item" style="margin-left: 0px; flex: 0 0 calc(75% - 6px); order: 0;">
            <main class="ml-content">
            <div class="mu-paper mu-paper-round mu-paper-1">
            <div>
            <div class="ml-content-wrap">
            <div><!----> 
            <div class="mu-content-block">
            <h2 class="ml-title">Bắt đầu quản lý tài chính cá nhân hiệu quả và tiện lợi hơn với Amazing gói cao cấp</h2>
             <div type="premium_one_time">
             <table class="ml-table ml-table-price">
             <thead>
             <tr>
             <th>&nbsp;</th> 
             <th class="ml-subhead-secondary"><!---->
             <br>
          Amazing Miễn phí
          <br> <span class="ml-text-caption">&nbsp;</span>
        </th> 
        <th class="ml-subhead-secondary">
            <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjRweCIgaGVpZ2h0PSIyNHB4IiB2aWV3Qm94PSIwIDAgMjQgMjQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5Hcm91cDwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPgogICAgICAgIDxsaW5lYXJHcmFkaWVudCB4MT0iNTAlIiB5MT0iMCUiIHgyPSI1MCUiIHkyPSIxMDAlIiBpZD0ibGluZWFyR3JhZGllbnQtMSI+CiAgICAgICAgICAgIDxzdG9wIHN0b3AtY29sb3I9IiNGREMwMDAiIG9mZnNldD0iMCUiPjwvc3RvcD4KICAgICAgICAgICAgPHN0b3Agc3RvcC1jb2xvcj0iI0ZCOEMwMCIgb2Zmc2V0PSIxMDAlIj48L3N0b3A+CiAgICAgICAgPC9saW5lYXJHcmFkaWVudD4KICAgIDwvZGVmcz4KICAgIDxnIGlkPSJTeW1ib2xzIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0iSWNvbnMvY3Jvd25fc21hbGwvaWNfY3Jvd25fZnVsbF9zbWFsbCI+CiAgICAgICAgICAgIDxnIGlkPSJHcm91cCI+CiAgICAgICAgICAgICAgICA8cG9seWdvbiBpZD0iQ29tYmluZWQtU2hhcGUiIGZpbGw9InVybCgjbGluZWFyR3JhZGllbnQtMSkiIHBvaW50cz0iMTUuMTU0Mzg2NyAyLjI5MTc5NjA3IDEyIDAgOC44NDU2MTMzMyAyLjI5MTc5NjA3IDQuOTQ2NTc2OTcgMi4yOTE3OTYwNyAzLjc0MTcwODQ4IDYgMC41ODczMjE4MDQgOC4yOTE3OTYwNyAxLjc5MjE5MDMgMTIgMC41ODczMjE4MDQgMTUuNzA4MjAzOSAzLjc0MTcwODQ4IDE4IDQuOTQ2NTc2OTcgMjEuNzA4MjAzOSA4Ljg0NTYxMzMzIDIxLjcwODIwMzkgMTIgMjQgMTUuMTU0Mzg2NyAyMS43MDgyMDM5IDE5LjA1MzQyMyAyMS43MDgyMDM5IDIwLjI1ODI5MTUgMTggMjMuNDEyNjc4MiAxNS43MDgyMDM5IDIyLjIwNzgwOTcgMTIgMjMuNDEyNjc4MiA4LjI5MTc5NjA3IDIwLjI1ODI5MTUgNiAxOS4wNTM0MjMgMi4yOTE3OTYwNyI+PC9wb2x5Z29uPgogICAgICAgICAgICAgICAgPHBhdGggZD0iTTksMTguNSBMNi41LDEyLjUgTDguNSwxMS41IEM4LjUsMTEuNSA5LDEyLjUgOS41LDEyLjUgQzEwLjUsMTIuNSAxMSwxMCAxMSwxMCBMMTMsMTAgQzEzLDEwIDEzLjUsMTIuNSAxNC41LDEyLjUgQzE1LDEyLjUgMTUuNSwxMS41IDE1LjUsMTEuNSBMMTcuNSwxMi41IEwxNSwxOC41IEw5LDE4LjUgWiBNMTIsOSBDMTEuMTcxNTcyOSw5IDEwLjUsOC4zMjg0MjcxMiAxMC41LDcuNSBDMTAuNSw2LjY3MTU3Mjg4IDExLjE3MTU3MjksNiAxMiw2IEMxMi44Mjg0MjcxLDYgMTMuNSw2LjY3MTU3Mjg4IDEzLjUsNy41IEMxMy41LDguMzI4NDI3MTIgMTIuODI4NDI3MSw5IDEyLDkgWiBNNi41LDExLjUgQzUuNjcxNTcyODgsMTEuNSA1LDEwLjgyODQyNzEgNSwxMCBDNSw5LjE3MTU3Mjg4IDUuNjcxNTcyODgsOC41IDYuNSw4LjUgQzcuMzI4NDI3MTIsOC41IDgsOS4xNzE1NzI4OCA4LDEwIEM4LDEwLjgyODQyNzEgNy4zMjg0MjcxMiwxMS41IDYuNSwxMS41IFogTTE3LjUsMTEuNSBDMTYuNjcxNTcyOSwxMS41IDE2LDEwLjgyODQyNzEgMTYsMTAgQzE2LDkuMTcxNTcyODggMTYuNjcxNTcyOSw4LjUgMTcuNSw4LjUgQzE4LjMyODQyNzEsOC41IDE5LDkuMTcxNTcyODggMTksMTAgQzE5LDEwLjgyODQyNzEgMTguMzI4NDI3MSwxMS41IDE3LjUsMTEuNSBaIiBpZD0iUGF0aC0yODQiIGZpbGw9IiNGRkZGRkYiPjwvcGF0aD4KICAgICAgICAgICAgPC9nPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+" alt="premium" height="24">
            <br>
          Amazing gói cao cấp
          <br> <span class="ml-text-caption">&nbsp;</span>
        </th>
        </tr>
        </thead> 
        <tbody>
        <tr>
        <td>Số lượng ví tiền mặt</td> 
        <td>
            <span>1</span>
            </td> 
            <td><span>Vô hạn <!----></span>
        </td>
    </tr>
    <tr>
        <td>Số lượng ngân sách, tiết kiệm, sự kiện, định kỳ và hóa đơn</td>
         <td><span>1</span></td> 
         <td><span>Vô hạn <!----></span></td>
        </tr><tr><td>Sync</td> 
        <td><span>Lên đến 5 tài khoản</span></td>
         <td><span>Vô hạn <!----></span></td>
        </tr><tr><td>Truy cập vào ứng dụng web</td>
         <td>
         <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMThweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTggMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5pY29uIGRvbmU8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NoZWNrL2ljX2NoZWNrX2dyZWVuIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC02LjAwMDAwMCkiIGZpbGw9IiMyQkFGMkIiPgogICAgICAgICAgICA8cG9seWdvbiBpZD0iaWNvbi1kb25lIiBwb2ludHM9IjguNTU5MjMwNzcgMTkuMTIzODQyMSAzIDEzLjYzMDMxNTggNC40NjkwNzY5MiAxMi4xNzkxMDUzIDguNjAyMTUzODUgMTYuMjY0NTI2MyAxOS42MzgyMzA4IDYgMjEuMDYxNjE1NCA3LjQ5NSI+PC9wb2x5Z29uPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+" alt="active">
        </td>
         <td>
         <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMThweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTggMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5pY29uIGRvbmU8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NoZWNrL2ljX2NoZWNrX2dyZWVuIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC02LjAwMDAwMCkiIGZpbGw9IiMyQkFGMkIiPgogICAgICAgICAgICA8cG9seWdvbiBpZD0iaWNvbi1kb25lIiBwb2ludHM9IjguNTU5MjMwNzcgMTkuMTIzODQyMSAzIDEzLjYzMDMxNTggNC40NjkwNzY5MiAxMi4xNzkxMDUzIDguNjAyMTUzODUgMTYuMjY0NTI2MyAxOS42MzgyMzA4IDYgMjEuMDYxNjE1NCA3LjQ5NSI+PC9wb2x5Z29uPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+" alt="active">
        </td>
    </tr>
    <tr>
        <td>Xuất CSV</td>
         <td>
         <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTRweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTQgMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5TaGFwZTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJTeW1ib2xzIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIiBvcGFjaXR5PSIwLjUzOTk5OTk2MiI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NhbmNlbC9pY19jYW5jZWwiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01LjAwMDAwMCwgLTUuMDAwMDAwKSIgZmlsbD0iIzAwMDAwMCI+CiAgICAgICAgICAgIDxwb2x5Z29uIGlkPSJTaGFwZSIgcG9pbnRzPSIxOSA2LjQxNSAxNy41ODUgNSAxMiAxMC41ODUgNi40MTUgNSA1IDYuNDE1IDEwLjU4NSAxMiA1IDE3LjU4NSA2LjQxNSAxOSAxMiAxMy40MTUgMTcuNTg1IDE5IDE5IDE3LjU4NSAxMy40MTUgMTIiPjwvcG9seWdvbj4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==" alt="not-active" class="ml-icon-close">
         </td> 
         <td>
         <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMThweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTggMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5pY29uIGRvbmU8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NoZWNrL2ljX2NoZWNrX2dyZWVuIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC02LjAwMDAwMCkiIGZpbGw9IiMyQkFGMkIiPgogICAgICAgICAgICA8cG9seWdvbiBpZD0iaWNvbi1kb25lIiBwb2ludHM9IjguNTU5MjMwNzcgMTkuMTIzODQyMSAzIDEzLjYzMDMxNTggNC40NjkwNzY5MiAxMi4xNzkxMDUzIDguNjAyMTUzODUgMTYuMjY0NTI2MyAxOS42MzgyMzA4IDYgMjEuMDYxNjE1NCA3LjQ5NSI+PC9wb2x5Z29uPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+" alt="active">
         </td>
        </tr>
        <tr>
             <td>Đính kèm hình ảnh vào giao dịch</td>
          <td>
          <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTRweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTQgMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5TaGFwZTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJTeW1ib2xzIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIiBvcGFjaXR5PSIwLjUzOTk5OTk2MiI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NhbmNlbC9pY19jYW5jZWwiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01LjAwMDAwMCwgLTUuMDAwMDAwKSIgZmlsbD0iIzAwMDAwMCI+CiAgICAgICAgICAgIDxwb2x5Z29uIGlkPSJTaGFwZSIgcG9pbnRzPSIxOSA2LjQxNSAxNy41ODUgNSAxMiAxMC41ODUgNi40MTUgNSA1IDYuNDE1IDEwLjU4NSAxMiA1IDE3LjU4NSA2LjQxNSAxOSAxMiAxMy40MTUgMTcuNTg1IDE5IDE5IDE3LjU4NSAxMy40MTUgMTIiPjwvcG9seWdvbj4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==" alt="not-active" class="ml-icon-close">
          </td>
          <td>
          <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMThweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTggMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5pY29uIGRvbmU8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NoZWNrL2ljX2NoZWNrX2dyZWVuIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC02LjAwMDAwMCkiIGZpbGw9IiMyQkFGMkIiPgogICAgICAgICAgICA8cG9seWdvbiBpZD0iaWNvbi1kb25lIiBwb2ludHM9IjguNTU5MjMwNzcgMTkuMTIzODQyMSAzIDEzLjYzMDMxNTggNC40NjkwNzY5MiAxMi4xNzkxMDUzIDguNjAyMTUzODUgMTYuMjY0NTI2MyAxOS42MzgyMzA4IDYgMjEuMDYxNjE1NCA3LjQ5NSI+PC9wb2x5Z29uPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+" alt="active">
          </td>
          </tr>
          <tr>
          <td>Không có quảng cáo!</td>
           <td>
           <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTRweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTQgMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5TaGFwZTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJTeW1ib2xzIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIiBvcGFjaXR5PSIwLjUzOTk5OTk2MiI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NhbmNlbC9pY19jYW5jZWwiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC01LjAwMDAwMCwgLTUuMDAwMDAwKSIgZmlsbD0iIzAwMDAwMCI+CiAgICAgICAgICAgIDxwb2x5Z29uIGlkPSJTaGFwZSIgcG9pbnRzPSIxOSA2LjQxNSAxNy41ODUgNSAxMiAxMC41ODUgNi40MTUgNSA1IDYuNDE1IDEwLjU4NSAxMiA1IDE3LjU4NSA2LjQxNSAxOSAxMiAxMy40MTUgMTcuNTg1IDE5IDE5IDE3LjU4NSAxMy40MTUgMTIiPjwvcG9seWdvbj4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg==" alt="not-active" class="ml-icon-close">
           </td> 
           <td>
           <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMThweCIgaGVpZ2h0PSIxNHB4IiB2aWV3Qm94PSIwIDAgMTggMTQiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQ2LjIgKDQ0NDk2KSAtIGh0dHA6Ly93d3cuYm9oZW1pYW5jb2RpbmcuY29tL3NrZXRjaCAtLT4KICAgIDx0aXRsZT5pY29uIGRvbmU8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0iU3ltYm9scyIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+CiAgICAgICAgPGcgaWQ9Ikljb25zL2NoZWNrL2ljX2NoZWNrX2dyZWVuIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMy4wMDAwMDAsIC02LjAwMDAwMCkiIGZpbGw9IiMyQkFGMkIiPgogICAgICAgICAgICA8cG9seWdvbiBpZD0iaWNvbi1kb25lIiBwb2ludHM9IjguNTU5MjMwNzcgMTkuMTIzODQyMSAzIDEzLjYzMDMxNTggNC40NjkwNzY5MiAxMi4xNzkxMDUzIDguNjAyMTUzODUgMTYuMjY0NTI2MyAxOS42MzgyMzA4IDYgMjEuMDYxNjE1NCA3LjQ5NSI+PC9wb2x5Z29uPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+" alt="active">
           </td>
           </tr>
           </tbody> 
           <!---->
           </table>
           </div>
           </div>
           </div>
            <div class="mu-content-block">
               <h2 class="ml-title">Cách Amazing gói cao cấp cải thiện quản lý tài chính của bạn</h2> 
          <div class="mu-flexbox mu-flex-row" style="justify-content: space-between; align-items: flex-start; flex-wrap: wrap;">
          <div class="mu-flexbox-item col-md-3 col-sm-6" style="margin-left: 8px; flex: 0 1 calc(50% - 12px); order: 0;">
          <div class="ml-media"><div class="ml-media-symbol"><img src="../tainguyenkhac/hinh_anh/hinh/h1.svg" alt="Unlimited items" height="40">
        </div>
         <div class="ml-media-body">     
             <h4 class="ml-media-title ml-title-small">Không giới hạn mặt hàng</h4> 
             <p class="ml-media-describe ml-text-caption">Nhiều khi bạn sẽ thấy mình cần nhiều ví hơn: một chiếc để đựng tiền mặt, một chiếc cho gia đình và một chiếc cho một chuyến phiêu lưu kỳ thú trong tương lai! Đi gói cao cấp sẽ cung cấp cho bạn khả năng tạo ví, ngân sách, khoản tiết kiệm, giao dịch và hóa đơn định kỳ, tùy theo nhu cầu của bạn.</p>
            </div>
             </div>
            </div>
             <div class="mu-flexbox-item col-md-4 col-sm-3" style="margin-left: 8px; flex: 0 1 calc(50% - 12px); order: 0;">
             <div class="ml-media">
                 <div class="ml-media-symbol">
                 <img src="../tainguyenkhac/hinh_anh/hinh/h2.svg" alt="Unlock all features" height="40">
                </div>
                  <div class="ml-media-body">
                      <h4 class="ml-media-title ml-title-small">Mở khóa tất cả các tính năng</h4> 
                      <p class="ml-media-describe ml-text-caption">Amazing gói cao cấp đi kèm với một số công cụ để bạn sử dụng, chẳng hạn như: truy cập vào Amazing từ PC thông qua trình duyệt web bất cứ khi nào bạn muốn hoặc xuất dữ liệu của bạn sang CSV để dễ dàng nhập vào báo cáo của bạn.</p>
                    </div> 
                </div>
            </div>
                      <div class="mu-flexbox-item col-md-4 col-sm-3" style="margin-left: 8px; flex: 0 1 calc(50% - 12px); order: 0;">
                      <div class="ml-media">
                          <div class="ml-media-symbol"><img src="../tainguyenkhac/hinh_anh/hinh/h3.svg" alt="Work on multiple devices" height="40">
                        </div> 
                          <div class="ml-media-body">
                              <h4 class="ml-media-title ml-title-small">Làm việc trên nhiều thiết bị</h4> 
                              <p class="ml-media-describe ml-text-caption">Bạn có thể có nhiều thiết bị và khả năng truy cập dữ liệu của bạn từ bất kỳ thiết bị nào bạn sử dụng, bất kỳ lúc nào bạn muốn, chỉ cách bạn một đầu ngón tay Amazing gói cao cấp.</p>
                            </div>
                         </div>
                        </div>
                              <div class="mu-flexbox-item col-md-6 col-sm-6" style="margin-left: -60%;margin-top: 60%; padding-bottom: 30%; flex: 0 1 calc(50% - 12px); order: 0;">
                              <div class="ml-media"><div class="ml-media-symbol">
                              <img src="../tainguyenkhac/hinh_anh/hinh/h4.svg" alt="Remove ads" height="40">
                              </div> 
                              <div class="ml-media-body">
                              <h4 class="ml-media-title ml-title-small">Loại bỏ các quảng cáo</h4>
                               <p class="ml-media-describe ml-text-caption">Quảng cáo thật khó chịu ?  gói cao cấp sẽ xóa hoàn toàn quảng cáo khỏi ứng dụng và bằng cách làm này, bạn sẽ cho chúng tôi thêm một ít cà phê để tiếp tục mang đến nhiều tính năng thú vị hơn cho Amazing.</p>
                            </div> 
                        </div>
                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</div> 

<div class="container">

</div>
                        </div>
                    </div>
                </div>
              
<iframe id="intercom-frame" style="position: absolute !important; opacity: 0 !important; width: 1px !important; height: 1px !important; top: 0 !important; left: 0 !important; border: none !important; display: block !important; z-index: -1 !important; pointer-events: none;" aria-hidden="true" tabindex="-1" title="Intercom">
</iframe>
<div class="intercom-lightweight-app" aria-live="polite">
<style id="intercom-lightweight-app-style" type="text/css">
  @keyframes intercom-lightweight-app-launcher
   {
    from
     {
      opacity: 0;
      transform: scale(0.5);
    }
    to 
    {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes intercom-lightweight-app-gradient
   {
    from 
    {
      opacity: 0;
    }
    to 
    {
      opacity: 1;
    }
  }

  @keyframes intercom-lightweight-app-messenger 
  {
    from 
    {
      opacity: 0;
      transform: translateY(20px);
    }
    to 
    {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .intercom-lightweight-app
   {
    position: fixed;
    z-index: 2147483001;
    width: 0;
    height: 0;
    font-family: intercom-font, "Helvetica Neue", "Apple Color Emoji", Helvetica, Arial, sans-serif;
  }

  .intercom-lightweight-app-gradient 
  {
    position: fixed;
    z-index: 2147483002;
    width: 500px;
    height: 500px;
    bottom: 0;
    right: 0;
    pointer-events: none;
    background: radial-gradient(
      ellipse at bottom right,
      rgba(29, 39, 54, 0.16) 0%,
      rgba(29, 39, 54, 0) 72%);
    animation: intercom-lightweight-app-gradient 200ms ease-out;
  }

  .intercom-lightweight-app-launcher
   {
    position: fixed;
    z-index: 2147483003;
    bottom: 20px;
    right: 20px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: undefined;
    cursor: pointer;
    box-shadow: 0 1px 6px 0 rgba(0, 0, 0, 0.06), 0 2px 32px 0 rgba(0, 0, 0, 0.16);
    animation: intercom-lightweight-app-launcher 250ms ease;
  }

  .intercom-lightweight-app-launcher:focus 
  {
    outline: none;
    
  }

  .intercom-lightweight-app-launcher-icon
  {
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    top: 0;
    left: 0;
    width: 60px;
    height: 60px;
    transition: transform 100ms linear, opacity 80ms linear;
  }

  .intercom-lightweight-app-launcher-icon-open 
  {
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-open svg
   {
    width: 28px;
    height: 32px;
  }

  .intercom-lightweight-app-launcher-icon-open svg path
   {
    fill: undefined;
  }

  .intercom-lightweight-app-launcher-icon-self-serve
   {
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg 
  {
    height: 56px;
  }

  .intercom-lightweight-app-launcher-icon-self-serve svg path
   {
    fill: undefined;
  }

  .intercom-lightweight-app-launcher-custom-icon-open
   {
    max-height: 36px;
    max-width: 36px;
    
        opacity: 1;
        transform: rotate(0deg) scale(1);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize 
  {
    
        opacity: 0;
        transform: rotate(-60deg) scale(0);
      
  }

  .intercom-lightweight-app-launcher-icon-minimize svg 
  {
    width: 16px;
  }

  .intercom-lightweight-app-launcher-icon-minimize svg path
   {
    fill: undefined;
  }

  .intercom-lightweight-app-messenger
   {
    position: fixed;
    z-index: 2147483003;
    overflow: hidden;
    background-color: white;
    animation: intercom-lightweight-app-messenger 250ms ease-out;
    
        width: 376px;
        height: calc(100% - 40px);
        max-height: 704px;
        min-height: 250px;
        right: 20px;
        bottom: 20px;
        box-shadow: 0 5px 40px rgba(0,0,0,0.16);
        border-radius: 8px;    
  }

  .intercom-lightweight-app-messenger-header
   {
    height: 75px;
    background: linear-gradient(
      135deg,
      undefined 0%,
      undefined 100%
    );
  }

  @media print
   {
    .intercom-lightweight-app
     {
      display: none;
    }
  }
</style>
</div>

</body>
</html>