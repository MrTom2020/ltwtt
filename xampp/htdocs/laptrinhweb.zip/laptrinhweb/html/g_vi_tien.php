<!doctype html>
<html lang="vi">
    <head>
        <meta charset="utf-8"/>
    </head>
    <body>
    <ul id="menu" class="list-group">
        <li class="list-group-item"><a href="https://moneylover.vn/">Trang chủ</a></li>
        <li class="list-group-item"><a href="trang_gioi_thieu.php">Giới thiệu</a></li>
        <li class="list-group-item"><a href="goi_dich_vu.php">Gói dịch vụ</a></li>
        <li class="list-group-item"><a href="so_giao_dich.php">Sổ giao dịch</a></li>
        <li class="list-group-item"><a href="bao_cao.php">Báo cáo</a></li>
        <li class="list-group-item"><a href="lap_ke_hoach.php">Lập kế hoạch</a></li>
        <li class="list-group-item"><a href="taikhoan.php">Tài khoản</a></li>
    </ul>    
    </script>
    </body>
</html>