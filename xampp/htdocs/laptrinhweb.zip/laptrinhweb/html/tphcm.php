<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8"/>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 127 54" fill="none" id="icon-HoChiMinhCity-gray">
<path d="M80.8688 53.0837H125.105C125.105 53.0837 130.119 41.9106 121.914 42.7422C113.709 43.5738 114.165 47.8916 114.165 47.8916C114.165 47.8916 121.002 32.5712 112.798 30.7268C104.593 28.8824 103.755 34.8528 103.755 34.8528C103.755 34.8528 111.43 11.7496 99.5787 9.08422C87.7273 6.41888 89.0842 27.1552 89.0842 27.1552C89.0842 27.1552 87.2609 20.8224 80.8794 23.4877C74.4979 26.1531 71.7417 39.661 80.8688 53.0837Z" fill="#F4F4F4"></path>
<path d="M12.2726 53.3171H45.1553C45.1553 53.3171 50.8869 46.5015 45.1553 43.8291C39.4236 41.1566 38.2715 45.8286 38.2715 45.8286C38.2715 45.8286 43.6287 36.5808 36.745 35.9944C29.8612 35.408 29.986 41.1566 29.986 41.1566C29.986 41.1566 34.0664 24.6895 24.504 25.074C14.9416 25.4585 17.2362 35.6964 18.3883 39.1956C18.3883 39.1956 15.7097 33.1394 9.20995 35.9944C2.71023 38.8591 6.15691 48.6356 12.2726 53.3171Z" fill="#F4F4F4"></path>
<path d="M0 52.1221H114.825" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M43.2898 27.2334H71.5353" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M71.5354 29.9736H82.1155" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M82.1155 35.4434H114.825" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M46.2469 13.4297H68.588" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M43.2898 8.35449H71.5353" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M67.0806 8.35449V52.4976" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M71.5354 25.5127V52.4965" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M82.1155 28.4453V52.4972" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M84.3716 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M92.4939 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M95.3838 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M103.151 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M106.041 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M113.462 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M43.2898 25.5127V52.4965" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M47.7542 8.35449V52.4976" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M50.6249 52.1215V39.3554C50.6249 35.6832 53.6011 32.7031 57.2686 32.7031C60.9361 32.7031 63.9124 35.6832 63.9124 39.3554V52.1215" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M57.4125 24.3305C59.6289 24.3305 61.4257 22.5314 61.4257 20.3122C61.4257 18.093 59.6289 16.2939 57.4125 16.2939C55.1962 16.2939 53.3994 18.093 53.3994 20.3122C53.3994 22.5314 55.1962 24.3305 57.4125 24.3305Z" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M57.4126 17.8516V20.3125H58.9199" stroke="#BDBDBD" stroke-miterlimit="10"></path>
<path d="M44.9604 8.35413L57.9983 4.39355L69.9993 8.35413" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M57.931 0V4.39316" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M59.256 2.30664H56.5966" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M113.462 42.4707V41.8939C113.462 39.9328 111.878 38.3467 109.919 38.3467C107.961 38.3467 106.377 39.9328 106.377 41.8939H102.901C102.901 39.9328 101.317 38.3467 99.3584 38.3467C97.3999 38.3467 95.8157 39.9328 95.8157 41.8939H92.3403C92.3403 39.9328 90.7561 38.3467 88.7976 38.3467C86.839 38.3467 85.2549 39.9328 85.2549 41.8939H82.1346" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M43.2899 29.9736H32.7098" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M32.7099 35.4434H0" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M32.7098 28.4453V52.4972" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M30.4536 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M22.3409 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M19.4415 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M11.6841 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M8.78467 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M1.36328 43.5186V52.4971" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
<path d="M1.36328 42.4707V41.8939C1.36328 39.9328 2.94741 38.3467 4.90597 38.3467C6.86453 38.3467 8.44866 39.9328 8.44866 41.8939H11.9241C11.9241 39.9328 13.5083 38.3467 15.4668 38.3467C17.4254 38.3467 19.0095 39.9328 19.0095 41.8939H22.485C22.485 39.9328 24.0691 38.3467 26.0277 38.3467C27.9862 38.3467 29.5704 39.9328 29.5704 41.8939H32.6906" stroke="#BDBDBD" stroke-width="1.7" stroke-miterlimit="10"></path>
</svg>
</body>
</html>