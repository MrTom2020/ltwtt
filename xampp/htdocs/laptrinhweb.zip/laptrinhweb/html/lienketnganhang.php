<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
</head>
<body>
<svg data-v-0698e127="" data-v-5cd9f210="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" viewBox="0 0 24 24" aria-labelledby="ic_link" version="1.1"><defs data-v-0698e127=""></defs> <g data-v-0698e127="" id="Icons/account/ic_account" stroke="none" stroke-width="1" fill="#747474" fill-rule="evenodd">
<rect data-v-0698e127="" id="blue-background" fill-opacity="0" fill="#FFFFFF" x="0" y="0" width="24" height="24">
</rect> <!----> <!----> <!---->
 <path data-v-5cd9f210="" d="M3.9,12 C3.9,10.29 5.29,8.9 7,8.9 L11,8.9 L11,7 L7,7 C4.24,7 2,9.24 2,12 C2,14.76 4.24,17 7,17 L11,17 L11,15.1 L7,15.1 C5.29,15.1 3.9,13.71 3.9,12 Z M8,13 L16,13 L16,11 L8,11 L8,13 Z M17,7 L13,7 L13,8.9 L17,8.9 C18.71,8.9 20.1,10.29 20.1,12 C20.1,13.71 18.71,15.1 17,15.1 L13,15.1 L13,17 L17,17 C19.76,17 22,14.76 22,12 C22,9.24 19.76,7 17,7 Z" id="Shape" fill-rule="nonzero" data-v-0698e127="">
 </path>
 </g>
 </svg>
 </body>
 </html>