<!DOCTYPE html>
<html lang="vn">

<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="../css/amazing.css">
</head>
<body>
<div class="footer">
        <div class="social">
            
            <span>Về chúng tôi</span>
            
            <a href="../html/ve_chung_toi.php" target="_blank" class="share-button yt-button">
                <img src="../tainguyenkhac/hinh_anh/hinh/icon_yt.gif" width="23" height="23" alt="Youtube">
            </a>
            
            
            
            <a href="https://www.facebook.com/tomhum.chin" target="_blank" class="share-button linkedin-button">
                <img src="../tainguyenkhac/hinh_anh/hinh/icon_linkedin.gif" width="23" height="23" alt="LinkedIn">
            </a>
            
            <a href="https://www.facebook.com/tomhum.chin" target="_blank" class="share-button fb-button">
                <img src="../tainguyenkhac/hinh_anh/hinh/icon_fb.gif" width="23" height="23" alt="Facebook">
            </a>
            
            
        </div>
        <ul class="footnav hide-desktop">
            
            <li class="locations menu-top"><a href="#" target="_self">Mạng lưới &amp; AMAZING</a></li>
            <li class="hide-mobile menu-top"><a href="#">Điều khoản sử dụng</a></li>
            <li class="contact menu-top"><a href="../html/chinh_sach_bao_mat.php">Chính sách bảo mật</a></li>

        </ul>
        <div class="footnav hide-mobile">
            
        <a href="#" target="_self">Sơ đồ trang</a>
        <a href="#" target="_self">Liên hệ</a>

        </div>
        <div class="clear"></div>
        <div class="copyright">Bản quyền © 2020 thuộc về AMAZING. Nơi của những giấc mơ màu xanh lá.</div>
        
        <div class="clear"></div>
    </div>
</body>
</html>