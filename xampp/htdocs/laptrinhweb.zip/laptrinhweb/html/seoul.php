<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8"/>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 89 49" fill="none" id="icon-seoul-gray">
<path d="M0 35.5615H88.0593V48.4769H0V35.5615Z" fill="#F4F4F4"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M6.16431 48.4761V42.6055H7.92549V48.4761H6.16431Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M10.2738 48.4773V37.9102H12.035V48.4773H10.2738Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M14.3832 48.477V34.9746H16.1444V48.477H14.3832Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M18.4926 48.4768V32.0391H20.2537V48.4768H18.4926Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M22.6021 48.4765V33.2129H24.3632V48.4765H22.6021Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M26.7114 48.4765V33.2129H28.4726V48.4765H26.7114Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M30.8208 48.4765V33.2129H32.582V48.4765H30.8208Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M39.0399 42.6059V33.2129H40.8011V42.6059H39.0399Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M43.1493 37.9094V33.2129H44.9105V37.9094H43.1493Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M47.2587 42.6059V33.2129H49.0199V42.6059H47.2587Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M51.3682 48.4765V33.2129H53.1294V48.4765H51.3682Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M55.4775 48.4765V33.2129H57.2387V48.4765H55.4775Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M34.9304 48.4765V33.2129H36.6916V48.4765H34.9304Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M59.5869 48.4765V33.2129H61.3481V48.4765H59.5869Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M63.6965 48.4765V33.2129H65.4577V48.4765H63.6965Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M67.8059 48.4768V32.0391H69.5671V48.4768H67.8059Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M71.9153 48.477V34.9746H73.6765V48.477H71.9153Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M80.1342 48.4761V42.6055H81.8953V48.4761H80.1342Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M76.0248 48.4773V37.9102H77.786V48.4773H76.0248Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M58.0033 3.86026V0.337891H59.7645V3.86026H58.0033Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M27.6044 3.86026V0.337891H29.3656V3.86026H27.6044Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M23.219 17.584V12.666H24.9802V17.584H23.219Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M23.776 29.9121V24.9941H25.5372V29.9121H23.776Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M27.2985 29.9121V24.9941H29.0596V29.9121H27.2985Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M30.8208 29.9121V24.9941H32.582V29.9121H30.8208Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M34.3433 29.9121V24.9941H36.1044V29.9121H34.3433Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M37.8657 29.9121V24.9941H39.6269V29.9121H37.8657Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M41.3879 29.3252V24.4072H43.1491V29.3252H41.3879Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M44.9104 29.3252V24.4072H46.6716V29.3252H44.9104Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M48.4327 29.3252V24.4072H50.1939V29.3252H48.4327Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M51.9551 29.3252V24.4072H53.7163V29.3252H51.9551Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M55.4775 29.3252V24.4072H57.2387V29.3252H55.4775Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M58.9998 29.3252V24.4072H60.7609V29.3252H58.9998Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M43.2642 18.1914V13.2734H45.0253V18.1914H43.2642Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M62.5222 29.7285V24.8105H64.2834V29.7285H62.5222Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M63.0696 17.584V12.666H64.8308V17.584H63.0696Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M67.8615 29.9848H19.9602V28.2236H67.8615V29.9848Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M69.2735 33.5073L18.7861 33.5073L18.7861 31.7461L69.2735 31.7461L69.2735 33.5073Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M28.0452 2.94824L28.3334 2.98785C31.1126 3.36982 37.073 3.56672 43.9143 3.56672C50.7499 3.56672 55.7903 3.37011 58.5717 2.98785L58.8414 2.95078L73.7934 10.4182L71.9409 11.1386C69.1721 12.2154 64.9643 12.8825 60.1024 13.2869C55.2161 13.6933 49.5833 13.8403 43.9143 13.8403C38.2454 13.8403 32.6699 13.6933 27.8409 13.2868C23.0347 12.8822 18.8862 12.2149 16.1187 11.1386L14.3583 10.454L28.0452 2.94824ZM28.3847 4.77067L18.6545 10.1066C21.0775 10.7559 24.2771 11.2194 27.9886 11.5318C32.7485 11.9325 38.2694 12.0791 43.9143 12.0791C49.5592 12.0791 55.1383 11.9325 59.9564 11.5318C63.6571 11.2239 66.8594 10.7695 69.2862 10.1358L58.5395 4.7686C55.5828 5.14479 50.5399 5.3279 43.9143 5.3279C37.3063 5.3279 31.4014 5.14573 28.3847 4.77067Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M64.4187 16.4336L73.0164 24.4674L71.1407 24.695C66.2501 25.2885 55.1713 25.2885 43.9563 25.2885H43.7462C32.5303 25.2885 21.2224 25.2885 16.3318 24.695L14.334 24.4526L23.77 16.437L24.1601 16.4908C26.9274 16.872 37.0076 17.0696 43.8514 17.0696C50.6967 17.0696 61.2366 16.8719 64.0035 16.4908L64.4187 16.4336ZM24.3161 18.284L18.6037 23.1365C24.0963 23.5259 33.9305 23.5273 43.8514 23.5273C53.8479 23.5273 63.5774 23.5258 69.0028 23.1275L63.8221 18.2865C60.4098 18.6535 50.3495 18.8308 43.8514 18.8308C37.3372 18.8308 27.6705 18.6527 24.3161 18.284Z" fill="#BDBDBD"></path>
<path fill-rule="evenodd" clip-rule="evenodd" d="M41.6509 39.733C41.1343 40.3312 40.801 41.2747 40.801 42.6064V48.477H39.0398V42.6064C39.0398 41.0028 39.4403 39.5981 40.318 38.5818C41.2118 37.5468 42.5018 37.0293 44.0298 37.0293C45.5578 37.0293 46.8478 37.5468 47.7417 38.5818C48.6193 39.5981 49.0199 41.0028 49.0199 42.6064V48.477H47.2587V42.6064C47.2587 41.2747 46.9254 40.3312 46.4088 39.733C45.9083 39.1535 45.1436 38.7905 44.0298 38.7905C42.9161 38.7905 42.1513 39.1535 41.6509 39.733Z" fill="#BDBDBD"></path>
</svg>
</body>
</html>