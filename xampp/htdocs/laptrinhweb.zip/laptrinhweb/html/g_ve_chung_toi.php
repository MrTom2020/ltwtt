<!doctype html>
<html lang="vi">
<head>
    <link rel="stylesheet" type="text/css" href="../css/css_cua_trang_chu.css">
    <meta charset="utf-8"/>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
</head>
<body>
<article class="container col-sm-12">
<section  id="s_chung_toi" class="col-8" style="font-size:16px;margin-left:10%;">
<p  style="font-size:36px;margin-bottom:-10%;">Amazing là nền tảng quản lý tài chính hàng đầu ở Đông Nam Á và Đài Loan.</p>
</section>
<section class="col-sm-10" style="padding-left: 18vw;">
    <img src="../tainguyenkhac/hinh_anh/hinh/BK4.png" /><br>
<div class="col-sm-2" style="padding-right: 4vw;">
  <h4> WE SERVE</h4>
Khách hàng luôn đúng
Cung cấp những giá trị vượt xa sự mong đợi của khách hàng
</div>
<div class="col-sm-2" style="padding-right: 4vw;">
<h4>WE ADAPT</h4>
Dự đoán những thay đổi và lập kế hoạch trước
Chấp nhận những thay đổi không lường trước và chủ động trong việc thực thi
</div>
<div class="col-sm-2" style="padding-right: 4vw;">
<h4>WE RUN</h4>
Tự định hướng để phát triển, không cần ai thúc đẩy
Luôn khẩn trương hoàn thành công việc
</div>
<div class="col-sm-2" style="padding-right: 4vw;">
<h4>WE COMMIT</h4>
Đáng tin cậy, làm những gì đã nói
Nâng cao các tiêu chuẩn; không đi đường tắt ngay cả khi không có ai đang quan sát
Chủ động tìm cách phát triển tổ chức
</div>
<div class="col-sm-2" style="padding-right: 4vw;">
<h4>WE STAY HUMBLE</h4>
Luôn khiêm tốn với vị thế của mình và tìm cách học hỏi từ thị trường và đối thủ cạnh tranh
Chấp nhận rằng chúng tôi không hoàn hảo
Làm việc chăm chỉ trước, tận hưởng sau
</div>
</section>
<section class="col-sm-10">
    <h4>Hiểu người khác chính là chìa khóa để lãnh đạo thành công. Tại Amazing,điều quan trọng với chúng tôi là làm thế nào để mang lại trải nghiệm tốt nhất cho nhân viên, đối tác và người dùng.</h4>
</section>
</article>
</body>
</html>