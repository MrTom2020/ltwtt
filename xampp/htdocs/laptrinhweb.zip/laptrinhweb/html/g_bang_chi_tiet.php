<html lang="en" class="no-js"><head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
 
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">

<!-- rel=dynamic-content indicates an element that is replaced with the contents produced by the specified href. 
	 dyn-cs:* URIs are resolved using the WP DynamicContentSpotMappings resource environment provider. These values can
	 also be set using theme metadata if a theme is specified in the URI (e.g. @tl:oid:theme_unique_name). -->
<link rel="stylesheet" href="/wps/contenthandler/!ut/p/digest!Jb5pUIG7VQdDLic9HLA60w/sp/mashup:ra:collection?soffset=0&amp;eoffset=21&amp;themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fcss&amp;entry=wp_dialog_css__0.0%3Ahead_css&amp;entry=wp_simple_contextmenu_css__0.0%3Ahead_css&amp;entry=wp_toolbar_common__0.0%3Ahead_css&amp;entry=wp_toolbar_actionbar__0.0%3Ahead_css&amp;entry=wp_toolbar_sitepreview_contentspot__0.0%3Ahead_css&amp;entry=wp_toolbar_projectmenu__0.0%3Ahead_css&amp;entry=wp_toolbar_logo__0.0%3Ahead_css&amp;entry=wp_one_ui_303__0.0%3Ahead_css&amp;entry=wp_ic4_wai_resources__0.0%3Ahead_css&amp;entry=wp_theme_portal_85__0.0%3Ahead_css&amp;entry=wp_one_ui_dijit_303__0.0%3Ahead_css&amp;entry=wp_oob_sample_styles__0.0%3Ahead_css&amp;entry=wp_status_bar__0.0%3Ahead_css&amp;entry=wp_social_rendering_85__0.0%3Ahead_css&amp;entry=wp_portlet_css__0.0%3Ahead_css" type="text/css"><link rel="alternate" id="head_css_deferred" href="/wps/contenthandler/!ut/p/digest!_AUZ81llcgTjZ5R7vZECkQ/sp/mashup:ra:collection?soffset=0&amp;eoffset=6&amp;themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fcss&amp;entry=wp_dnd_css__0.0%3Ahead_css&amp;entry=wp_federated_documents_picker__0.0%3Ahead_css&amp;entry=wp_contextmenu_css__0.0%3Ahead_css&amp;entry=wp_content_targeting_cam__0.0%3Ahead_css&amp;entry=wcm_inplaceEdit__0.0%3Ahead_css&amp;deferred=true"><script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript">var djConfig={"baseUrl":"/wps/portal_dojo/v1.9/dojo/","locale":"fr","isDebug":false,"debugAtAllCosts":false,"parseOnLoad":false,"afterOnLoad":false,"modulePaths":{"com":"/wps/themeModules/js/com","ibm":"/wps/themeModules/js/ibm","pagebuilder":"/wps/themeModules/modules/pagebuilder/js","portalclient":"/wps/themeModules/modules/portalclient/js","asa":"/wps/themeModules/modules/asa/js","contentmapping":"/wps/themeModules/modules/contentmapping/js","federation":"/wps/themeModules/modules/federation/js"}};djConfig.locale=djConfig.locale.replace(/_/g, "-").replace(/iw/, "he").toLowerCase();(function(){if (typeof(wpModules) == 'undefined') wpModules = {}; if (typeof(wpModules.state) == 'undefined') wpModules.state = {}; if (typeof(wpModules.state.page) == 'undefined') wpModules.state.page = {};wpModules.state.page._initial=[{"nsuri":"http://www.ibm.com/xmlns/prod/websphere/portal/publicparams","name":"selection","value":["Z6_600G0942K81980AAADK8JDHG36"]},{"nsuri":"http://www.ibm.com/xmlns/prod/websphere/portal/publicparams","name":"labelMappings","value":["Z6_00000000000000A0BR2B300GO2","Z6_600G0942K81980AAADK8JDHG36","Z6_000000000000000000000000A0","Z6_600G0942K81980AAADK8JDHG36"]}];wpModules.state.page.path='/wps/portal';wpModules.state.page.protectedPath='/wps/myportal';wpModules.state.page.publicPath='/wps/portal';})();</script><script type="text/javascript" src="/wps/contenthandler/!ut/p/digest!Jb5pUIG7VQdDLic9HLA60w/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fjavascript&amp;entry=wp_client_main__0.0%3Ahead_js&amp;entry=wp_client_ext__0.0%3Ahead_js&amp;entry=wp_state_page__0.0%3Ahead_js&amp;entry=wp_theme_utils__0.0%3Ahead_js&amp;entry=wp_toolbar_viewframe_validator__0.0%3Ahead_js&amp;entry=wp_a11y__0.0%3Ahead_js&amp;entry=wp_toolbar_common__0.0%3Ahead_js&amp;entry=wp_client_logging__0.0%3Ahead_js&amp;entry=wp_client_tracing__0.0%3Ahead_js&amp;entry=wp_toolbar_actionbar__0.0%3Ahead_js&amp;entry=wp_dialog_util__0.0%3Ahead_js&amp;entry=wp_dialog_draggable__0.0%3Ahead_js&amp;entry=wp_dialog_main__0.0%3Ahead_js&amp;entry=wp_client_selector__0.0%3Ahead_js&amp;entry=wp_analytics_aggregator__0.0%3Ahead_js&amp;entry=wp_theme_portal_85__0.0%3Ahead_js&amp;entry=wp_social_rendering_85__0.0%3Ahead_js"></script><link rel="alternate" id="head_js_deferred" href="/wps/contenthandler/!ut/p/digest!_AUZ81llcgTjZ5R7vZECkQ/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fjavascript&amp;entry=dojo_19__0.0%3Ahead_js&amp;entry=dojo_selector_lite_19__0.0%3Ahead_js&amp;entry=dojo_data_19__0.0%3Ahead_js&amp;entry=dojo_dom_19__0.0%3Ahead_js&amp;entry=dojo_app_19__0.0%3Ahead_js&amp;entry=dijit_19__0.0%3Ahead_js&amp;entry=dijit_menu_19__0.0%3Ahead_js&amp;entry=dojo_dnd_basic_19__0.0%3Ahead_js&amp;entry=dojo_dnd_ext_19__0.0%3Ahead_js&amp;entry=dojo_fmt_19__0.0%3Ahead_js&amp;entry=dijit_form_19__0.0%3Ahead_js&amp;entry=dojo_fx_19__0.0%3Ahead_js&amp;entry=dijit_layout_basic_19__0.0%3Ahead_js&amp;entry=dojox_layout_basic_19__0.0%3Ahead_js&amp;entry=dijit_layout_ext_19__0.0%3Ahead_js&amp;entry=dijit_tree_19__0.0%3Ahead_js&amp;entry=wp_contextmenu_js__0.0%3Ahead_js&amp;entry=wp_dnd_namespace__0.0%3Ahead_js&amp;entry=wp_dnd_source__0.0%3Ahead_js&amp;entry=wp_dnd_util__0.0%3Ahead_js&amp;entry=wp_client_dnd__0.0%3Ahead_js&amp;entry=wcm_inplaceEdit__0.0%3Ahead_js&amp;entry=wp_dnd_target__0.0%3Ahead_js&amp;deferred=true"><!--[if IE 7]>
<script type="text/javascript">document.getElementsByTagName("html")[0].className+=" lotusui_ie lotusui_ie7";</script>
<![endif]--> 
<!--[if IE 8]>
<script type="text/javascript">document.getElementsByTagName("html")[0].className+=" lotusui_ie8";</script>
<![endif]-->
<!--[if IE 9]>
<script type="text/javascript">document.getElementsByTagName("html")[0].className+=" lotusui_ie9";</script>
<![endif]-->
<style id="layout-wstate-styles"></style><base href="https://www.acb.com.vn/wps/portal/!ut/p/z1/04_Sj9CPykssy0xPLMnMz0vMAfIjo8zizQwM3A0sTYy8LQwtLQwcHR1dvC28XDzcjc30w8EKDFCAo4FTkJGTMVCTv5F-FOn6kU0irD8KrASfC7AoQLGiIDc0wiDTUREA_OCsuQ!!/">
<title>Quản lý chi tiêu</title>


<link id="com.ibm.lotus.NavStateUrl" rel="alternate" href="/wps/portal/!ut/p/z1/04_Sj9CPykssy0xPLMnMz0vMAfIjo8zizQwM3A0sTYy8LQwtLQwcHR1dvC28XDzcjc30w8EKDFCAo4FTkJGTMVCTv5F-FOn6kU0irD8KrASfC7AoQLGiIDc0wiDTUREA_OCsuQ!!/dz/d5/L2dJQSEvUUt3QS80TmxFL1o2XzYwMEcwOTQySzgxOTgwQUFBREs4SkRIRzM2/">
<link rel="bookmark" title="Quản lý chi tiêu" href="/wps/portal/!ut/p/z1/04_Sj9CPykssy0xPLMnMz0vMAfIjo8zizQwM3A0sTYy8LQwtLQwcHR1dvC28XDzcjc30w8EKDFCAo4FTkJGTMVCTv5F-FOn6kU0irD8KrASfC7AoQLGiIDc0wiDTUREA_OCsuQ!!/dz/d5/L2dJQSEvUUt3QS80TmxFL1o2XzYwMEcwOTQySzgxOTgwQUFBREs4SkRIRzM2/" hreflang="fr">
<!-- link href="/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme/css/acb/css/normalize.css" rel="stylesheet"/ -->

<link href="/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme/css/privilege/styles/vendor.css" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="../css/main2.css">
<link href="/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme/css/privilege/styles/main.css" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="../css/main2.css">
<link href="../css/custom.css" rel="stylesheet">
<link href="../css/customize.css" rel="stylesheet">
<link href="../css/print.css" rel="stylesheet" media="print">
<script src="/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme/js/acb/vendor/jquery.js"></script>
<script src="/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme/js/acb/vendor/jquery.js"></script>

<link href="/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme/images/favicon.ico" rel="shortcut icon" type="image/x-icon">


<script data-dapp-detection="">!function(){let e=!1;function n(){if(!e){const n=document.createElement("meta");n.name="dapp-detected",document.head.appendChild(n),e=!0}}if(window.hasOwnProperty("ethereum")){if(window.__disableDappDetectionInsertion=!0,void 0===window.ethereum)return;n()}else{var t=window.ethereum;Object.defineProperty(window,"ethereum",{configurable:!0,enumerable:!1,set:function(e){window.__disableDappDetectionInsertion||n(),t=e},get:function(){if(!window.__disableDappDetectionInsertion){const e=arguments.callee;e&&e.caller&&e.caller.toString&&-1!==e.caller.toString().indexOf("getOwnPropertyNames")||n()}return t}})}}();</script></head>
<body style="">	
	
	
		<a type="button" class="btn btn-success" href="http://lethanhhiep.com:8080/html/lap_ke_hoach.php" >Quay trở lại</a>
		<header role="banner">

			<!-- site toolbar -->
			<div class="wpthemeHeader">
				<div class="wpthemeInner">
					<!-- renders the top navigation -->
					</div>
			</div><!-- end header -->

			<div class="wpthemeBanner">
				<div class="wpthemeBannerInner">
					<div class="wpthemeInner">
						<div class="wpthemeClear"></div>
					</div>
				</div>
			</div><!--end main banner-->
			
			<div class="wpthemeBanner wpthemeBannerPrimaryNavigation">
				<div class="wpthemeBannerInner">
					<div class="wpthemeInner">
						<div class="wpthemeClear"></div>
					</div>
				</div>
			</div><!--end primary nav banner-->
			
			<div class="wpthemeSecondaryBanner">
				<div class="wpthemeClear"></div>
			</div><!--end secondary banner-->
		</header>
		
		<div class="wpthemeMainContent" role="main" aria-label="IBM WebSphere Portal">
			<div class="wpthemeInner">	
				<!-- asa markup contributions for pages -->	
				

<div class="asa.page" id="asa.page" style="display:none;">
	<span class="asa.page.id">Z6_600G0942K81980AAADK8JDHG36</span>

	

</div>

<div class="wpthemeClear"></div>
				
<c:if test="">   
<div class="wpthemeInner">
	<div id="wpthemeStatusBarContainer" class="wpthemeStatusBarContainer">
		
		<noscript>
			<div class="wpthemeMessage" role="alert" wairole="alert">
				<img class="wpthemeMsgIcon wpthemeMsgIconError" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" alt="Error" />
				<span class="wpthemeAltText">Error:</span>
				<div class="wpthemeMessageBody">Javascript est désactivé dans ce navigateur. Javascript est requis pour cette page. Modifiez les paramètres de votre navigateur pour autoriser l'exécution de Javascript. Pour des instructions spécifiques, voir la documentation de votre navigateur.</div>
			</div>
		</noscript>
	</div>
</div>
</c:if></div>		

			<!-- required - do not remove -->
			<div style="display:none" id="portletState">{}</div><div id="layoutContainers" class="wpthemeLayoutContainers wpthemeLayoutContainersHidden">	
				<div class="wpthemeInner">					
					<div class="hiddenWidgetsDiv">
	<!-- widgets in this container are hidden in the UI by default -->
	<div class="component-container wpthemeFull ibmDndRow wpthemeCol12of12 hiddenWidgetsContainer id-Z7_600G0942K81980AAADK8JDHG33" name="ibmHiddenWidgets"></div><div style="clear:both"></div>
</div>
<!-- this layout has one main container -->
<div class="wptheme1Col">
	<div class="component-container wpthemeFull wpthemeLeft wpthemeCol ibmDndColumn wpthemeCol12of12 wpthemePrimary id-Z7_600G0942K81980AAADK8JDHG37" name="ibmMainContainer"><div class="component-control id-Z7_600G0942K81980AAADK8JDHGB7"><span id="Z7_600G0942K81980AAADK8JDHGB7"></span><section class="ibmPortalControl wpthemeNoSkin a11yRegionTarget" role="region" aria-labelledby="wpRegionIdZ7_600G0942K81980AAADK8JDHGB7">
	<!-- marks the node the analytics tags for this portlet will be placed in -->
	

	<div class="asa.portlet" id="asa.portlet.Z7_600G0942K81980AAADK8JDHGB7" style="display:none;">
		<span class="asa.portlet.id">Z7_600G0942K81980AAADK8JDHGB7</span>

		

	</div>
	
<!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
	<div style="position:relative; z-index: 1;">
		<div class="analytics.overlay"></div>
	</div>
    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
   
    <div class="wpthemeOverflowAuto"> <!-- lm:control dynamic spot injects markup of layout control -->
   		        
				            <div class="main-nav type-mobile" id="main-nav">            
<a href="#0" onclick="return false;" title="Collapse Menu" class="btn-collapse-menu"></a>
            

            <div class="minimal-menu">
                <a href="/wps/portal/Home" title="ACB" class="logo"> </a>

                <div class="wrap-top-minimal-menu">
                    <ul class="wrap-list-top">
                        <li>
                            <a href="/wps/portal/Home/News" title="Cá nhân" class="lnk lnk-personal"> </a>
                        </li>
                        <li>
                            <a href="/wps/portal/Home/business" title="Doanh nghiệp" class="lnk lnk-business"> </a>
                        </li>
                        <li>
                            <a href="/wps/portal/Home/about-us" title="Về ACB" class="lnk lnk-about-acb"> </a>
                        </li>
                    </ul>
                    <span class="highlight"></span>
                    



<ul class="wrap-list-middle">
	
				<li data-submenu-id="want" class="">
		
			              <a href="#" title="Tôi muốn" onclick="return false;" class="lnk lnk-type-1"></a>
			              
				</li><li data-submenu-id="" class="">
		    	 <a href="/wps/portal/privilege/vn" title="Ngân hàng ưu tiên" class="lnk lnk-type-8"></a>
		    
				</li><li data-submenu-id="the" class="">
		
			<a href="/vn/personal/the" title="Thẻ" class="lnk lnk-type-3"></a>
			
				</li><li data-submenu-id="tai-khoan-tien-gui" class="">
		
			<a href="/vn/personal/tai-khoan-tien-gui" title="Tài khoản tiền gửi" class="lnk lnk-type-4"></a>
			
				</li><li data-submenu-id="cho-vay" class="">
		
			<a href="/vn/personal/cho-vay" title="Cho vay" class="lnk lnk-type-5"></a>
			
				</li><li data-submenu-id="khuyen-mai-uu-dai" class="">
		
			              <a href="#" title="Khuyến mãi Ưu đãi" onclick="return false;" class="lnk lnk-type-6"></a>
			              
				</li><li data-submenu-id="giao-dich-cung-acb" class="">
		
			<a href="/vn/personal/giao-dich-cung-acb" title="GIAO DỊCH CÙNG ACB" class="lnk lnk-type-7"></a>
			

</li></ul>

                </div>

              

                <div class="wrap-bottom-minimal-menu">
                   
                    <div class="wrap-atm-brand">
                        <a href="/wps/portal/Home/atm" title="ATMs, CDMs &amp; Brand"> </a>
                    </div>
                </div>

            </div>
           <div id="load">
 
           </div>
   
        </div>

        <div id="main" class="page type-mobile page-tools-calculator">
        
            <div class="page-wrapper">
                


             

                

                

<link rel="stylesheet" href="../css/customize.css">
<script src="/ACBComponent/resource/js/tool-manager/tool-calculator.js"></script>

<script>
		$(function() {
			/* ------------------load defauft-------------------- */
			 $('#main').addClass('page-tool-calculator');
			 $('#main').removeClass('page-tools-calculator');
			/* -------------------------------------- */
			$('#short-version').click(function() {
			    $('#main').addClass('page-tool-calculator');
			    $('#main').removeClass('page-tools-calculator');	
				var url = '/ACBComponent/jsp/html/vn/management-tool/short-version.jsp';
				$.post( url, { cmd:'DEFAULT'}, function(data) {
					var content = $( data );		
					$("#content").empty().append(content);				
				});
				return false;
			});
			/* -------------------------------------- */
			$('#long-version').click(function() {
			    $('#main').addClass('page-tools-calculator');
			    $('#main').removeClass('page-tool-calculator');		
				var url = '/ACBComponent/jsp/html/vn/management-tool/long-version.jsp';
				$.post( url, { cmd:'DEFAULT'}, function(data) {
					var content = $( data );		
					$("#content").empty().append(content);				
				});
				return false;
			});
	});
	
	function loadType() {
		var typeSelect = document.getElementById("type-chitieu").value;
		if(typeSelect==0){
			$('#chitieuCamketTaichinh').removeClass('hidden');
			$('#chitieuNhaSinhhoatphi').addClass('hidden');
			$('#chitieuGiaoducSuckhoe').addClass('hidden');
			$('#chitieuMuasamDichuyen').addClass('hidden');
			$('#chitieuGiaitriAnngoai').addClass('hidden');
		} else if(typeSelect==1){
			$('#chitieuNhaSinhhoatphi').removeClass('hidden');
			$('#chitieuCamketTaichinh').addClass('hidden');
			$('#chitieuGiaoducSuckhoe').addClass('hidden');
			$('#chitieuMuasamDichuyen').addClass('hidden');
			$('#chitieuGiaitriAnngoai').addClass('hidden');
			
		} else if (typeSelect == 2){
			$('#chitieuNhaSinhhoatphi').addClass('hidden');
			$('#chitieuCamketTaichinh').addClass('hidden');
			$('#chitieuGiaoducSuckhoe').removeClass('hidden');
			$('#chitieuMuasamDichuyen').addClass('hidden');
			$('#chitieuGiaitriAnngoai').addClass('hidden');
		} else if (typeSelect == 3){
			$('#chitieuNhaSinhhoatphi').addClass('hidden');
			$('#chitieuGiaoducSuckhoe').addClass('hidden');
			$('#chitieuCamketTaichinh').addClass('hidden');
			$('#chitieuMuasamDichuyen').removeClass('hidden');
			$('#chitieuGiaitriAnngoai').addClass('hidden');
		} else if (typeSelect == 4){
			$('#chitieuNhaSinhhoatphi').addClass('hidden');
			$('#chitieuGiaoducSuckhoe').addClass('hidden');
			$('#chitieuMuasamDichuyen').addClass('hidden');
			$('#chitieuCamketTaichinh').addClass('hidden');
			$('#chitieuGiaitriAnngoai').removeClass('hidden');
		}
	}
		
</script>

 
 <!-- ---------------- -->
 <div class="wrap-list-items" id="content">
     <div class="evaluation">
                        <h2>Quản lý chi tiêu</h2>
                        <p>Nhập vào thu nhập và các khoản chi tiêu, bạn sẽ có cái nhìn rõ hơn về tình trạng tài chính để hoạch định cho tương lai cùng Amazing</p>
                        <p></p>
                        <p class="press f-side">Kết quả</p>
                        <div class="select-wrapper select-2 third"><span>Hàng tháng</span>
                            <span class="icon-select"></span>
                            <select name="type-select" id="main_select" onchange="mainCalculator();">
                            	<option value="1">Hàng tháng</option>
                                <option value="2">Hàng tuần</option>
                                <option value="3">Hàng 2 tuần</option>
                                <option value="4">Hàng quý</option>
                                <option value="5">Hàng năm</option>
                                
                            </select>
                        </div>
                        <div style="clear:both"></div>
                        
                        <div class="custome_chart" id="pieChart" data-highcharts-chart="11"><div class="highcharts-container" id="highcharts-22" style="position: relative; overflow: hidden; width: 260px; height: 260px; text-align: left; line-height: normal; z-index: 0; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"><svg version="1.1" style="font-family:&quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif;font-size:12px;" xmlns="http://www.w3.org/2000/svg" width="260" height="260"><desc>Created with Highcharts 4.0.4</desc><defs><clipPath id="highcharts-23"><rect x="0" y="0" width="240" height="235"></rect></clipPath></defs><rect x="0" y="0" width="260" height="260" strokeWidth="0" fill="#4ba9dd" class=" highcharts-background"></rect><rect x="10" y="10" width="240" height="235" fill="#4ba9dd"></rect><g class="highcharts-series-group" zIndex="3"><g class="highcharts-series highcharts-tracker" visibility="visible" zIndex="0.1" transform="translate(10,10) scale(1 1)" style=""><path fill="#42ced0" d="M 119.97810513060277 10.00000222969912 A 107.5 107.5 0 1 1 117.27097781879348 10.0346454063707 L 118.51490420836669 59.01885354672266 A 58.5 58.5 0 1 0 119.98808511758384 59.00000121337115 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#009395" d="M 117.37844451998724 10.031970117317144 A 107.5 107.5 0 0 1 117.27097781879348 10.0346454063707 L 118.51490420836669 59.01885354672266 A 58.5 58.5 0 0 0 118.57338608762096 59.01739769174933 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#009395" d="M 117.37844451998724 10.031970117317144 A 107.5 107.5 0 0 1 117.27097781879348 10.0346454063707 L 118.51490420836669 59.01885354672266 A 58.5 58.5 0 0 0 118.57338608762096 59.01739769174933 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#0b56c6" d="M 117.37844451998724 10.031970117317144 A 107.5 107.5 0 0 1 117.27097781879348 10.0346454063707 L 118.51490420836669 59.01885354672266 A 58.5 58.5 0 0 0 118.57338608762096 59.01739769174933 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#0b56c6" d="M 117.37844451998724 10.031970117317144 A 107.5 107.5 0 0 1 117.27097781879348 10.0346454063707 L 118.51490420836669 59.01885354672266 A 58.5 58.5 0 0 0 118.57338608762096 59.01739769174933 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#361db4" d="M 117.37844451998724 10.031970117317144 A 107.5 107.5 0 0 1 119.85068465665731 10.000103698058183 L 119.91874467362281 59.00005643103631 A 58.5 58.5 0 0 0 118.57338608762096 59.01739769174933 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#361db4" d="M 119.9581846097003 10.000008132683405 A 107.5 107.5 0 0 1 119.85068465665731 10.000103698058183 L 119.91874467362281 59.00005643103631 A 58.5 58.5 0 0 0 119.97724464806946 59.00000442569283 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#64199d" d="M 119.9581846097003 10.000008132683405 A 107.5 107.5 0 0 1 119.85068465665731 10.000103698058183 L 119.91874467362281 59.00005643103631 A 58.5 58.5 0 0 0 119.97724464806946 59.00000442569283 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path><path fill="#64199d" d="M 119.9581846097003 10.000008132683405 A 107.5 107.5 0 0 1 119.85068465665731 10.000103698058183 L 119.91874467362281 59.00005643103631 A 58.5 58.5 0 0 0 119.97724464806946 59.00000442569283 Z" stroke="#FFFFFF" stroke-width="1" stroke-linejoin="round" transform="translate(0,0)"></path></g><g class="highcharts-markers" visibility="visible" zIndex="0.1" transform="translate(10,10) scale(1 1)"></g></g><text x="130" text-anchor="middle" class="highcharts-title" zIndex="4" style="color:#333333;font-size:18px;fill:#333333;width:196px;" y="128"><tspan>Biểu đồ</tspan></text><g class="highcharts-legend" zIndex="7"><g zIndex="1"><g></g></g></g><g class="highcharts-tooltip" zIndex="8" style="cursor:default;padding:0;white-space:nowrap;" transform="translate(0,-9999)"><path fill="none" d="M 3 0 L 13 0 C 16 0 16 0 16 3 L 16 13 C 16 16 16 16 13 16 L 3 16 C 0 16 0 16 0 13 L 0 3 C 0 0 0 0 3 0" isShadow="true" stroke="black" stroke-opacity="0.049999999999999996" stroke-width="5" transform="translate(1, 1)"></path><path fill="none" d="M 3 0 L 13 0 C 16 0 16 0 16 3 L 16 13 C 16 16 16 16 13 16 L 3 16 C 0 16 0 16 0 13 L 0 3 C 0 0 0 0 3 0" isShadow="true" stroke="black" stroke-opacity="0.09999999999999999" stroke-width="3" transform="translate(1, 1)"></path><path fill="none" d="M 3 0 L 13 0 C 16 0 16 0 16 3 L 16 13 C 16 16 16 16 13 16 L 3 16 C 0 16 0 16 0 13 L 0 3 C 0 0 0 0 3 0" isShadow="true" stroke="black" stroke-opacity="0.15" stroke-width="1" transform="translate(1, 1)"></path><path fill="rgba(249, 249, 249, .85)" d="M 3 0 L 13 0 C 16 0 16 0 16 3 L 16 13 C 16 16 16 16 13 16 L 3 16 C 0 16 0 16 0 13 L 0 3 C 0 0 0 0 3 0"></path><text x="8" zIndex="1" style="font-size:12px;color:#333333;fill:#333333;" y="21"></text></g></svg></div></div>
                        
                        <div class="note">
                            <div class="r-note" style="margin-left:5%;">
                                <p style="background-color: #42ced0; width:40%;">Cam kết tài chính</p>
                               
                                <p class="col2" id="labMainCommitment">0 VND</p>
                                <input type="hidden" id="hiddenMainCommitment" value="0">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color: #009395; width:40%;">Nhà</p>    
                                <p class="col2" id="labMainHome">VND</p>
                                <input type="hidden" id="hiddenMainHome">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color: #009395; width:40%;">Sinh hoạt phí</p>
                                <p class="col2" id="labMainShp"> VND</p>
                                <input type="hidden" id="hiddenMainShp">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color: #0b56c6; width:40%;">Giáo dục</p>
                               
                                <p class="col2" id="labMainEducation"> VND</p>
                                <input type="hidden" id="hiddenMainEducation">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color: #0b56c6; width:40%;">Sức khỏe</p>
                               
                                <p class="col2" id="labMainHealth"> VND</p>
                                <input type="hidden" id="hiddenMainHealth">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color: #361db4; width:40%;">Mua sắm</p>
                               
                                <p class="col2" id="labMainShoping">0 VND</p>
                                <input type="hidden" id="hiddenMainShoping" value="0">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color:#361db4; width:40%;">Di chuyển</p>
                               
                                <p class="col2" id="labMainTransport"> VND</p>
                                <input type="hidden" id="hiddenMainTransport">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color: #64199d; width:40%;">Giải trí</p>
                    
                                <p class="col2" id="labMainEntaiterment"> VND</p>
                                <input type="hidden" id="hiddenMainEntaiterment">
                            </div>
                            <div class="r-note" style="margin-left:5%;">
                            <p style="background-color: #64199d; width:40%;">Ăn ngoài</p>
                                
                                <p class="col2" id="labMainEatingOut"> VND</p>
                                <input type="hidden" id="hiddenMainEatingOut">
                            </div>
                        </div>
                        <p></p>
                        <hr>
                        <p class="tit-value">Tổng thu nhập</p>
                        <p class="press" id="labThunhapTotal">0 VND</p>
                        <input type="hidden" id="hiddenThunhapTotal" value="0">
                        <p></p>
                        <p class="tit-value">Tổng chi tiêu</p>
                        <p class="press" id="labChitieuTotal">0 VND</p>
                        <p></p>                        
                        <p class="tit-value">Tích lũy tài chính</p>
                        <p class="press" id="labCanbang">0 VND</p>
                    </div>
                    <div class="table-detail">
                        <h3>Thu nhập</h3>
                       
                        <div class="item-details">
                            <div class="item-detail">
                                Thu nhập cá nhân
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="type-select" id="thunhap_canhan_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_canhan" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div class="item-details">
                            <div class="item-detail">
                                Thu nhập của vợ/chồng
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="thunhap_vo_chong_select" id="thunhap_vo_chong_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_vo_chong" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div class="item-details">
                            <div class="item-detail">
                                Thưởng/làm ngoài giờ/phụ cấp
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="thunhap_phucap_select" id="thunhap_phucap_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_phucap" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div class="item-details">
                            <div class="item-detail">
                                Thu nhập từ tiền lãi, hoạt động đầu tư
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="type-select" id="thunhap_tienlai_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_tienlai" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div class="item-details">
                            <div class="item-detail">
                                Lương hưu
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="thunhap_luonghuu_select" id="thunhap_luonghuu_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_luonghuu" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div class="item-details">
                            <div class="item-detail">
                                Trợ cấp từ gia đình
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="type-select" id="thunhap_trocap_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_trocap" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div class="item-details">
                            <div class="item-detail">
                                Hỗ trợ phúc lợi của nhà nước
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="thunhap_phucloi_select" id="thunhap_phucloi_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_phucloi" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div class="item-details">
                            <div class="item-detail">
                                Thu nhập khác 
                            </div>
                            <div class="value-details se-input">
                                 <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                                    <span class="icon-select"></span>
                                    <select name="type-select" id="thunhap_khac_select" onchange="monthIncom();">
                                        <option value="1">Hàng tháng</option>
		                                <option value="2">Hàng tuần</option>
		                                <option value="3">Hàng 2 tuần</option>
		                                <option value="4">Hàng quý</option>
		                                <option value="5">Hàng năm</option>
                                    </select>
                                </div>
                                <input type="text" id="thunhap_khac" onblur="monthIncom();" onkeyup="convert(this);">
                                <label class="currency">VND</label>
                            </div>
                        </div>
                        <div style="clear:both;"></div>
                        <p class="sum-monthly" id="labTotalThunhap">Tổng thu nhập (hàng tháng)</p>
                        <p class="num-monthly" id="thunhap_total">0 <span>VND</span></p>
                        <h3>Chi tiêu</h3>
                        <div class="cate-payment">
                            <div class="tit-label">
                                <p>Chọn danh mục</p>
                            </div>
                            <div class="value-details">
                                 <div class="select-wrapper select-2 "><span>CAM KẾT TÀI CHÍNH</span>
                                    <span class="icon-select"></span>
                                    <select name="type-select" id="type-chitieu" onchange="loadType();">
                                    	<option value="0">CAM KẾT TÀI CHÍNH</option>
                                        <option value="1">NHÀ / SINH HOẠT PHÍ</option>
                                        <option value="2">GIÁO DỤC / SỨC KHỎE</option>
                                        <option value="3">MUA SẮM / DI CHUYỂN</option>
                                        <option value="4">GIẢI TRÍ / ĂN NGOÀI</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        


		<!-- ----------------------------Cam ket tai chinh------------------------- --> 
		<div id="chitieuCamketTaichinh" class="">
			<div class="item-details">
                 <div class="item-detail tit-cate">
                     Cam kết tài chính
                 </div>
                 <div>
                      
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                    Tiền thuê nhà/Chi phí trả lãi vay mua nhà
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_thuenha_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_thuenha" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Trả lãi vay mua xe hơi
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_tralai_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_tralai" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Các khoản thanh toán nợ vay khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_thanhtoanno_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_thanhtoanno" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                    Trả lãi thẻ tín dụng
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_tralaitindung_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_tralaitindung" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Đóng góp cho quỹ hưu trí
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_quyhuu_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_quyhuu" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Tiết kiệm
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_tietkiem_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_tietkiem" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
			 
			  <div class="item-details">
                 <div class="item-detail">
                     Chi phí nuôi con
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_nuoicon_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_nuoicon" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
			 
			  <div class="item-details">
                 <div class="item-detail">
                     Tài trợ/ Từ thiện
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_taitro_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_taitro" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
			 
			 <div class="item-details">
                 <div class="item-detail">
                     Tiền tiêu vặt cho Con
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_tientieuvat_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_tientieuvat" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
			 
			 <div class="item-details">
                 <div class="item-detail">
                     Chi tiêu tài chính khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="commitment_chiphikhac_select" onchange="financialCommitmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="commitment_chiphikhac" onblur="financialCommitmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div style="clear:both;"></div>
   
    <p class="sum-monthly" id="labCommitmentTotal">Tổng cam kết tài chính (hàng tháng)</p>
    <p class="num-monthly" id="commitment_total">0 <span>VND</span></p>
	</div>
<!-- -------------------------------------------------------------------------------- -->                         
                        
<!-- ----------------------------chi tieu nha sinh hoat phi------------------------- --> 
                       
          <div id="chitieuNhaSinhhoatphi" class="hidden">
                 	
               
			<div class="item-details">
                 <div class="item-detail tit-cate">
                     Nhà
                 </div>
                 <div>                     
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                    Thuế nhà đất
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="nha_thuedat_select" onchange="homeCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="nha_thuedat" onblur="homeCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Phí quản lý tòa nhà
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="nha_phiquanlytoanha_select" onchange="homeCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="nha_phiquanlytoanha" onblur="homeCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Bảo hiểm nhà và vật dụng
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="nha_baohiemvatdung_select" onchange="homeCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="nha_baohiemvatdung" onblur="homeCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                    Chi phí sửa chữa nhà
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="nha_chiphisuanha_select" onchange="homeCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="nha_chiphisuanha" onblur="homeCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Vật dụng gia đình
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="nha_vatdunggiadinh_select" onchange="homeCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="nha_vatdunggiadinh" onblur="homeCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Chi phí nhà khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="nha_chiphikhac_select" onchange="homeCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="nha_chiphikhac" onblur="homeCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div style="clear:both;"></div>
    <p class="sum-monthly" id="labHomeTotal">Tổng chi tiêu nhà (hàng tháng)</p>
    <p class="num-monthly" id="nha_total"><span>VND</span></p>
    <p></p>
    <div class="item-details">
        <div class="item-detail tit-cate">
            Sinh hoạt
        </div>
        <div></div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Điện
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_dien_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_dien" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
            Gas
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_gas_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_gas" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Nước
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_nuoc_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_nuoc" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
           Internet
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_internet_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_internet" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div class="item-details">
        <div class="item-detail">
           Truyền hình cáp
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_truyenhinh_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_truyenhinh" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div class="item-details">
        <div class="item-detail">
           Điện thoại nhà
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_dienthoai_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_dienthoai" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div class="item-details">
        <div class="item-detail">
           Điện thoại di động
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_didong_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_didong" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div class="item-details">
        <div class="item-detail">
            Sinh hoạt khác
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="shp_khac_select" onchange="utilityCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="shp_khac" onblur="utilityCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div style="clear:both;"></div>
    <p class="sum-monthly" id="labUtilityTotal">Tổng chi tiêu sinh hoạt phí (hàng tháng)</p>
    <p class="num-monthly" id="shp_total"><span>VND</span></p>
	</div>
<!-- -------------------------------------------------------------------------------- --> 
<!-- ----------------------------chi tieu giao duc suc khoe-------------------------- --> 	
	<div id="chitieuGiaoducSuckhoe" class="hidden">
		<div class="item-details">
                 <div class="item-detail tit-cate">
                     Giáo dục
                 </div>
                 <div>                      
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Học phí
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaoduc_hocphi_select" onchange="educationCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaoduc_hocphi" onblur="educationCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Học phí đại học hoặc sau tốt nghiệp
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaoduc_daihoc_select" onchange="educationCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaoduc_daihoc" onblur="educationCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Chi phí nuôi con nhỏ/ mẫu giáo/ nhà trẻ
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaoduc_mannon_select" onchange="educationCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaoduc_mannon" onblur="educationCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                    Đồng phục
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaoduc_dongphuc_select" onchange="educationCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaoduc_dongphuc" onblur="educationCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Thể thao, âm nhạc, giải trí, …
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaoduc_thethao_select" onchange="educationCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaoduc_thethao" onblur="educationCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Tham quan/du lịch
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaoduc_thamquan_select" onchange="educationCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaoduc_thamquan" onblur="educationCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Chi phí giáo dục khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaoduc_khac_select" onchange="educationCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaoduc_khac" onblur="educationCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

    <div style="clear:both;"></div>
    
    <p class="sum-monthly" id="labEducationTotal">Tổng chi tiêu giáo dục (hàng tháng) </p>
    <p class="num-monthly" id="giaoduc_total"> <span>VND</span></p>
    <p></p>
    <div class="item-details">
        <div class="item-detail tit-cate">
            Sức khỏe
        </div>
        <div>             
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Bảo hiểm sức khỏe cá nhân/BHYT
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_bhyt_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_bhyt" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
            Bảo hiểm nhân thọ
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_bhnt_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              		<option value="2">Hàng tuần</option>
              		<option value="3">Hàng 2 tuần</option>
              		<option value="4">Hàng quý</option>
              		<option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_bhnt" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
           Chi phí khám chữa bệnh
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_khamchuabenh_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_khamchuabenh" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
            Chi phí nha khoa
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_phinhakhoa_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_phinhakhoa" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div class="item-details">
        <div class="item-detail">
            Tiền thuốc
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_tienthuoc_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_tienthuoc" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
       <div class="item-details">
        <div class="item-detail">
           Chi phí chăm sóc mắt
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_chamsocmat_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_chamsocmat" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    
       <div class="item-details">
        <div class="item-detail">
           Khám bệnh định kỳ
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_khamdinhky_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_khamdinhky" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
       <div class="item-details">
        <div class="item-detail">
            Chi phí sức khỏe khác
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="suckhoe_chiphikhac_select" onchange="healthCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="suckhoe_chiphikhac" onblur="healthCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div style="clear:both;"></div>
    <p class="sum-monthly" id="labHealthTotal">Tổng chi tiêu sức khỏe (hàng tháng)</p>
    <p class="num-monthly" id="suckhoe_total"> <span>VND</span></p>
	</div>
	<!-- ----------------mua sam dich chuyen------------ -->
	<div id="chitieuMuasamDichuyen" class="hidden">
		<div class="item-details">
                 <div class="item-detail tit-cate">
                     Mua sắm
                 </div>
                 <div></div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Tiền chợ
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_tiencho_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_tiencho" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Rau quả
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_rauqua_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_rauqua" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Mua sắm cho Con
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_chocon_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_chocon" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                    Quần áo / giầy dép
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_quanao_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_quanao" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Mỹ phẩm/ Nước hoa/ dầu thơm
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_mypham_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_mypham" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Làm tóc/ trang điểm
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_trangdiem_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_trangdiem" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Quà tặng, mừng cưới, tiệc, …
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_mungcuoi_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_mungcuoi" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Các loại mua sắm khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="muasam_khac_select" onchange="shoppingCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="muasam_khac" onblur="shoppingCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
     <div style="clear:both;"></div>
     
    <p class="sum-monthly" id="labShoppingTotal">Tổng chi tiêu mua sắm (hàng tháng)</p>
    <p class="num-monthly" id="muasam_total">86,666,667 <span>VND</span></p>
    <p></p>
    
    <div class="item-details">
        <div class="item-detail tit-cate">
            Di chuyển
        </div>
        <div>             
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Bảo hiểm Ô tô
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="dichuyen_baohiemoto_select" onchange="transportCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="dichuyen_baohiemoto" onblur="transportCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
            Bảo trì Ô tô
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="dichuyen_baotrioto_select" onchange="transportCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="dichuyen_baotrioto" onblur="transportCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Thuế sử dụng xe máy, Ô tô
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="dichuyen_thueoto_select" onchange="transportCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="dichuyen_thueoto" onblur="transportCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
            Xăng, dầu
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="dichuyen_xangdau_select" onchange="transportCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="dichuyen_xangdau" onblur="transportCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Chi phí cầu đường/ đỗ xe
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="dichuyen_chiphicauduong_select" onchange="transportCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="dichuyen_chiphicauduong" onblur="transportCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div class="item-details">
        <div class="item-detail">
            Xe lửa/ Xe buýt/ Phà
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="dichuyen_phuongtien_select" onchange="transportCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="dichuyen_phuongtien" onblur="transportCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div class="item-details">
        <div class="item-detail">
            Chi phí di chuyển khác
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="dichuyen_khac_select" onchange="transportCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="dichuyen_khac" onblur="transportCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    
    <div style="clear:both;"></div>
    <p class="sum-monthly" id="labTransportTotal">Tông chi tiêu di chuyển (hàng tháng)</p>
    <p class="num-monthly" id="dichuyen_total"> <span>VND</span></p>
	</div>
	<!-- ----------------------giai tri an ngoai---------------------------- -->
	<div id="chitieuGiaitriAnngoai" class="hidden">
				<div class="item-details">
                 <div class="item-detail tit-cate">
                     Giải trí
                 </div>
                 <div>                      
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Nghỉ lễ
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_nghile_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_nghile" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Bars/clubs
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_bar_club_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_bar_club" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Những nơi giải trí khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_nhungnoikhac_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_nhungnoikhac" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                    Gym/thành viên clb thể thao
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_thethao_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_thethao" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             <div class="item-details">
                 <div class="item-detail">
                     Thuốc lá
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_thuocla_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_thuocla" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Xem phim/nghe nhạc
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_xemphim_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_xemphim" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Sở thích khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_sothich_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_sothich" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>
             
             <div class="item-details">
                 <div class="item-detail">
                     Báo chí
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_baochi_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_baochi" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Tiệc cưới/lễ hội
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_tieccuoi_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_tieccuoi" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div class="item-details">
                 <div class="item-detail">
                     Chi phí giải trí khác
                 </div>
                 <div class="value-details se-input">
                      <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                         <span class="icon-select"></span>
                         <select name="type-select" id="giaitri_khac_select" onchange="entertainmentCalculator();">
                             <option value="1">Hàng tháng</option>
                       <option value="2">Hàng tuần</option>
                       <option value="3">Hàng 2 tuần</option>
                       <option value="4">Hàng quý</option>
                       <option value="5">Hàng năm</option>
                         </select>
                     </div>
                     <input type="text" id="giaitri_khac" onblur="entertainmentCalculator();" onkeyup="convert(this);">
                     <label class="currency">VND</label>
                 </div>
             </div>

             <div style="clear:both;"></div>
    <p class="sum-monthly" id="labEntertaimentTotal">Tông chi tiêu giải trí (hàng tháng)</p>
    <p class="num-monthly" id="giaitri_total"><span>VND</span></p>
    <p></p>
    <div class="item-details">
        <div class="item-detail tit-cate">
            Ăn ngoài
        </div>
        <div>             
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Nhà hàng/quán ăn/quán cà phê
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="anngoai_nhahang_select" onchange="eatingOutCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="anngoai_nhahang" onblur="eatingOutCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
            Ăn vặt
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="anngoai_anvat_select" onchange="eatingOutCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="anngoai_anvat" onblur="eatingOutCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Ăn trưa
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="anngoai_antrua_select" onchange="eatingOutCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="anngoai_antrua" onblur="eatingOutCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>

    <div class="item-details">
        <div class="item-detail">
            Cà phê
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="anngoai_caphe_select" onchange="eatingOutCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="anngoai_caphe" onblur="eatingOutCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div class="item-details">
        <div class="item-detail">
            Chi phí ăn ngoài khác
        </div>
        <div class="value-details se-input">
             <div class="select-wrapper select-2 opt-payment"><span>Hàng tháng</span>
                <span class="icon-select"></span>
                <select name="type-select" id="anngoai_khac_select" onchange="eatingOutCalculator();">
                    <option value="1">Hàng tháng</option>
              <option value="2">Hàng tuần</option>
              <option value="3">Hàng 2 tuần</option>
              <option value="4">Hàng quý</option>
              <option value="5">Hàng năm</option>
                </select>
            </div>
            <input type="text" id="anngoai_khac" onblur="eatingOutCalculator();" onkeyup="convert(this);">
            <label class="currency">VND</label>
        </div>
    </div>
    <div style="clear:both;"></div>
    <p class="sum-monthly" id="labEatingOutTotal">Tổng chi tiêu ăn ngoài (hàng tháng)</p>
    <p class="num-monthly" id="anngoai_total"> <span>VND</span></p>
	</div>
	<!-- --------------------------------------------------------- -->
	<span style="color:black;">(*) Bảng tính chỉ mang tính chất tham khảo.</span>
</div>



               	
                 	
                 	
                    <div style="clear:both"></div></div>
 <!-- Popup to mesage-->
  <div class="wrap-call-to-chat" id="popupMessage">
      <div class="inner">
          <div class="wrap-top-call">
              <h2 class="title">Thông báo</h2>
              <img src="/wps/contenthandler/dav/themelist/ACBTheme/css/acb/images/logo-1.png" alt="">
          </div>
          <div class="wrap-register-call">
              <div class="wrap-info">
                  <ul>
                      <li id="labMessage" style="color: white;"> Thông báo lỗi </li>
                  </ul>
            </div>
        </div>
        <div class="wrap-no-thanks">
            <a href="#0" title="Close" class="close" id="close-send-email">
                <span class="icon"></span>
                <span class="title">Đóng.</span>
            </a>
        </div>
    </div>
 </div>
<script src="../js/chart.js"></script>
<script src="/ACBComponent/resource/js/chart/highcharts-pie.js"></script>
 
                

<script language="javascript">
   function goToByScrollx(){
    $('html,body').animate({
        scrollTop: $("#"+'main').offset().top},'slow');
   }
</script>

            </div>

        </div>

<script language="javascript">
   var languageUrl = "/wps/portal/en/management-tool";
   $("#lang-switcher-select option:last").attr("link",languageUrl);
</script>

</div>
</section> </div></div></div>
<div class="wpthemeClear"></div>
				</div>
			</div>
		</div>
		<!--end main content-->
		
		
		
	<!-- end frame -->
		
    <!-- This is responsible for bootstrapping the configuration for the javascript framework. 
        This is located here instead of the head section to improve client performance. -->	
		
		
		
		<div class="wpthemeComplementaryContent" id="wpthemeComplementaryContent" role="region" aria-labelledby="wpthemeComplementaryContentText">
			<span style="display:none;" class="wpthemeAltText" id="wpthemeComplementaryContentText">Complementary Content</span>
			<script type="text/javascript" src="/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fjavascript&amp;entry=wp_portal__0.0%3Aconfig_config_static&amp;entry=wcm_config__0.0%3Aconfig_config_static&amp;entry=wcm_inplaceEdit__0.0%3Aconfig_config_static"></script><script type="text/javascript">i$.merge({"ibmCfg":{"themeConfig":{"themeUniqueName":"com.ibm.portal.custom.theme.acbtheme","themeRootURI":"/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme","themeWebAppBaseURI":"/wps/defaultTheme85/themes/html/dynamicSpots","themeWebDAVBaseURI":"dav:fs-type1/themes/ACBTheme/","modulesWebAppBaseURI":"/wps/themeModules","commonResourcesRootURI":"/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/common-resources","isRTL":false,"isPageRenderModeCSA":false,"portletOverridePageTitle":"Quản lý chi tiêu","currentContentNodeOID":"Z6_600G0942K81980AAADK8JDHG36","loadingImage":"css/images/loading.gif","dndSourceDefinitions":[{"id":"ibmDndColumn","object":"com.ibm.pb.dnd.layout.LayoutColumnSource","orientation":"vertical"},{"id":"ibmDndRow","object":"com.ibm.pb.dnd.layout.LayoutRowSource","orientation":"horizontal"}],"categorySources":["system/WebContentCategory.json,label:shelf_socialCategory"],"styleSources":[],"layoutSources":[]},"portalConfig":{"locale":"fr","portalURI":"/wps/portal","contentHandlerURI":"/wps/contenthandler/!ut/p/digest!rZxHym55S9CVPkq0dFJ_Cg/","pocURI":"/wps/portal/!ut/p/z0/0wcA1NLTeQ!!/","isVirtualPortal":false,"canImpersonate":false,"themeRootURI":"/wps/defaultTheme85/themes/html/dynamicSpots","parentPageID":"Z6_00000000000000A0BR2B300GO2","currentPageOID":"Z6_600G0942K81980AAADK8JDHG36","canAnonymousUserViewCurrentPage":true,"bootstrapState":"&lt;?xml version=&#034;1.0&#034; encoding=&#034;UTF-8&#034;?&gt;&lt;root xmlns=&#034;http://www.ibm.com/xmlns/prod/websphere/portal/v6.1/portal-state&#034;&gt;&lt;state type=&#034;navigational&#034;&gt;&lt;selection selection-node=&#034;Z6_600G0942K81980AAADK8JDHG36&#034;&gt;&lt;mapping src=&#034;Z6_00000000000000A0BR2B300GO2&#034; dst=&#034;Z6_600G0942K81980AAADK8JDHG36&#034;/&gt;&lt;mapping src=&#034;Z6_000000000000000000000000A0&#034; dst=&#034;Z6_600G0942K81980AAADK8JDHG36&#034;/&gt;&lt;/selection&gt;&lt;expansions&gt;&lt;node id=&#034;Z6_00000000000000A0BR2B300GO2&#034;/&gt;&lt;node id=&#034;Z6_000000000000000000000000A0&#034;/&gt;&lt;/expansions&gt;&lt;/state&gt;&lt;/root&gt;","isUserLoggedIn":false,"currentUser":"anonymous portal user","currentUserOID":"","aggregatedStyle":null,"isCurrentPageEditable":true,"wcmPageMetadata":{"contentRoot":null,"sharingScope":null},"projectUUID":null},"userName":""},"com_ibm_theme_capabilities":{"analytics_aggregator":"8.0","toolbar":"8.5","social_rendering":"8.5","a11y":"1.0","hasBaseURL":"true","simple-contextmenu":"1.1","oneUI":"3.0.3"},"com_ibm_device_class":[]});ibmCfg.portalConfig.bootstrapState=(ibmCfg.portalConfig.bootstrapState||"").replace(/&lt;/gm, '<').replace(/&gt;/gm, '>').replace(/&amp;/gm, '&').replace(/&#039;/gm, "'").replace(/&#034;/gm, '"');i$.merge({"ibmCfg":{"portalConfig":{"asaConfig":{"canViewAsaReports":"false","canViewAsaSitePromotions":"false","canCreateAsaSitePromotions":"false","canDeleteAsaSitePromotions":"false","reportConfig":{"scopes":[]}}}}});i$.merge({"ibmCfg":{"portalConfig":{"isShowHiddenPages":false}}});</script><script type="text/javascript" src="/wps/contenthandler/!ut/p/digest!_AUZ81llcgTjZ5R7vZECkQ/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fjavascript&amp;entry=wp_state_page_modes__0.0%3Aconfig_js&amp;entry=wp_one_ui_303__0.0%3Aconfig_js&amp;entry=wp_dialog_main__0.0%3Aconfig_js&amp;entry=wp_toolbar_utils__0.0%3Aconfig_js&amp;entry=wp_toolbar_projectmenu__0.0%3Aconfig_js&amp;entry=wp_theme_high_contrast__0.0%3Aconfig_js&amp;entry=wp_simple_contextmenu_js__0.0%3Aconfig_js&amp;entry=wp_simple_contextmenu_ext__0.0%3Aconfig_js&amp;entry=wp_ic4_wai_resources__0.0%3Aconfig_js&amp;entry=wp_theme_skin_region__0.0%3Aconfig_js&amp;entry=wp_status_bar__0.0%3Aconfig_js"></script><a rel="alternate" id="config_js_deferred" href="/wps/contenthandler/!ut/p/digest!_AUZ81llcgTjZ5R7vZECkQ/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fjavascript&amp;entry=wp_liveobject_framework_core__0.0%3Aconfig_js&amp;entry=wp_toolbar_menuactions__0.0%3Aconfig_js&amp;entry=wp_portal_ui_utils__0.0%3Aconfig_js&amp;entry=wp_federated_documents_picker__0.0%3Aconfig_js&amp;entry=wp_contextmenu_js__0.0%3Aconfig_js&amp;entry=wp_dnd_main__0.0%3Aconfig_js&amp;entry=wp_movecontrols__0.0%3Aconfig_js&amp;entry=wp_content_targeting_cam__0.0%3Aconfig_js&amp;entry=wp_toolbar_controlactions__0.0%3Aconfig_js&amp;entry=wp_analytics_tags__0.0%3Aconfig_js&amp;entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&amp;deferred=true" style="display:none"></a><span id="simpleMenuTemplate" class="wpthemeMenuLeft">
    <div class="wpthemeMenuBorder">
        <div class="wpthemeMenuNotchBorder"></div>
        <!-- define the menu item template inside the "ul" element.  only "css-class", "description", and "title" are handled by the theme's sample javascript. -->
       
    </div>
    <!-- Template for loading -->
    
    <!-- Template for submenu -->
    <div class="wpthemeAnchorSubmenu wpthemeTemplateSubmenu">
        <div class="wpthemeMenuBorder wpthemeMenuSubmenu">
            <ul id="${submenu-id}" class="wpthemeMenuDropDown" role="menu"><li role="menuitem" tabindex="-1"></li></ul>
        </div>
    </div>
</span><a rel="alternate" id="config_markup_deferred" href="/wps/contenthandler/!ut/p/digest!IXwiX9drWR0if7K7KQc7aA/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fplain&amp;entry=wp_dnd_main__0.0%3Aconfig_markup&amp;entry=wp_contextmenu_templates__0.0%3Aconfig_markup&amp;deferred=true" style="display:none"></a></div>
	

<script type="text/javascript">	
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-56996301-1', 'auto');
		  ga('send', 'pageview');

		</script>



<div class="h-overlay"></div></body></html>