
<html lang="en" class="no-js"><head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
 
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">

<!-- rel=dynamic-content indicates an element that is replaced with the contents produced by the specified href. 
	 dyn-cs:* URIs are resolved using the WP DynamicContentSpotMappings resource environment provider. These values can
	 also be set using theme metadata if a theme is specified in the URI (e.g. @tl:oid:theme_unique_name). -->

<script type="text/javascript">document.getElementsByTagName("html")[0].className+=" lotusui_ie lotusui_ie7";</script>
<![endif]--> 
<!--[if IE 8]>
<script type="text/javascript">document.getElementsByTagName("html")[0].className+=" lotusui_ie8";</script>
<![endif]-->
<!--[if IE 9]>
<script type="text/javascript">document.getElementsByTagName("html")[0].className+=" lotusui_ie9";</script>
<![endif]-->
<style id="layout-wstate-styles"></style><base href="http://localhost:8080/html/">
<title>Quản lý chi tiêu</title>
<link href="../css/vendor.css" type="text/css" rel="stylesheet">
<link href="../css/main2.css" type="text/css" rel="stylesheet">

<link href="../css/custom.css" type="text/css" rel="stylesheet">
<link href="../css/customize.css" type="text/css" rel="stylesheet">
<link href="../css/print.css" type="text/css" rel="stylesheet" media="print">
<script src="../js/vendor.js"></script>

</head>
<body style="width:100%;">	
	
	
		
		<header role="banner">

			<!-- site toolbar -->
			<div class="wpthemeHeader">
				<div class="wpthemeInner">
					<!-- renders the top navigation -->
					</div>
			</div><!-- end header -->

			<div class="wpthemeBanner">
				<div class="wpthemeBannerInner">
					<div class="wpthemeInner">
						<div class="wpthemeClear"></div>
					</div>
				</div>
			</div><!--end main banner-->
			
			<div class="wpthemeBanner wpthemeBannerPrimaryNavigation">
				<div class="wpthemeBannerInner">
					<div class="wpthemeInner">
						<div class="wpthemeClear"></div>
					</div>
				</div>
			</div><!--end primary nav banner-->
			
			<div class="wpthemeSecondaryBanner">
				<div class="wpthemeClear"></div>
			</div><!--end secondary banner-->
		</header>
		
		<div class="wpthemeMainContent" role="main" aria-label="IBM WebSphere Portal">
			<div class="wpthemeInner">	
				<!-- asa markup contributions for pages -->	
				

<div class="asa.page" id="asa.page" style="display:none;">
	<span class="asa.page.id">Z6_600G0942K81980AAADK8JDHG36</span>

	

</div>

<div class="wpthemeClear"></div>
				
<c:if test="">   
<div class="wpthemeInner">
	<div id="wpthemeStatusBarContainer" class="wpthemeStatusBarContainer">
		
		<noscript>
			<div class="wpthemeMessage" role="alert" wairole="alert">
				<img class="wpthemeMsgIcon wpthemeMsgIconError" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" alt="Error" />
				<span class="wpthemeAltText">Error:</span>
				<div class="wpthemeMessageBody">Javascript est désactivé dans ce navigateur. Javascript est requis pour cette page. Modifiez les paramètres de votre navigateur pour autoriser l'exécution de Javascript. Pour des instructions spécifiques, voir la documentation de votre navigateur.</div>
			</div>
		</noscript>
	</div>
</div>
</c:if></div>		

			<!-- required - do not remove -->
			<div style="display:none" id="portletState">{}</div><div id="layoutContainers" class="wpthemeLayoutContainers wpthemeLayoutContainersHidden">	
				<div class="wpthemeInner">					
					<div class="hiddenWidgetsDiv">
	<!-- widgets in this container are hidden in the UI by default -->
	<div class="component-container wpthemeFull ibmDndRow wpthemeCol12of12 hiddenWidgetsContainer id-Z7_600G0942K81980AAADK8JDHG33" name="ibmHiddenWidgets"></div><div style="clear:both"></div>
</div>
<!-- this layout has one main container -->
<div class="wptheme1Col">
	<div class="component-container wpthemeFull wpthemeLeft wpthemeCol ibmDndColumn wpthemeCol12of12 wpthemePrimary id-Z7_600G0942K81980AAADK8JDHG37" name="ibmMainContainer"><div class="component-control id-Z7_600G0942K81980AAADK8JDHGB7"><span id="Z7_600G0942K81980AAADK8JDHGB7"></span><section class="ibmPortalControl wpthemeNoSkin a11yRegionTarget" role="region" aria-labelledby="wpRegionIdZ7_600G0942K81980AAADK8JDHGB7">
	<!-- marks the node the analytics tags for this portlet will be placed in -->
	

	<div class="asa.portlet" id="asa.portlet.Z7_600G0942K81980AAADK8JDHGB7" style="display:none;">
		<span class="asa.portlet.id">Z7_600G0942K81980AAADK8JDHGB7</span>

		

	</div>
	

	<div style="position:relative; z-index: 1;">
		<div class="analytics.overlay"></div>
	</div>
    
    <div class="wpthemeOverflowAuto">
 <div class="main-nav type-mobile" id="main-nav">            
<a href="#0" onclick="return false;" title="Collapse Menu" class="btn-collapse-menu"></a>
            <div class="full-menu">
                <div class="wrap-top-nav">
<script language="javascript">
$('#textid2').keydown(function (event) {
    var keypressed = event.keyCode || event.which;
    if (keypressed == 13) {
       submitFrmMobi();
    }
});
  function submitFrmMobi(){
     var query_search =  document.frm-search-mobile.search_query.value;
     sessionStorage.setItem("searchQR", query_search );
     document.frm-search-mobile.submit();
  }
</script>     
                </div>   
                </div>                
            </div>
        </div>
        <div id="main" style="width:100%;" class="page type-mobile page-tool-calculator">
        
 <div class="page-wrapper">

<link rel="stylesheet" href="../css/customize.css">
<script src="../js/tool-calculator.js"></script>



  <div class="wrap-filter" style="background-image: linear-gradient(to bottom right, #2eb84b, #fff);">
     <div class="wrap-control" >
         <a href="http://lethanhhiep.com:8080/html/so_giao_dich.php" title="Bảng tổng quát"   class="btn-short" id="short-version">Bảng tổng quát</a><a href="http://lethanhhiep.com:8080/html/g_bang_chi_tiet.php" title="Bảng chi tiết" class="btn-long"   id="long-version">Bảng chi tiết</a> 
         <div class="tool-quick-links">
         <a href="#" class="link link-click-to-chat"></a>
         <a onclick="inserttocookies('/wps/portal?1dmy&amp;page=acb.tool.management-tool&amp;urile=wcm:path:acbwebsite/acb-vn', 'Quản lý chi tiêu', 'Giúp bạn tính toán các khoản thu nhập và chi tiêu để hoạch định số tiền cần đầu tư')" href="#" title="Quản lý chi tiêu" class="link link-stuff-i-like"></a>
         
     </div>
     </div>
  </div>
 <!-- ---------------- -->
 <div class="wrap-list-items" id="content">
 <!-- //////// -->
 	<div class="evaluation"  style="background-image: linear-gradient(to bottom right, #2eb84b, #fff);">
		<h2>Quản lý chi tiêu hàng tháng</h2>
		<p>Nhập vào thu nhập và các khoản chi tiêu hàng tháng, bạn sẽ có cái nhìn rõ hơn về tình trạng tài chính để hoạch định cho tương lai cùng Amazing</p>
		<p></p>
		<p class="press">Kết quả</p>
		<p></p>
		<p class="tit-value">Tổng thu nhập</p>
		<p class="press" id="labTotalMonthIncome"> VND</p>
		<input type="hidden" id="hiddenTotalMonthIncome" >
		<p></p>
		<p class="tit-value">Tổng chi tiêu</p>
		<p class="press" id="labTotalMonthExpenses">VND</p>
		<input type="hidden" id="hiddenTotalMonthExpenses">
		<p></p>
		<p class="tit-value">Tích lũy tài chính</p>
		<p class="press" id="monthlyBalance">VND</p>
	</div>
	<div class="table-detail">
		
		<h3>Thu nhập hàng tháng</h3>
		<div class="item-details">
			<div class="item-detail">
				Tổng thu nhập
			</div>
			<div class="value-details">
				<input type="text" id="totalMonthIncome"  value="0" onblur="shortMonthIncome();" onkeyup="convert(this);">
				
				<label class="currency" id="labMothlyIncom">VND</label>
			</div>
		</div>
		<hr>
		<h3>Chi tiêu hàng tháng</h3>
		<div class="item-details">
			<div class="item-detail">
				Nhà / Sinh hoạt phí
			</div>
			<div class="value-details">
				<input type="text" id="homeUtilities" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Thực phẩm / Tạp hóa
			</div>
			<div class="value-details">
				<input type="text" id="foodGroceries" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>
		<div class="item-details">
			<div class="item-detail">
				Mua sắm
			</div>
			<div class="value-details">
				<input type="text" id="shopping" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Di chuyển
			</div>
			<div class="value-details">
				<input type="text" id="transport" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Giải trí
			</div>
			<div class="value-details">
				<input type="text" id="entertaiment" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Chăm sóc con
			</div>
			<div class="value-details">
				<input type="text" id="childrenExprenses" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Trả nợ vay
			</div>
			<div class="value-details">
				<input type="text" id="loans" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Bảo hiểm / đầu tư
			</div>
			<div class="value-details">
				<input type="text" id="securities" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Chăm sóc sức khỏe
			</div>
			<div class="value-details">
				<input type="text" id="health" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>

		<div class="item-details">
			<div class="item-detail">
				Khác
			</div>
			<div class="value-details">
				<input type="text" id="other" onblur="monthExprenses();" onkeyup="convert(this);">
				<label class="currency">VND</label>
			</div>
		</div>
		<span style="color:black;">(*) Bảng tính chỉ mang tính chất tham khảo.</span>
	</div>
	
	<div style="clear:both"></div>
 <!-- //////// -->
 </div>
 <!-- Popup to mesage-->


               

<script language="javascript">
   function goToByScrollx(){
    $('html,body').animate({
        scrollTop: $("#"+'main').offset().top},'slow');
   }
</script>

            </div>

        </div>

<script language="javascript">
   var languageUrl = "/wps/portal/en/management-tool";
   $("#lang-switcher-select option:last").attr("link",languageUrl);
</script>
  
</div>
</section> </div></div></div>
<div class="wpthemeClear"></div>
				</div>
			</div>
		</div>
		<!--end main content-->
		
		
		
	<!-- end frame -->
		
    <!-- This is responsible for bootstrapping the configuration for the javascript framework. 
        This is located here instead of the head section to improve client performance. -->	
		
		
		
		<div class="wpthemeComplementaryContent" id="wpthemeComplementaryContent" role="region" aria-labelledby="wpthemeComplementaryContentText">
			<span style="display:none;" class="wpthemeAltText" id="wpthemeComplementaryContentText">Complementary Content</span>
		<script type="text/javascript">i$.merge({"ibmCfg":{"themeConfig":{"themeUniqueName":"com.ibm.portal.custom.theme.acbtheme","themeRootURI":"/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/themes/ACBTheme","themeWebAppBaseURI":"/wps/defaultTheme85/themes/html/dynamicSpots","themeWebDAVBaseURI":"dav:fs-type1/themes/ACBTheme/","modulesWebAppBaseURI":"/wps/themeModules","commonResourcesRootURI":"/wps/contenthandler/!ut/p/digest!-nPtAlPf9EYTFvwzrZnGwg/dav/fs-type1/common-resources","isRTL":false,"isPageRenderModeCSA":false,"portletOverridePageTitle":"Quản lý chi tiêu","currentContentNodeOID":"Z6_600G0942K81980AAADK8JDHG36","loadingImage":"css/images/loading.gif","dndSourceDefinitions":[{"id":"ibmDndColumn","object":"com.ibm.pb.dnd.layout.LayoutColumnSource","orientation":"vertical"},{"id":"ibmDndRow","object":"com.ibm.pb.dnd.layout.LayoutRowSource","orientation":"horizontal"}],"categorySources":["system/WebContentCategory.json,label:shelf_socialCategory"],"styleSources":[],"layoutSources":[]},"portalConfig":{"locale":"fr","portalURI":"/wps/portal","contentHandlerURI":"/wps/contenthandler/!ut/p/digest!1-1DTvqWPwNKFJKVq-FnZQ/","pocURI":"/wps/portal/!ut/p/z0/0wcA1NLTeQ!!/","isVirtualPortal":false,"canImpersonate":false,"themeRootURI":"/wps/defaultTheme85/themes/html/dynamicSpots","parentPageID":"Z6_00000000000000A0BR2B300GO2","currentPageOID":"Z6_600G0942K81980AAADK8JDHG36","canAnonymousUserViewCurrentPage":true,"bootstrapState":"&lt;?xml version=&#034;1.0&#034; encoding=&#034;UTF-8&#034;?&gt;&lt;root xmlns=&#034;http://www.ibm.com/xmlns/prod/websphere/portal/v6.1/portal-state&#034;&gt;&lt;state type=&#034;navigational&#034;&gt;&lt;selection selection-node=&#034;Z6_600G0942K81980AAADK8JDHG36&#034;&gt;&lt;mapping src=&#034;Z6_00000000000000A0BR2B300GO2&#034; dst=&#034;Z6_600G0942K81980AAADK8JDHG36&#034;/&gt;&lt;mapping src=&#034;Z6_000000000000000000000000A0&#034; dst=&#034;Z6_600G0942K81980AAADK8JDHG36&#034;/&gt;&lt;/selection&gt;&lt;expansions&gt;&lt;node id=&#034;Z6_00000000000000A0BR2B300GO2&#034;/&gt;&lt;node id=&#034;Z6_000000000000000000000000A0&#034;/&gt;&lt;/expansions&gt;&lt;/state&gt;&lt;/root&gt;","isUserLoggedIn":false,"currentUser":"anonymous portal user","currentUserOID":"","aggregatedStyle":null,"isCurrentPageEditable":true,"wcmPageMetadata":{"contentRoot":null,"sharingScope":null},"projectUUID":null},"userName":""},"com_ibm_theme_capabilities":{"analytics_aggregator":"8.0","toolbar":"8.5","social_rendering":"8.5","a11y":"1.0","hasBaseURL":"true","simple-contextmenu":"1.1","oneUI":"3.0.3"},"com_ibm_device_class":[]});ibmCfg.portalConfig.bootstrapState=(ibmCfg.portalConfig.bootstrapState||"").replace(/&lt;/gm, '<').replace(/&gt;/gm, '>').replace(/&amp;/gm, '&').replace(/&#039;/gm, "'").replace(/&#034;/gm, '"');i$.merge({"ibmCfg":{"portalConfig":{"asaConfig":{"canViewAsaReports":"false","canViewAsaSitePromotions":"false","canCreateAsaSitePromotions":"false","canDeleteAsaSitePromotions":"false","reportConfig":{"scopes":[]}}}}});i$.merge({"ibmCfg":{"portalConfig":{"isShowHiddenPages":false}}});</script><script type="text/javascript" src="/wps/contenthandler/!ut/p/digest!_AUZ81llcgTjZ5R7vZECkQ/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fjavascript&amp;entry=wp_state_page_modes__0.0%3Aconfig_js&amp;entry=wp_one_ui_303__0.0%3Aconfig_js&amp;entry=wp_dialog_main__0.0%3Aconfig_js&amp;entry=wp_toolbar_utils__0.0%3Aconfig_js&amp;entry=wp_toolbar_projectmenu__0.0%3Aconfig_js&amp;entry=wp_theme_high_contrast__0.0%3Aconfig_js&amp;entry=wp_simple_contextmenu_js__0.0%3Aconfig_js&amp;entry=wp_simple_contextmenu_ext__0.0%3Aconfig_js&amp;entry=wp_ic4_wai_resources__0.0%3Aconfig_js&amp;entry=wp_theme_skin_region__0.0%3Aconfig_js&amp;entry=wp_status_bar__0.0%3Aconfig_js"></script><a rel="alternate" id="config_js_deferred" href="/wps/contenthandler/!ut/p/digest!_AUZ81llcgTjZ5R7vZECkQ/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fjavascript&amp;entry=wp_liveobject_framework_core__0.0%3Aconfig_js&amp;entry=wp_toolbar_menuactions__0.0%3Aconfig_js&amp;entry=wp_portal_ui_utils__0.0%3Aconfig_js&amp;entry=wp_federated_documents_picker__0.0%3Aconfig_js&amp;entry=wp_contextmenu_js__0.0%3Aconfig_js&amp;entry=wp_dnd_main__0.0%3Aconfig_js&amp;entry=wp_movecontrols__0.0%3Aconfig_js&amp;entry=wp_content_targeting_cam__0.0%3Aconfig_js&amp;entry=wp_toolbar_controlactions__0.0%3Aconfig_js&amp;entry=wp_analytics_tags__0.0%3Aconfig_js&amp;entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&amp;deferred=true" style="display:none"></a><span id="simpleMenuTemplate" class="wpthemeMenuLeft">
    <div class="wpthemeMenuBorder">
        <div class="wpthemeMenuNotchBorder"></div>
        <!-- define the menu item template inside the "ul" element.  only "css-class", "description", and "title" are handled by the theme's sample javascript. -->
        
    </div>
    <!-- Template for loading -->
   
    <!-- Template for submenu -->
    <div class="wpthemeAnchorSubmenu wpthemeTemplateSubmenu">
        <div class="wpthemeMenuBorder wpthemeMenuSubmenu">
            <ul id="${submenu-id}" class="wpthemeMenuDropDown" role="menu"><li role="menuitem" tabindex="-1"></li></ul>
        </div>
    </div>
</span><a rel="alternate" id="config_markup_deferred" href="/wps/contenthandler/!ut/p/digest!gLmkSJTKFf4ViVcSs9rP8A/mashup/ra:collection?themeID=ZJ_600G0942K81980AI3EBOS30002&amp;locale=fr&amp;locale=en&amp;mime-type=text%2Fplain&amp;entry=wp_dnd_main__0.0%3Aconfig_markup&amp;entry=wp_contextmenu_templates__0.0%3Aconfig_markup&amp;deferred=true" style="display:none"></a></div>
		

<script type="text/javascript">	
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-56996301-1', 'auto');
		  ga('send', 'pageview');

		</script>



<div class="h-overlay"></div></body></html>