<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
</head>
<body>
<svg data-v-0698e127="" data-v-72379cd2="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" viewBox="0 0 24 24" aria-labelledby="test" version="1.1">
<defs data-v-0698e127="">
</defs> <g data-v-0698e127="" id="Icons/account/ic_account" stroke="none" stroke-width="1" fill="#BDBDBD" fill-rule="evenodd">
<rect data-v-0698e127="" id="blue-background" fill-opacity="0" fill="#FFFFFF" x="0" y="0" width="24" height="24">
</rect>
 <path data-v-72379cd2="" d="M21,18 L21,19 C21,20.105 20.105,21 19,21 L5,21 C3.895,21 3,20.105 3,19 L3,5 C3,3.895 3.895,3 5,3 L19,3 C20.105,3 21,3.895 21,5 L21,6 L12,6 C10.895,6 10,6.895 10,8 L10,16 C10,17.105 10.895,18 12,18 L21,18 L21,18 Z M12,16 L22,16 L22,8 L12,8 L12,16 L12,16 Z M16,13.5 C15.17,13.5 14.5,12.83 14.5,12 C14.5,11.17 15.17,10.5 16,10.5 C16.83,10.5 17.5,11.17 17.5,12 C17.5,12.83 16.83,13.5 16,13.5 L16,13.5 Z" id="Shape" data-v-0698e127="">
 </path>
 </g>
</svg>
</body>
</html>