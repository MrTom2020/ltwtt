<html prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" lang="vi-VN" style="font-size:62.5%" class="hiperf loaded" dir="ltr"><head data-info="v:20201208_29556320;a:39f31a57-4880-406c-91fe-78e6f524d229;cn:0;az:{did:a7ccbd4efae74ddbb493c3a55e47b714, rid: 0, sn: easia-prod-entertainment, dt: 2020-12-07T11:49:40.8191847Z, bt: 2020-12-08T23:47:19.8842145Z};ddpi:1;dpio:;dpi:1;dg:tmx.pc.webkit.chrome.chrome76plus;th:green;PageName:currenciesPage;m:vi-vn;cb:;l:vi-vn;mu:vi-vn;ud:{cid:,vk:finance,n:,l:vi-vn,ck:FinanceCurrencyConverter};xd:;ovc:f;al:;f:msnallexpusers,muidflt17cf,muidflt19cf,muidflt28cf,muidflt47cf,muidflt54cf,muidflt301cf,moneyhz1cf,moneyhz3cf,artgly1cf,gallery2cf,msnapp2cf,1s-bing-news,vebudumu04302020,bbh20200521msncf,msnsports5cf,weather2cf,weather3cf,wfprong1t;userOptOut:false;userOptOutOptions:" data-js="{&quot;dpi&quot;:1.0,&quot;ddpi&quot;:1.0,&quot;dpio&quot;:null,&quot;forcedpi&quot;:null,&quot;dms&quot;:6000,&quot;ps&quot;:1000,&quot;bds&quot;:7,&quot;dg&quot;:&quot;tmx.pc.webkit.chrome.chrome76plus&quot;,&quot;ssl&quot;:true,&quot;moduleapi&quot;:&quot;https://www.msn.com/vi-vn/money/api/modules/fetch&quot;,&quot;cdnmoduleapi&quot;:&quot;https://static-entertainment-eas-s-msn-com.akamaized.net/vi-vn/money/api/modules/cdnfetch&quot;,&quot;pdpdeltaupdateapi&quot;:&quot;https://www.msn.com/vi-vn/homepage/api/pdp/updatepdpdata&quot;,&quot;xd&quot;:null,&quot;signedin&quot;:0,&quot;sso&quot;:&quot;https://login.live.com/login.srf?wa=wsignin1.0&amp;rpsnv=13&amp;checkda=1&amp;ct=1607608928&amp;rver=7.0.6730.0&amp;wp=lbi&amp;wreply=https%3a%2f%2fwww.msn.com%2fvi-vn%2fmoney%2fsecure%2fsilentpassport%3fsecure%3dtrue&amp;lc=1033&amp;id=1184&amp;mkt=vi-vn&quot;,&quot;exchangeenabled&quot;:false,&quot;twitterimpenabled&quot;:false,&quot;greenidcallenabled&quot;:false,&quot;ispreload&quot;:false,&quot;anonckname&quot;:&quot;&quot;,&quot;ssocomplete&quot;:false}" data-client-settings="{&quot;apptype&quot;:&quot;hybrid&quot;,&quot;geo_country&quot;:&quot;vn&quot;,&quot;geo_subdivision&quot;:&quot;bin duong&quot;,&quot;geo_zip&quot;:&quot;820000&quot;,&quot;geo_ip&quot;:&quot;113.182.168.0&quot;,&quot;geo_lat&quot;:&quot;10.9817&quot;,&quot;geo_long&quot;:&quot;106.65&quot;,&quot;os_region&quot;:&quot;&quot;,&quot;browser&quot;:{&quot;browsertype&quot;:&quot;chrome&quot;,&quot;version&quot;:&quot;87&quot;,&quot;ismobile&quot;:&quot;false&quot;},&quot;deviceformfactor&quot;:&quot;desktop&quot;,&quot;domain&quot;:&quot;www.msn.com&quot;,&quot;locale&quot;:{&quot;language&quot;:&quot;vi&quot;,&quot;script&quot;:&quot;&quot;,&quot;market&quot;:&quot;vn&quot;},&quot;os&quot;:&quot;windows&quot;,&quot;pagetype&quot;:&quot;currencies&quot;,&quot;apps_locale&quot;:&quot;&quot;,&quot;base_url&quot;:&quot;/vi-vn/money/&quot;,&quot;aid&quot;:&quot;39f31a574880406c91fe78e6f524d229&quot;,&quot;sid&quot;:null,&quot;v&quot;:&quot;20201208_29556320&quot;,&quot;static_page&quot;:false,&quot;empty_gif&quot;:&quot;//static-entertainment-eas-s-msn-com.akamaized.net/sc/9b/e151e5.gif&quot;,&quot;functionalonly_cookie_experience&quot;:false,&quot;functional_cookies&quot;:&quot;&quot;,&quot;functional_cookie_patterns&quot;:&quot;&quot;,&quot;fbid&quot;:&quot;132970837947&quot;,&quot;lvk&quot;:&quot;money&quot;,&quot;vk&quot;:&quot;finance&quot;,&quot;cat&quot;:null,&quot;autorefresh&quot;:true,&quot;bingssl&quot;:false,&quot;autorefreshsettings&quot;:{&quot;is_market_enabled&quot;:true,&quot;timeout&quot;:8,&quot;idle_enabled&quot;:false,&quot;idle_timeout&quot;:&quot;2&quot;},&quot;uipr&quot;:false,&quot;uiprsettings&quot;:{&quot;enabled&quot;:false,&quot;frequency_minutes&quot;:0,&quot;banner_delay_minutes&quot;:null,&quot;maxfresh_display&quot;:null,&quot;minfresh_count&quot;:&quot;5&quot;,&quot;ajaxtimeoutinseconds&quot;:&quot;60&quot;},&quot;imgsrc&quot;:{&quot;quality_high&quot;:&quot;60&quot;,&quot;quality_low&quot;:&quot;5&quot;,&quot;order_timeout&quot;:&quot;1000&quot;},&quot;adsettings&quot;:{&quot;wait_for_ad_in_sec&quot;:&quot;3&quot;,&quot;retry_for_ad&quot;:&quot;2&quot;},&quot;mecontroluri&quot;:&quot;https://mem.gfx.ms/meversion/?partner=msn&amp;market=vi-vn&quot;,&quot;mecontrolv2uri&quot;:&quot;&quot;,&quot;lazyload&quot;:{&quot;enabled&quot;:false}}" iris-modules-settings="[{&quot;n&quot;:&quot;banner&quot;,&quot;pos&quot;:&quot;top&quot;,&quot;canvas&quot;:&quot;vlp&quot;}]">
        
            <script>if(window&&(typeof window.performance=="object")){if(typeof window.performance.mark=="function"){window.performance.mark("TimeToHeadStart");}}</script>

        <meta charset="utf-8">




        <meta name="robots" content="index, follow">        <link rel="preload" href="//static-entertainment-eas-s-msn-com.akamaized.net/sc/f8/f77b07.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preconnect" href="img-s-msn-com.akamaized.net"><link rel="preconnect" href="c.msn.com"><link rel="preconnect" href="c.msn.cn"><link rel="preconnect" href="https://www.bing.com"><link rel="preconnect" href="//web.vortex.data.msn.com"><link rel="dns-prefetch" href="img-s-msn-com.akamaized.net"><link rel="dns-prefetch" href="c.msn.com"><link rel="dns-prefetch" href="c.msn.cn"><link rel="dns-prefetch" href="https://www.bing.com"><link rel="dns-prefetch" href="//web.vortex.data.msn.com"><meta name="msapplication-TileColor" content="#224f7b"><meta name="msapplication-TileImage" content="//static-entertainment-eas-s-msn-com.akamaized.net/sc/1f/08ced4.png"><meta name="msapplication-config" content="none">        <title>Đổi tiền - MSN Tài chính </title>
<meta name="description" content="Công cụ chuyển đổi tiền tệ giúp đổi tiền theo các tỷ giá hối đoái hiện hành trên toàn thế giới. ">
 <meta name="viewport" content="width=device-width,initial-scale=1.0">

<link rel="stylesheet" href="//static-entertainment-eas-s-msn-com.akamaized.net/vi-vn/money/_sc/css/d7cb56b9-6e84a50b/direction=ltr.locales=vi-vn.themes=green.dpi=resolution1x/53-e71093-1cab3bcf/42-b7bb9b-1864198b/7f-145015-491caa4c/7d-3d0302-273ab94b/82-0361a8-71d40569/b1-72dc7e-24a7339f/c0-77dd6d-ebceab88/51-e120b3-ac5c2fc8/7a-e2312d-feaf21fa/ed-6bbb92-90280eae/77-7a8b59-9d91c285/70-82ab63-d4a77217/5d-6b1dcd-868f6756/9c-af4c6c-3fd034f2/7c-368f3a-302202f?ver=20201208_29556320&amp;fdhead=msnallexpusers,muidflt17cf,muidflt19cf,muidflt28cf,muidflt47cf,muidflt54cf,muidflt301cf,moneyhz1cf,moneyhz3cf,artgly1cf,gallery2cf,msnapp2cf,1s-bing-news,vebudumu04302020,bbh20200521msncf,msnsports5cf,weather2cf,weather3cf,wfprong1t&amp;csopd=20201002173902&amp;csopdb=20201204234342" type="text/css" media="all"><script>(function(n){function i(i,r){try{var u=new n.FontFace(i,r,{}).load();t.push(u)}catch(f){}}var t=[];typeof n.FontFace=="function"&&i("ps_g","url(//static-entertainment-eas-s-msn-com.akamaized.net/sc/f8/f77b07.woff2)")})(window),function(n,t){function h(n,i,r){typeof n!="string"&&(r=i,i=n,n=t);i&&i.splice||(r=i,i=[]);n==it?a=!0:n==rt&&(v=!0);l(n,i,r,!1,!1)}function l(n,t,i,r,f,e){var s,y;if(!n||!c[n]){var h=ot(n,t),o=h.dependencyNotFound,l=h.resolved;if(o){typeof u[o]=="undefined"&&(u[o]=[]);u[o].push(e||{i:n,d:t,f:i,r:r,s:f});return}s=typeof i=="function";y=v&&a&&s&&!f;y?et(n,i,l,r):ft(s,n,i,l,r)}}function ft(n,t,i,r,u){var f;f=n?i.apply(null,r):i;d(t,f,u)}function et(n,t,i,r){setTimeout(function(){var u=t.apply(null,i);d(n,u,r)},1)}function d(t,i,r){r&&(i={});t&&(i?(c[t]=i,f.push(t),g()):n.console&&console.error("Dependencies resolved, but object still not defined (or is otherwise falsey). id:"+t+"; typeof obj: "+typeof i))}function g(){var t,s,h,i,o,c,r,n;if(e)e&&(e=2);else{t=[];do{for(e=1,h=f.length,i=0;i<h;i++)o=f[i],c=u[o]||[],t=t.concat(c),delete u[o];for(f=[],s=t.length,r=0;r<s;r++)n=t[r],l(n.i,n.d,n.f,n.r,n.s,n);t=[]}while(e>1);e=0}}function ot(n,t){for(var e,i=[],r,o=t?t.length:0,u=0;u<o;u++){var f=t[u],s=c[f],h=typeof s!="undefined";if(!h){if(e=st(n,f),e){i.push(e);continue}r||(r=f);break}i.push(s)}return o===i.length?{resolved:i}:{dependencyNotFound:r}}function st(i,r){var f=k.exec(r),e,u;if(f){if(e=f[1],u=n[e],u!==t)return u;s||(s=setTimeout(nt,w))}}function nt(){var i,r,e,o,h;s=0;i=!1;for(r in u)e=k.exec(r),e&&(o=e[1],h=n[o],h!==t?f.push(r):i=!0);i&&!s&&(s=setTimeout(nt,w));f.length&&g()}function ht(n,t,i){if((typeof n!="object"||n&&n.splice)&&(i=t,t=n,n={}),t&&t.splice||(i=t,t=[]),ct(n.js),i){var r,u=n.synchronous||!1;l(r,t,i,!0,u)}}function ct(n){if(typeof n=="string")tt(n);else if(n)for(var t=0;t<n.length;t++)tt(n[t])}function tt(n){if(!b[n]){b[n]=1;var i=o.getElementsByTagName("script")[0],t=o.createElement("script");t.src=n;t.onload=t.onreadystatechange=function(){this.readyState&&this.readyState!="loaded"&&this.readyState!="complete"||(t.onload=t.onreadystatechange=null,t.parentNode&&t.parentNode.removeChild(t))};i.parentNode.insertBefore(t,i)}}function lt(n){return ut?n?i.now():Math.round(i.now()):new Date-y}var it=n._jsLoaderAsyncCanary||"c.dom",rt="c.pageReveal",a=!1,v=typeof n._jsLoaderRevealMode=="undefined"?!0:n._jsLoaderRevealMode,i=n.performance,ut=i&&typeof i.now=="function",r=" ----- ",y=((i||{}).timing||{}).navigationStart||+new Date,o=n.document,p=null;try{p=n.localStorage}catch(at){}var c={date:Date,document:o,image:n.Image,localStorage:p,location:o&&o.location,navigator:navigator,pageStart:y,pageTime:lt,screen:n.screen,window:n},u={},f=[],e,w=50,s,b={},k=/^window\.(.+)$/;h.amd={jQuery:1};h.is=function(n){return typeof c[n]!="undefined"};n.define=h;n.require=ht;h.showUserMarks=function(){var n=["Mark Name"+r+"Start time in ms"];return i.getEntriesByType("mark").forEach(function(t){n.push(t.name+r+t.startTime+"ms")}),n.join("\n")};h.showUserMeasures=function(){var n=["Measure name"+r+"Start time in ms"+r+"Duration in ms"];return i.getEntriesByType("measure").forEach(function(t){n.push(t.name+r+t.startTime+"ms"+r+t.duration+"ms")}),n.join("\n")}}(window);define("perfPing",function(){function n(n){require(["w3cTimer"],n)}function t(t){n(function(n){n.mark(t)})}function i(t){n(function(n){n.fire();typeof t=="function"&&t(n.payload)})}return{setMarker:t,getPayLoad:i}});define("perfMarker",["window"],function(n){function o(){return s?t.now()|0:r&&c()-r}function f(n){return typeof n=="function"}var t=n.performance,i;if(!t)return i=function(){},i.now=function(){return 0},i;var s=f(t.now),h=f(t.mark),r=(t.timing||{}).navigationStart,u=n.Date,c=f(u.now)?u.now:function(){return+new u},l,e=n._pageTimings||(n._pageTimings={}),a=!1,i=function(n,i,u,f){var s,c;typeof n!="string"||i&&e[n]&&!u||(s=typeof i=="number",s||(h&&t.mark(n),l&&console.timeStamp(n)),(i||a)&&(c=s?Math.round(i-(f?0:r)):o(),isNaN(c)||(e[n]=c)))};return i.now=o,n._perfMarker=i,i});define("perfMeasure",["window"],function(n){function f(){}function r(n,i,r,f){var e="string",s,h,o;typeof n===e&&typeof i===e&&typeof r===e&&(s=t.getEntriesByName(i),h=t.getEntriesByName(r),s.length>=1&&h.length>=1&&(t.measure(n,i,r),f&&(o=t.getEntriesByName(n),o.length>=1&&(u[n]=Math.round(o[0].duration)))))}function e(){require(["c.onload"],function(){i("TimeFordomComplete","domLoading","domComplete");i("TimeFordomInteractive","domLoading","domInteractive");i("TimeFordomContentLoaded","domContentLoadedEventStart","domContentLoadedEventEnd");i("TimeForloadEvent","loadEventStart","loadEventEnd")})}function i(n,i,r){try{t.measure(n,i,r)}catch(u){console&&console.error("Error while measuring native marker: "+n+", error: "+u)}}var u=n._pageTimings||(n._pageTimings={}),t=n.performance;return typeof t=="object"&&typeof t.measure=="function"&&typeof t.getEntriesByName=="function"?(e(),n._perfMeasure=r,r):f});require(["perfMarker","window"],function(n,t){function a(n){var t=e[n];t&&c[n]&&(o=Math.max(o,t),h++,h>=r&&v())}function s(n){var t=n.getAttribute(l);return t||(t=++p,n.setAttribute(l,t)),t}function v(t){if(!f){i&&clearTimeout(i);var r="TTAFImgs";t?n(r+"_timeout"):n(r,o,null,!0);define("c.ttafImgsReady",1);f=!0}}var h=0,y=1e4,i,f,e={},c={},o=0,p=0,l="data-image-id",r,u=t.imgTTAF=function(t,u,o){if(!f&&t){i||(i=setTimeout(function(){v(!0)},o||y));r=r==null?u:Math.max(r,u);var h=s(t);e[h]=n.now();a(h,t)}};return u.show=function(n){var t=s(n);c[t]=!0;a(t)},u.reset=function(n){var t=s(n);delete e[t]},u.marker=function(t){t&&n(t,!0)},u});require(["window","document"],function(n,t){function h(){var t,r,i;if(n.PerformanceObserver&&(t=n.PerformanceObserver.supportedEntryTypes,t))for(r=t.length,i=0;i<r;i++)if(t[i]==="element")return!0;return!1}function c(t){var i=n._pageTimings[r]||t;return t>i&&(i=t),i}function l(){var i=t.getElementsByTagName("head")[0],n=i.getAttribute("data-required-ttvr");return n?JSON.parse(n):null}function a(){return t.getElementById("eventhubriversection")}function v(){return y()&&!f(r)}function y(){if(i&&i.length>0){for(var n=0;n<i.length;n++)if(!f(i[n]))return!1;return!0}return!1}function f(t){return!(n._pageTimings[t]===undefined||n._pageTimings[t]===-1)}function e(t,e){f(t)||(n._pageTimings[t]=e,(!i||v())&&(n._pageTimings[r]=c(e),define(u,1)))}var r="TTVR",u="c.ttvr",i=l(),s=h(),o;s?(o=new n.PerformanceObserver(function(n){var t=n.getEntries();t.forEach(function(n){var t=Math.floor(n.renderTime);e(n.identifier,t)})}),o.observe({entryTypes:["element"]})):n._ttvrMarker=function(n,t){e(n,t)};i||a()||define(u,1);require(["c.postdeferred"],function(){define(u,1)})});define("evaluate",function(){return window.JSON&&window.JSON.parse||function(n){return eval("("+n+")")}});define("headData",["evaluate","document"],function(n,t){var r=t.getElementsByTagName("head")[0],i,u,f;return r?(i={},u=r.getAttribute("data-js"),u&&(i=n(u)),f=r.getAttribute("data-client-settings"),f&&(i.clientSettings=n(f)),i.xdid=r.getAttribute("data-xd-id"),i.locale=t.getElementsByTagName("html")[0].getAttribute("lang").toLowerCase(),i.currentFlights=((/f:\s*([^;]+)/i.exec(r.getAttribute("data-info"))||{})[1]||"").toLowerCase(),i.userOptOut=((/userOptOut:\s*([^;]+)/i.exec(r.getAttribute("data-info"))||{})[1]||"").toLowerCase(),i):{}});define("requestPageRevealCallback",["window","headData"],function(n,t){function u(u){typeof u=="function"&&(t.ispreload?i?u(i):n.require(["c.pageReveal"],function(n){i=n;u(i)}):u(r))}var i=null,r={didPreload:!1,timeTakenForRevealInMs:0};return u})</script><script data-dapp-detection="">!function(){let e=!1;function n(){if(!e){const n=document.createElement("meta");n.name="dapp-detected",document.head.appendChild(n),e=!0}}if(window.hasOwnProperty("ethereum")){if(window.__disableDappDetectionInsertion=!0,void 0===window.ethereum)return;n()}else{var t=window.ethereum;Object.defineProperty(window,"ethereum",{configurable:!0,enumerable:!1,set:function(e){window.__disableDappDetectionInsertion||n(),t=e},get:function(){if(!window.__disableDappDetectionInsertion){const e=arguments.callee;e&&e.caller&&e.caller.toString&&-1!==e.caller.toString().indexOf("getOwnPropertyNames")||n()}return t}})}}();</script><script async="async" src="//acdn.adnxs.com/ast/ast.js"></script><script async="async" src="//static-global-s-msn-com.akamaized.net/hp-eas/_h/975a7d20/webcore/externalscripts/jquery/jquery-2.1.1.min.js" crossorigin="anonymous" onerror="this.onerror=null;require({ js:'//static-entertainment-eas-s-msn-com.akamaized.net/vi-vn/entertainment/_h/975a7d20/webcore/externalscripts/jquery/jquery-2.1.1.min.js'});"></script><script async="async" src="//static-entertainment-eas-s-msn-com.akamaized.net/vi-vn/money/_sc/js/d7cb56b9-b4fdaae4/direction=ltr.locales=vi-vn.themes=green.dpi=resolution1x/15-f42807-60d1f800/64-4c5ce6-446d9077/9e-a7a255-68ddb2ab/a9-ac9b58-68ddb2ab/f1-d0c6aa-cae48929/c7-47822a-9af6c056/4b-9e5b69-87ff21eb/62-19f06a-c7e6d6ef/ef-f07294-5dc46d56/6a-8ec3ea-68ddb2ab/74-66f840-390811f8/82-877517-68ddb2ab?ver=20201208_29556320&amp;fdhead=msnallexpusers,muidflt17cf,muidflt19cf,muidflt28cf,muidflt47cf,muidflt54cf,muidflt301cf,moneyhz1cf,moneyhz3cf,artgly1cf,gallery2cf,msnapp2cf,1s-bing-news,vebudumu04302020,bbh20200521msncf,msnsports5cf,weather2cf,weather3cf,wfprong1t&amp;csopd=20201002173902&amp;csopdb=20201204234342" crossorigin="anonymous"></script><script>define("headInfo",["document"],function(n){function l(n){var r={},i,t,u;if(!n)return r;for(n=n.substring(1,n.length-1),i=n.split(","),t=0,u=i.length;t<u;t++)if(t in i){var e=i[t],f=e.split(":"),o=f.splice(0,1),s=f.join(":").replace(/^\s+/,"").replace(/\s+$/,"");r[o[0].replace(/^\s+/,"").replace(/\s+$/,"")]=s}return r}var e=n.getElementsByTagName("head")[0],r,u,i,t,o;if(e){if(r={},u=e.getAttribute("data-info"),u)for(i=u.split(";"),t=0,o=i.length;t<o;t++)if(t in i){var h=i[t],s=h.split(":"),c=s.splice(0,1),f=s.join(":");r[c[0]]=f.charAt(0)==="{"?l(f):f.replace(/^\s+/,"").replace(/\s+$/,"")}return r}return{}});define("deviceGroup",function(){return{isTmx:1,isPc:1,isWebKit:1,isChrome:1}});define("measure",function(){return function(n,t){var i=window.getComputedStyle(n);return t?i[t]||i.getPropertyValue(t):function(n){return i[n]||i.getPropertyValue(n)}}});define("deviceInit",function(){function u(i){return n[t(i)]}function f(i){return n[t(i)]=="true"}var n={},t=function(n){return n.toUpperCase()},i,r={capability:u,isCapable:f};return function(u){var f,e;if(i)throw"device was already initialized.";for(f in u)e=u[f],n[t(f)]=e;i=1;define("device",r)}});define("requestAnimationFrame",["window"],function(n){return function(){return n.requestAnimationFrame||n.webkitRequestAnimationFrame||n.mozRequestAnimationFrame||n.oRequestAnimationFrame||n.msRequestAnimationFrame||function(t){typeof t=="function"&&n.setTimeout(t,16.7)}}()});define("requestAnimationFrameBackground",["window","requestAnimationFrame","headData"],function(n,t,i){function u(i){typeof i=="function"&&(n.define.is(r)?t(i):setTimeout(i,1))}var r="c.pageReveal";return i.ispreload&&!n.define.is(r)?u:t});define("mediator",function(){function i(n){return t[n]||(t[n]=new r),t[n]}function r(){var n={};return{pub:function(t,i){var u=n[t],r;if(u)for(r=0;r<u.length;r++)u[r](i)},sub:function(t,i){if(typeof i=="function"){var r=n[t];r||(r=[],n[t]=r);r.push(i)}},unsub:function(t,i){var u=n[t],r;if(u)for(r=0;r<u.length;r++)u[r]===i&&u.splice(r--,1)}}}var n=new r,t={};return{pub:n.pub,sub:n.sub,unsub:n.unsub,pubChannel:function(n,t,r){i(t).pub(n,r)},subChannel:function(n,t,r){i(t).sub(n,r)},unsubChannel:function(n,t,r){i(t).unsub(n,r)}}});define("mediaQueryMatch",["device","deviceGroup","mediator","requestAnimationFrame","window"],function(n,t,i,r,u){function s(){function e(n,t){var i=n.exec(t);return i?i[1]*16:null}function n(){r(function(){t=u.innerWidth;f=u.innerHeight;for(var n=0;n<o.length;n++)h(o[n])})}function h(n){var r=p(n),t,i;if(n.matches!=r)for(n.matches=r,i=0;t=n.queryFunctions[i];i++)typeof t=="function"&&t()}function p(n){var i=!n.maxWidth||t<=n.maxWidth,r=!n.minWidth||t>=n.minWidth,u=!n.maxHeight||f<=n.maxHeight,e=!n.minHeight||f>=n.minHeight;return i&&r&&u&&e}function c(n){return{isMatching:function(){return!1},addListener:function(){},matches:!1,media:n,queryFunctions:[]}}var l=/min\-width\:\s*(\d+(\.\d+)?)/,a=/max\-width\:\s*(\d+(\.\d+)?)/,v=/min\-height\:\s*(\d+(\.\d+)?)/,y=/max\-height\:\s*(\d+(\.\d+)?)/,t,f,o=[],s;return require(["jquery"],function(t){t(u).resize(function(){clearTimeout(s);s=setTimeout(n,50)});require(["c.deferred"],n);setTimeout(n,500);i.subChannel("update","mediaQuery",n)}),function(i){if(!i)return c(i);var r={addListener:function(n){typeof n=="function"&&r.queryFunctions.push(n)},isMatching:function(){return n(),r.matches},matches:!1,media:i,queryFunctions:[]};return(r.minWidth=e(l,i),r.maxWidth=e(a,i),r.minHeight=e(v,i),r.maxHeight=e(y,i),!r.minWidth&&!r.maxWidth&&!r.minHeight&&!r.maxHeight)?c(i):(t=u.innerWidth,f=u.innerHeight,h(r),o.push(r),r)}}function h(n){var t=f(n);return t.isMatching=function(){return t.matches},t}var f=u.msMatchMedia||u.matchMedia,e=f?h:null,o=n.isCapable("UseCustomMatchMedia");return!o&&e||s()});define("scaledView",[],function(){return{addListener:function(){},removeListener:function(){},isScaled:function(){return!1}}});require(["measure","scaledView","document"],function(n,t,i){function u(){r=f.rem=parseFloat(n(i.getElementsByTagName("head")[0],"font-size"))}function f(n){return n*r}function e(n){return n/r}var r;t.addListener(u);u();define("remToPixel",function(){return f});define("pixelToRem",function(){return e})});define("viewAwareInit",["deviceGroup","pageTime","mediaQueryMatch","document","remToPixel"],function(n,t,i,r){return function(t){function f(n,t){var r,u,f;n&&(r=n.match(/calc\((.*?)\)/),r&&r.length==2&&(n=n.replace(r[0],eval(r[1]))),u=i(n),f=u.isMatching(),f&&(e=t),u.addListener(function(){u.matches&&s(t)}),h.push({mq:u,viewValue:t}))}function s(n){e=n;for(var t=0;t<o.length;t++)o[t](e)}var u={NONE:0,SIZE1COLUMN:1,SIZE2COLUMN:2,SIZE3COLUMN:4,SIZE4COLUMN:8,SIZE12COLUMN:3,SIZE23COLUMN:6,SIZE34COLUMN:12,SIZE234COLUMN:14,SIZE1ROW:256,SIZE1ROWSIZE1COLUMN:257,SIZE1ROWSIZE2COLUMN:258,SIZE1ROWSIZE3COLUMN:260,SIZE1ROWSIZE4COLUMN:264,SIZE2ROW:512,SIZE2ROWSIZE1COLUMN:513,SIZE2ROWSIZE2COLUMN:514,SIZE2ROWSIZE3COLUMN:516,SIZE2ROWSIZE4COLUMN:520,ALL:783},o=[],h=[],e=n.isMobile?u.SIZE1ROWSIZE1COLUMN:u.SIZE2ROWSIZE4COLUMN;f(t.size1rowsize1column,u.SIZE1ROWSIZE1COLUMN);f(t.size2rowsize1column,u.SIZE2ROWSIZE1COLUMN);f(t.size1rowsize2column,u.SIZE1ROWSIZE2COLUMN);f(t.size2rowsize2column,u.SIZE2ROWSIZE2COLUMN);f(t.size1rowsize3column,u.SIZE1ROWSIZE3COLUMN);f(t.size2rowsize3column,u.SIZE2ROWSIZE3COLUMN);f(t.size1rowsize4column,u.SIZE1ROWSIZE4COLUMN);f(t.size2rowsize4column,u.SIZE2ROWSIZE4COLUMN);s(e);define("viewAware",{listen:function(n){typeof n=="function"&&(o.push(n),n(e))},views:u,currentView:function(){return e}})}});define("screenDpiImpl",["window"],function(n){return function(){return n.devicePixelRatio||1}});define("dpi",["screenDpiImpl","headData","measure","deviceGroup","document","window","location"],function(n,t,i,r,u,f,e){var v=t.dpi||1,o={screen:1,detected:t.ddpi,override:t.dpio,forceServerDpi:t.forcedpi||!(typeof navigator.msManipulationViewsEnabled=="undefined"?!0:navigator.msManipulationViewsEnabled),server:v,client:v,dpiMultiplier:1,sizeMultiplier:1,refresh:!1},h,w,y,s,c,p,l,a;if(e.href.indexOf("nodpi=1")==-1&&(o.screen=n(o)),h=r.isMobile?[1.5,2.25,2.4,2.7]:[1,1.4,1.8,2],w=/<link[^>]*rel="stylesheet"[^>]*href="([^"]*)"[^>]*\/>/ig,o.forceServerDpi===!0)t.dpi=t.ddpi;else if(o.server!=o.screen){for(y=o.screen,s=0;s<h.length;s++)if(c=h[s],y<=c||s==h.length-1){o.dpiMultiplier=(o.client=c)/o.server;break}o.client!=o.server&&(p="dpio",l=p+"=",t&&t.clientSettings&&!t.clientSettings.functionalonly_cookie_experience&&(u.cookie=l+o.client+";path=/"),o.refresh&&e.href.indexOf("dpir=1")==-1&&e.href.indexOf(l)==-1&&require(["navigation"],function(n){var t=e.href.replace(/dpio=[\d.]*/,"");t+=(t.indexOf("?")==-1?"?":"&")+"dpir=1";n.navigate(t,!0)}))}return a=parseFloat(i(u.documentElement,"font-size")),a&&(o.sizeMultiplier=a/10/o.client),o});define("escape",["window"],function(n){function r(t){return t!=null&&n.encodeURI(t)||""}function u(t){return t!=null&&n.encodeURIComponent(t)||""}function f(n){return n!=null&&(""+n).replace(t,function(n){return i[n]||""})||""}var t=/["&'\/<>]/g,i={'"':"&quot;","&":"&amp;","'":"&#39;","/":"&#47;","<":"&lt;",">":"&gt;"};return{url:r,urlPart:u,html:f}});define("classList",function(){function i(n){return t[n]||(t[n]=new RegExp("(\\s|^)"+n+"(\\s|$)"))}function n(n,t){return n?n.classList?n.classList.contains(t):n.className?n.className.match(i(t)):!1:!1}function r(t,i){t&&(t.classList?t.classList.add(i):n(t,i)||(t.className+=" "+i))}function f(t,i){t&&(t.classList?t.classList.toggle(i):n(t,i)?u(t,i):r(t,i))}function u(t,r){t&&(t.classList?t.classList.remove(r):n(t,r)&&(t.className=t.className?t.className.replace(i(r)," "):!1))}var t=[];return{add:r,remove:u,toggle:f,contains:n}});define("viewport",["mediator","requestAnimationFrame","window","document"],function(n,t,i,r){function kt(){l=at();a=lt();(l!=s||a!=f)&&(u=!0,e=!0)}function g(){return{left:s,right:et,top:f,bottom:ot,width:h,height:c}}function ht(){u&&(s=l||at(),f=a||lt(),l=a=null,!nt&&f>yt&&(nt=!0,setTimeout(function(){define("c.scrolled",1)},ft)));o&&(h=i.innerWidth||r.documentElement.clientWidth,c=i.innerHeight||r.documentElement.clientHeight);(u||o)&&(et=s+h,ot=f+c);u=o=!1}function w(){if(e){pt=new Date;e=!1;var i=o,r=u,l=h,a=c,v=s,y=f;ht();i=i&&(a!=c||l!=h);r=r&&(v!=s||y!=f);i||r?(b||(b=setTimeout(function(){b=0;var t=g();n.pub(tt,t);r&&n.pub(it,t);i&&n.pub(rt,t)},ft)),dt(),setTimeout(w,ut)):t(w)}else t(w)}function dt(){v&&(st=+new Date,y||(y=setTimeout(function t(){y=v=!1;var i=new Date-st;i>d?n.pub(bt,k):y=setTimeout(t,d-i)},d)))}function ct(){u=!0;o=!0;e=!0}function lt(){if(typeof pageYOffset!="undefined")return pageYOffset;var t=r.body,n=r.documentElement;return n=n.clientHeight?n:t,n.scrollTop}function at(){if(typeof i.pageXOffset!="undefined")return i.pageXOffset;var t=r.body,n=r.documentElement;return n=n.clientWidth?n:t,n.scrollLeft}function gt(n){for(var i=null,t;n&&n.nodeName!="BODY"&&n.nodeName!="HTML";){if(t=n.getAttribute(wt),t){t=t.split(";");i={x:parseInt(t[0])||0,y:parseInt(t[1])||0};break}n=n.parentNode}return i}function ni(n,t,i,r){var u=n.getBoundingClientRect();if(!u.top&&!u.right&&!u.bottom&&!u.left)return 0;r||(r=g());var o=r.width*(t||0),s=r.height*(i||0),h={left:-o,right:r.width+o,top:0-s,bottom:r.bottom+s},f={left:u.left,right:u.right,top:u.top,bottom:u.bottom},e=gt(n.parentNode);return e&&(f.left+=e.x,f.right+=e.x,f.top+=e.y,f.bottom+=e.y),ti(h,f)}function ti(n,t){return!(t.left>n.right||t.right<n.left||t.top>n.bottom||t.bottom<n.top)}function vt(n,t){i.addEventListener(n,t,!1)}var e=!0,u=!0,o=!0,l=null,a=null,yt=10,nt,tt="viewport_change",it="viewport_scroll_change",rt="viewport_size_change",ut=parseInt("")||200,ft=50,b,s=0,et=0,f=0,ot=0,h=0,c=0,pt,wt="data-offset",k="",v=!1,y=0,d=1e3,st,bt="ViewabilityUpdatedEvent",p;return ht(),require(["c.dom"],ct),p="c.deferred",require([p],function(){i.setInterval(kt,ut);t(w)}),require([p],ct),vt("resize",function(){v=!0;k="resize";o=!0;e=!0}),vt("scroll",function(){v=!0;k="scroll";u=!0;e=!0}),{getDimensions:function(){return g()},changeEventName:tt,sizeChangeEventName:rt,scrollChangeEventName:it,isInViewport:ni,deferredCanaryName:p}});require(["window"],function(n){n._llic=function(n){require(["imgSrc"],function(t){t.checkLoad(n)})}});define("imgSrc",["viewAware","measure","dpi","evaluate","mediator","viewport","classList","window","document","image","headData","logging","perfMarker"],function(n,t,i,r,u,f,e,o,s,h,c,l,a){function vi(){u.sub(f.changeEventName,function(n){var t=Math.abs(n.left-b.left+n.width-b.width),i=Math.abs(n.top-b.top+n.height-b.height);(t>yt()||i>pt())&&(yt=function(){return n.width/4},pt=function(){return n.height/4},b=n,k())})}function yi(){p=[]}function pi(n,t){var i=n.getAttribute(t);if(i)try{return r(i)}catch(u){l.error("[imgSrc] error evaluating the '"+t+"' attribute: '"+i+"'",u)}}function wi(n,t){var u=!1,i=ht(n),r;return i&&i.src&&t&&typeof t.find=="function"&&typeof t.filter=="function"&&(r=t.find("img[data-src]").filter(function(){return this.imgSrcObj&&this.imgSrcObj.loadedSrc==i.src}),r.length&&(i.loadingSrc=i.src,n.imgSrcObj=i,ri(n,i,r[0]),u=!0)),u}function ht(n,t){var i=pi(n,li),f,r,u;if(i){if(f=i.dpi||1,i=i[v]!==t?i[v]:i[y]!==t?i[y]:i["default"],r=typeof i,r=="string")i={src:i};else if(r!="object"||!i)return null;return i.dpi=f,i.src?(u=i.src.indexOf("//"),u>0&&(i.src=i.src.substring(u)),i.src=gi(i.src,oi)):i.src=kt,i}return null}function gt(n,t){var i,r;return dt?(n.onload=null,i=ht(n),i&&(r=bi(n,i,t),r&&d(n,i,!0)),r):!1}function bi(n,t,i){return dt==2?!0:t.load=="wait"||t.load=="defer"?!1:e.contains(n,"wait")?!1:e.contains(n,"defer")?!1:n.getAttribute(rt)?!1:ni(n)?ct(n,t)?(i||f.isInViewport(n,0,0))?!0:!1:!1:!1}function ki(t){var i=nt&&nt!=t;nt=t;switch(t){case n.views.SIZE1ROWSIZE1COLUMN:v="size1rowsize1column";y="size1column";break;case n.views.SIZE2ROWSIZE1COLUMN:v="size2rowsize1column";y="size1column";break;case n.views.SIZE1ROWSIZE2COLUMN:v="size1rowsize2column";y="size2column";break;case n.views.SIZE2ROWSIZE2COLUMN:v="size2rowsize2column";y="size2column";break;case n.views.SIZE1ROWSIZE3COLUMN:v="size1rowsize3column";y="size3column";break;case n.views.SIZE2ROWSIZE3COLUMN:v="size2rowsize3column";y="size3column";break;case n.views.SIZE1ROWSIZE4COLUMN:v="size1rowsize4column";y="size4column";break;default:v="size2rowsize4column";y="size4column"}i&&k()}function di(n){return(n||s).getElementsByTagName("img")}function k(n){var o,u,i;if(st)for(o=0,u=di(n),i=0;i<u.length;i++){var t=u[i],r=ui(t),s=r&&r.load!="wait"&&!e.contains(t,"wait")&&!t.getAttribute(rt)&&ct(t,r)&&(e.contains(t,"defer")||ni(t)&&f.isInViewport(t,hi,ci));s&&(o++,d(t,r))}}function ni(n){do{if(t(n,"display")=="none")return!1;n=n.parentNode}while(n&&n.nodeName!="BODY");return!0}function gi(n,t){var i=n.match(ai);return i&&i[w]!=t?n.replace(i[0],i[0].replace(i[w],t)):n}function nr(n,t){var r=n.match(wt),u,i,f;return r&&(u=r[w]*t+.5|0,n=n.replace(r[0],r[0].replace(r[w],u))),i=n.match(bt),i&&(f=i[w]*t+.5|0,n=n.replace(i[0],i[0].replace(i[w],f))),n}function tr(){it=clearTimeout(it)}function ti(){it=setTimeout(function(){var t,n;for(lt=!0,t=0;t<p.length;t++)n=p[t],n.showFn&&(n.showFn(),n.showFn=null,n.shown=!0)},si)}function ii(n,t,i){var u=n.imgSrcObj,f,e,o,r;if(i.src==u.loadingSrc){if(lt||u.shown){t();return}for(u.showFn=t,f=0;f<u.id;f++)if(e=p[f],e.isInViewport&&!e.shown){if(e.loadingSrc.load!=u.loadingSrc.load)continue;ti();return}for(o=u.id;o<p.length;o++)if(r=p[o],!r.shown&&r.isInViewport)if(r.showFn)tr(),r.showFn(),r.showFn=null,r.shown=!0;else{ti();return}}}function ir(n,t,i){var r=g(n);t.src==r.loadingSrc&&(t.lowq&&i.loadingSrc==t.lowq?(t.lowqLoaded=!0,e.remove(n,vt),d(n,t)):(n.src=t.src,e.remove(n,et),e.remove(n,ot),e.add(n,ft)))}function ri(n,t,r){var f=g(n),u;t.src==f.loadingSrc&&(f.loadedSrc=t.src,i.sizeMultiplier>1&&(n.width=r.width*i.sizeMultiplier+.5|0),n.removeAttribute("height"),u=n.getAttribute("data-elementtiming"),u&&n.setAttribute("elementtiming",u),n.src=r.src,n.getAttribute("data-record-deferred-loadtime")==="true"&&n.setAttribute("data-load-time",a.now()),t.lowq&&r.loadingSrc==t.lowq?(t.lowqLoaded=!0,e.remove(n,vt),d(n,t)):(e.add(n,ot),e.remove(n,ft),e.remove(n,et)))}function ct(n,t){if(!t||!t.src)return!1;var i=g(n);return i.loadedSrc!=t.src&&t.src!=i.loadingSrc}function ui(n,t){if(!n)return null;if(t)t.src||(t={src:t});else{if(t=ht(n),!t)return null;var r=t.dpi||1;r!=i.client&&(t.src=nr(t.src,i.client/r))}return t}function fi(n,t){n&&(t=ui(n,t),ct(n,t)&&d(n,t))}function g(n){var t=n.imgSrcObj;return t||n.nodeName!="IMG"||(t={img:n,id:p.length},n.imgSrcObj=t,p[n.imgSrcObj.id]=t),t}function d(n,t){var r=g(n,t),u,i;r.isInViewport===undefined&&(r.isInViewport=!0);r.loadingSrc=t.src;t.w&&t.h?n.setAttribute(ut,"width:"+t.w+"rem;height:"+t.h+"rem;"):n.hasAttribute(ut)&&n.removeAttribute(ut);e.add(n,et);e.remove(n,ot);e.remove(n,ft);u=(t.lowqLoaded?null:t.lowq)||t.src;i=new h;i.onload=function(){i.onload=null;i.onerror=null;ii(n,function(){ri(n,t,i)},t)};i.onerror=function(){i.onload=null;i.onerror=null;ii(n,function(){ir(n,t,i)},t)};i.src=i.loadingSrc=u}var nt,v,y,tt=(c.clientSettings||{}).imgsrc||{},oi=tt.quality_high||60,rr=tt.quality_low||5,si=tt.order_timeout||1e3,hi=1,ci=1,lt=!1,it,at=100*i.client,rt="data-noupdate",li="data-src",ut="style",ft="err",et="loading",ot="loaded",vt="lowq",yt=function(){return 10},pt=function(){return 10},p=[],w=2,wt=/([?&]w=|_w)(\d+)/,bt=/([?&]h=|_h)(\d+)/,ai=/([?&]q=|_q)(\d+)/,kt="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAEALAAAAAABAAEAAAIBTAA7",dt={all:0,auto:1,none:2}[(location.search.match(/[?&]llibf=([^&#]+)/i)||[])[1]]||1,b,st;return o._llic=gt,b=f.getDimensions(),n.listen(ki),st=!1,require(["c.deferred"],function(){st=!0;vi();k()}),o.loadDeferredImages=k,{go:fi,reset:fi,noUpdate:rt,data:kt,checkLoad:gt,isInViewport:f.isInViewport,loadInViewport:k,dataOffsetAttr:"data-offset",force:wi,clearImages:yi}});define("imageLoad",["imgSrc","classList","document","window"],function(n,t,i,r){function a(){s();n.isInViewport?y():f(i.querySelectorAll("main img[data-src]"),c)}function s(n){u(".ip .swipenav>li:first-child+li img,.carousel .slides li+li img","defer",n);u(".sip .swipenav>li:first-child+li img,.carousel .slides li+li img","defer",n);u(".ip .swipenav>li+li+li img","wait",n);u(".sip .swipenav>li+li+li img","wait",n);u(".todaystripe .pipedheadlinelistwithimage img","defer",n)}function v(n,t){typeof n=="string"&&(n=i.querySelector(n));s(n);o(n,t)}function y(){e=!1;h(i.getElementById("precontent"));f((i.getElementById("main")||{}).childNodes,p);h(i.getElementById("aside"))}function p(i){var r=!1,u;return!t.contains(i,"mestripeouter")&&i.querySelector("img[data-src]")&&(u=n.isInViewport(i,0,0),u?(e=!0,o(i)):e&&(r=!0)),r}function h(t){var i=!1;return t&&t.querySelector("img[data-src]")&&n.isInViewport(t,0,0)&&(i=!0,o(t)),i}function o(n,t){f(n.querySelectorAll("img[data-src]"),function(n){c(n,t)})}function c(n){var i;return n&&(!n.src||!t.contains(n,"loaded")&&!t.contains(n,"loading"))&&l(n,i)?!0:!1}function f(n,t){var i,r;if(n&&n.length)for(i=0;r=n[i];++i)if(r.nodeType==1&&t(r))break}function u(n,r,u){f((u||i).querySelectorAll(n),function(n){t.add(n,r)})}var l=n.checkLoad||r._llic,e;return{cleanup:a,module:v}});var c="c.dom";require(["jquery","imgSrc","mediator",c],function(n,t,i){function r(){n("#main").children().addClass("loaded");t.loadInViewport(n("#main")[0]);i.pub("revealLoaded")}r()});define("autoSizeFlex",["jquery","jqBehavior","mediator","pixelToRem","dir.tokens"],function(n,t,i,r,u){function f(n){function e(){var i;(t=n.children(":visible").last(),f.length&&t.length)&&(i=u.ltr?t.offset().left-n.offset().left+t.outerWidth():f.offset().left-t.offset().left+f.outerWidth(!0),i!==n.width()&&n.width(r(i)+"rem"))}var t,f=n.children().first();return i.sub("tabChanged",e),{setup:e,update:e}}return t(f)});require(["binding","c.dom"],function(n){n("autoSizeFlex",".autosizeflex").all()});define("allPageBindings",function(){return function(n){var t=function(t){t(n)};require(["pageBindings"],t);require(["pageBindings.pc"],t);require(["pageBindings.pc-!ms.ie10plus"],t)}});require(["allPageBindings"],function(n){n("html")});define("navigation",["escape","location","document"],function(n,t,i){function o(t,i,r){var u=t[i],e,f;if(!u||u.length===0)return"";for(e="",f=0;f<u.length;f++)u[f]&&(e=e+r+i+"="+n.urlPart(u[f]),r==="?"&&(r="&"));return e}function u(n,t,i){var s=function(n){return n=n.replace(/\+/g," "),decodeURIComponent(n)},u={},o,e;if(n)for(n=n.split("#")[0],o=n.split("&"),e=0;e<o.length;e++){var h=o[e].split("="),r=h[0],f=h[1];i&&(r=s(r),f&&(f=s(f)));t||r==="item"?(u[r]||(u[r]=[]),u[r].push(f)):u[r]=f}return u}function f(n){var t=i.createElement("a");return t.href=n,{protocol:t.protocol,host:t.host,hostName:t.hostname,port:t.port,path:t.pathname,hash:t.hash,query:t.search,origin:t.origin}}function e(n){return f(n).hostName}var r={getUrl:function(n){return r.filter?r.filter(n):n},navigate:function(n,i){r.filter&&(n=r.filter(n));i?t.replace(n):t.href=n},getHostName:e,parseUrl:f,isLocal:function(n){var i=e(n);return!i||t.hostname==i},getParams:u,getParamsFromUrl:function(n,t,i){var r=n.split("?")[1];return u(r,t,i)},mergeQueryStringParams:function(t,i){var s,f,e,h,r,c;if(i){if(s=t.split("?"),s[1]){f=u(s[1],!1,!0);for(r in i)f[r]=i[r]}else f=i;t=s[0];e="?";h="item";for(r in f)r!==h&&(t+=f[r]?e+n.urlPart(r)+"="+n.urlPart(f[r]):e+n.urlPart(r),e==="?"&&(e="&"));c=o(f,h,e);t=t+c}return t},filter:null};return r});require(["logging","measure","document","c.onload"],function(n,t,i){var e=t(i.getElementsByTagName("head")[0]),o=e("boxSizing"),r;if(o!="border-box"){var u="",f=i.getElementsByTagName("head")[0];f?(r=f.querySelectorAll("link[href*='/_sc/css/']"),u=r.length===0?"No css found.":r.length===1?r[0].href:"Multiple css urls found: "+r[0].href+" "+r[1].href):u="No head element found.";n.fatalError("C5001 Css was not loaded correctly. "+u)}});define("logging",["navigation","headData","requestAnimationFrame","window","document","pageTime","escape"],function(n,t,i,r,u,f,e){function ut(n,t){if(n.addEventListener)n.addEventListener("error",t,!1);else if(n.onerror){var i=n.onerror;n.onerror=function(n,r,u,f,e){return i(n,r,u,f,e),t(n,r,u,f,e)}}else n.onerror=t}function ft(){if(!o&&(o=n.getUrl(t.clientSettings.base_url+"_log"),!/[?&]fdhead=[^&#]*/i.test(o))){var i=(/\bf\:([^;]*)/.exec(u.getElementsByTagName("head")[0].getAttribute("data-info"))||{})[1]||"";i&&(o+=(o.indexOf("?")>0?"&":"?")+"fdhead="+i)}return o}function g(){c&&k&&!p&&(p=setTimeout(function(){var h,l,o,i,f,e;if(p=0,s.length){if(h=ft(),l="POST",r.hybridEnabled===1&&(d=!0),o=[],i=u.querySelectorAll&&u.querySelectorAll("[data-anadid]"),i&&i.length)for(f=0;f<i.length;f++)o.push(i[f].getAttribute("data-anadid"));e={aid:t.clientSettings.aid,v:t.clientSettings.v,messages:s,isInstart:d,adIds:o};e=JSON.stringify(e);var v=JSON.stringify({data:e}),n=new XMLHttpRequest;n.onload=function(){n.status!=200&&(a("error","[506] Could not log, request status: "+n.status+"; response text: "+n.responseText),c=!1)};n.open(l,h,!0);n.setRequestHeader("Content-Type","application/json;charset=UTF-8");n.send(v);s=[]}},2e3))}function l(n,t){return(t==b&&n.indexOf("Script error")>=0&&(t=h),t==h)?"warn":t==y?"info":(c&&(s.push({m:e.urlPart(n),t:t,d:f()}),g()),t==y?"info":t==h?"warn":"error")}function a(n,t,i){if(r.console){if(!i&&n=="info")return;if(!i&&n=="warn")return;var u=console[n];u&&typeof u=="function"?console[n](t):console.log&&console.log(t)}}function v(n){var r=[],t,i;if(n)for(t=0;t<n.length;++t)i=nt(n[t]),i&&r.push(i);return r.join(", ")}function nt(n,t,i,u,f){var o=(n==null||typeof n=="string"?n:n.message||n.description)||"",e,s;return!o&&(n!=null&&(typeof n=="object"&&n.toString()=="[object Event]"?(e=r.event,e&&e.type=="error"&&(o=e.errorMessage,t=e.errorUrl,i=e.errorLine,u=e.errorCharacter)):o=n.toString()),!o)?"":(t=n.url||n.filename||t,i=n.lineno||i,u=n.colno||u,s=n.stack||n.error&&n.error.stack,o.trim()+(f||"")+(i?"\nLine="+i:"")+(u?"\nColumn="+u:"")+(t?"\nScriptUrl="+t:"")+(s?"\nStack="+s:""))}function et(){var n=v(arguments);l(n,it);i(function(){var n=u.location,i=e.html(n.protocol+"//"+n.host),f=e.url(n.href),o=function(n){var i="",r,t;if(n)for(r=n.length,t=0;t<r;t++)(t===8||t===12||t===16||t===20)&&(i+="-"),i+=n[t];return i};u.getElementsByTagName("body")[0].innerHTML="<style>body{font-family:Arial;margin-left:40px}img{border:0 none}#content{margin-left:auto;margin-right:auto}#message h2{font-size:20px;font-weight:normal;color:#000;margin:34px 0 0 0}#message p{font-size:13px;color:#000;margin:7px 0 0 0}#errorref{font-size:11px;color:#737373;margin-top:41px}<\/style><div id='content'><div id='message'><h2>Trang này hiện không khả dụng<\/h2><p>Việc này thỉnh thoảng có thể xảy ra nếu bạn gặp sự cố kết nối internet hoặc đang chạy phần mềm/plugin gây ảnh hưởng đến lưu lượng truy cập internet.<br/><br/><a href=\""+e.html(f)+'" onclick="window.location.reload(true)">Nhấp vào đây<\/a> để thử lại trang này hoặc truy cập: <a href="'+i+'">'+i+"<\/a><\/p><\/div><div id='errorref'><span>Ref 1: "+e.html(o(t.clientSettings.aid))+"&nbsp;&nbsp;&nbsp;Ref 2: "+e.html(t.clientSettings.sid||"000000")+"&nbsp;&nbsp;&nbsp;Ref 3: "+e.html((new r.Date).toUTCString())+"<\/span><\/div><\/div>"});ot({errId:1512,errMsg:n})}function ot(n){require(["track"],function(t){var i={errId:n.errId,errMsg:n.errMsg,reportingType:0};t.trackAppErrorEvent(i)})}function tt(){var n=v(arguments);a(l(n,b),n,!0)}function st(){var n=v(arguments);a(l(n,h),n)}function ht(){var n=v(arguments);a(l(n,y),n)}function ct(n){(r.console||{}).timeStamp?console.timeStamp(n):(r.performance||{}).mark&&r.performance.mark(n)}var w=0,it=-1,b=0,h=1,y=2,s=[],p,k,rt,o,d=!1,c=Math.random()*100<=10;return ut(r,function(n,t,i,r){return w++,n=nt(n,t,i,r," [ENDMESSAGE]"),n&&tt("[SCRIPTERROR] "+n),!0}),c&&require(["jquery","c.deferred"],function(n){k=!0;rt=n;s.length&&g()}),{error:tt,fatalError:et,unhandledErrorCount:function(){return w},perfMark:ct,warning:st,information:ht}});require(["viewAwareInit"],function(n){n({size2row:"(min-height: 48.75em)",size1row:"(max-height: 48.74em)",size4column:"(min-width: 79em)",size3column:"(min-width: 58.875em) and (max-width: 78.99em)",size2column:"(min-width: 43.75em) and (max-width: 58.865em)",size2rowsize4column:"(min-width: 79em) and (min-height: 48.75em)",size2rowsize3column:"(min-width: 58.875em) and (max-width: 78.99em) and (min-height: 48.75em)",size2rowsize2column:"(max-width: 58.865em) and (min-height: 48.75em)",size1rowsize4column:"(min-width: 79em) and (max-height: 48.74em)",size1rowsize3column:"(min-width: 58.875em) and (max-width: 78.99em) and (max-height: 48.74em)",size1rowsize2column:"(max-width: 58.865em) and (max-height: 48.74em)"})});require(["deviceInit"],function(n){n({AllowTransform3d:"false",AllowTransform2d:"true",RtlScrollLeftAdjustment:"fromLeft",ShowMoveTouchGestures:"true",SupportFixedPosition:"true",UseCustomMatchMedia:null,Viewport_Behavior:"Default",Viewport_Landscape:null,Viewport:"width=device-width,initial-scale=1.0",IsMobileDevice:"false"})})</script><meta property="sharing_url" content="https://www.msn.com/vi-vn/money/currencyconverter"><meta property="og:url" content="https://www.msn.com/vi-vn/money/currencyconverter"><meta property="og:title" content="Đổi tiền - MSN Tài chính "><meta property="twitter:card" content="summary_large_image"><meta property="og:type" content="website"><meta property="og:site_name" content="MSN"><meta property="og:image" content="https://static-entertainment-eas-s-msn-com.akamaized.net/sc/c6/519670.jpg"><link rel="shortcut icon" href="//static-entertainment-eas-s-msn-com.akamaized.net/sc/b1/f9e423.ico"><style>.mobile .galleryinfo .img-divider{display:none}.homepage.tmx.pc.chrome #main .one-col,.homepage.tmx.pc.chrome #main .two-col,.homepage.tmx.pc.chrome #main .three-col{margin-right:-.016rem;margin-left:-.016rem}.homepage.midlevel .pagingsection>button.show,.channelplayerpage.midlevel .pagingsection>button.show{display:none}.settings.start.tmx.pc .globalsettings .social.twitter{display:none}@media screen and (max-width:52.303em){#irisbanner .irisbanner header>a{max-width:33rem}}.tmx.pc.webkit.chrome .msame_Header_pic{height:5rem}</style>
        
        


        

        
            <script>window._perfMarker && window._perfMarker("TimeToHeadEnd"); window._perfMeasure && window._perfMeasure("TimeForHead", "TimeToHeadStart", "TimeToHeadEnd", true);</script>
    </head>

    <body class="currenciespage green tmx pc webkit chrome chrome76plus fltmsnallexpusers fltmuidflt17cf fltmuidflt19cf fltmuidflt28cf fltmuidflt47cf fltmuidflt54cf fltmuidflt301cf fltmoneyhz1cf fltmoneyhz3cf fltartgly1cf fltgallery2cf fltmsnapp2cf flt1s-bing-news fltvebudumu04302020 fltbbh20200521msncf fltmsnsports5cf fltweather2cf fltweather3cf fltwfprong1t irisbactive-top scroll-up">
            <script>window._perfMarker && window._perfMarker("TimeToBodyStart");</script>

            <script>
                require(["headData", "pageInstance", "mediator"], function (headData, pageInstance, mediator)
                {
                    var url = '//c.msn.com/c.gif?udc=true&rid=39f31a574880406c91fe78e6f524d229&rnd=637432057289100471&rf=&tp=https%253A%252F%252Fwww.msn.com%252Fvi-vn%252Fmoney%252Fcurrencyconverter&di=19546&lng=vi-vn&activityId=39f31a574880406c91fe78e6f524d229&d.dgk=tmx.pc.webkit.chrome.chrome76plus&d.imd=0&st.dpt=FinanceCurrencyConverter&st.sdpt=&subcvs=finance&pg.n=currencies&pg.t=data&pg.c=&pg.p=prime&anoncknm=&issso=0&aadState=0';
                    if (headData && headData.clientSettings && headData.clientSettings.static_page)
                    {
                        mediator.pub(pageInstance.eventName);
                        var rid = pageInstance.getActivityId();
                        url = url.replace(/([?&]rid=)[^&#]*/i, "$1" + rid);
                    }
 
                    var img = new Image();
                    img.onload = img.onerror = function ()
                    {
                        img.onload = img.onerror = null;
                    };
                    img.src = url;
                    
 });
</script>
<script>
/*<![CDATA[*/
 require(["jsll-bootstrap"],function(jsllbt){jsllbt.initialize({"isLoggedIn":"False","logLevel":"1","jsError":"false","env":"prod","appId":"MSN","endpoint":"https://web.vortex.data.msn.com/collect/v1"});});require(["track","track.generic","c.track.mobi"],function(t,g,o){t.extend({"sitePage":{"department":"FinanceCurrencyConverter","subDepartment":"","channel":"finance","page_name":"currencies","page_type":"data","page_product":"prime","storeocid":"msn","pageUrl":"https%3A%2F%2Fwww.msn.com%2Fvi-vn%2Fmoney%2Fcurrencyconverter","autoRefresh":"0","requestId":"39f31a574880406c91fe78e6f524d229","serverImpressionGuid":"39f31a574880406c91fe78e6f524d229","canvas":"Browser","vertical":"finance","entityId":"","entityCollectionId":"","entitySrc":"","cvAuthor":"","d_dgk":"tmx.pc.webkit.chrome.chrome76plus","d_imd":"0","cvPartner":"","cvPublcat":"","provid":"","templ":"","pageIndex":"","pageTotalCount":"","isStaticPage":"False","pageVersion":"15","contentType":"unknown_use_metadata_to_set_the_content_type","isCorePV":"","chartBeatUID":"42635","chartBeatDomain":"msn.com","chartBeatBase":"https://static.chartbeat.com","otfURL":"//otf.msn.com/c.gif?","flightid":"msnallexpusers,muidflt17cf,muidflt19cf,muidflt28cf,muidflt47cf,muidflt54cf,muidflt301cf,moneyhz1cf,moneyhz3cf,artgly1cf,gallery2cf,msnapp2cf,1s-bing-news,vebudumu04302020,bbh20200521msncf,msnsports5cf,weather2cf,weather3cf,wfprong1t","exa":"msnallexpusers,muidflt17cf,muidflt19cf,muidflt28cf,muidflt47cf,muidflt54cf,muidflt301cf,moneyhz1cf,moneyhz3cf,artgly1cf,gallery2cf,msnapp2cf,1s-bing-news,vebudumu04302020,bbh20200521msncf,msnsports5cf,weather2cf,weather3cf,wfprong1t","device":"Unknown Unknown","domainId":"19546","propertyId":"","propertySpecifier":"","pageMode":"","localeCode":"vi-vn"},"userStatic":{"isSignedIn":"False","beginRequestTicks":"637432057289100471"}});t.register(new g({"base":"//c.msn.com/c.gif?","id":"ctag","disableOnAutoRefresh":"scorecard","isGeneratedEarly":1,"rmca":1,"impr":{"param":{'udc': 'true'},"paramMap":{"event":{'evt':'type'},"userDynamic":{'rid':'requestId','rnd':'timeStamp'},"client":{'rf':'referrer','tp':'pageUrl','scr':'screenResolution','anoncknm':'getAnonCookieName','issso':'getSsoComplete','aadState':'getAadAuthentication'},"sitePage":{'di':'domainId','lng':'localeCode','activityId':'requestId','d.dgk':'d_dgk','d.imd':'d_imd','st.dpt':'department','st.sdpt':'subDepartment','subcvs':'vertical','pg.n':'page_name','pg.t':'page_type','pg.c':'page_configuration','pg.p':'page_product'}}}}),new g({"base":"https://sb.scorecardresearch.com/b?","id":"scorecard","disableOnAutoRefresh":"scorecard","isGeneratedEarly":0,"impr":{"param":{'c1': '2', 'c2': '3000001', 'cs_ucfr': '1'},"paramMap":{"userDynamic":{'rn':'timeStamp'},"client":{'c7':'pageUrl','c8':'pageTitle','c9':'referrer'}}},"page_candidate":{"paramMap":{"event":{'evt':'type'},"userDynamic":{'rn':'timeStamp'},"client":{'c7':'pageUrl','c8':'pageTitle','c9':'referrer'}}}}),new g({"base":"//otf.msn.com/c.gif?","id":"udc","disableOnAutoRefresh":"scorecard","commonMap":{"userDynamic":{'rid':'requestId','cts':'timeStamp','idx':'currentEventIndex','dwellTime':'dwellTime'},"client":{'clid':'clientId','anoncknm':'getAnonCookieName','issso':'getSsoComplete','aadState':'getAadAuthentication','clidType':'clientIdType'},"sitePage":{'di':'domainId','mkt':'localeCode','su':'pageUrl','flightid':'flightid','activityId':'requestId','cvs':'canvas','subcvs':'vertical','pg.n':'page_name','pg.t':'page_type','pg.c':'page_configuration','pg.p':'page_product','pivot':'pagePivot','pageuid':'pageUserId','pageutype':'pageUserType','afd':'frontDoor'}},"isGeneratedEarly":0,"impr":{"param":{'evt': 'impr', 'js': '1'},"paramMap":{"userStatic":{'pp':'isSignedIn'},"userDynamic":{'dv.snlogin':'settings','dv.grpfrmod':'defaultSlotTrees'},"client":{'rf':'referrer','cu':'pageUrl','scr':'screenResolution','bh':'height','bw':'width','dv.Title1':'pageTitle','viewType':'viewType','e1':'OTFTelemetry','prs':'personalization','oscm':'connectionMode','osver':'buildVersion'},"sitePage":{'st.dpt':'department','st.sdpt':'subDepartment','cv.partner':'cvPartner','cv.publcat':'cvPublcat','cv.author':'cvAuthor','CndEl':'conditionalItem','cv.entityId':'entityId','cv.entitySrc':'entitySrc','cv.parentId':'entityCollectionId','provid':'provid','ar':'autoRefresh','d.dgk':'d_dgk','d.imd':'d_imd','tmpl':'templ','isStaticPage':'isStaticPage','pgIdx':'pageIndex','pgTot':'pageTotalCount','jids':'joinIds','fid':'feedId','fn':'feedName','ft':'feedType','ex':'extflightid','osgp':'groupPolicy','rt':'referrerType','ccn':'cookieConsentNotice'},"custom":{'pb':'addCustomTags'}}},"click":{"paramMap":{"event":{'evt':'type'},"userDynamic":{'slidetype':'slideType'},"client":{'gesture':'gesture','viewType':'viewType'},"sitePage":{'fid':'feedId','fn':'feedName','ft':'feedType','tmpl':'templ'},"report":{'cm':'contentModule','hl':'headline','du':'destinationUrl','e1':'jsonModule','l':'nLineage','lo':'oLineage','TTI':'timeToInteract','at':'actionType','bt':'behaviorType'},"custom":{'pb':'addCustomTagsForClickEvent'}}},"page_candidate":{"paramMap":{"event":{'evt':'type'}}},"unload":{"paramMap":{"event":{'evt':'type'},"client":{'frd':'frameData','wbh':'wasBrowserHiddenAtLeastOnce','mfd':'maxFrameDuration'}}},"app_error":{"paramMap":{"event":{'evt':'type'},"report":{'errId':'errId','errMsg':'errMsg','errSource':'errSource','ignorePV':'ignorePV','pb':'pb','reportingType':'reportingType'}}},"adimpr_update":{"paramMap":{"event":{'evt':'type'},"report":{'dst':'dst','den':'den','art':'art','id':'id','pg':'pg','w':'w','h':'h','status':'status','anAd':'anAd','seqid':'seqid','sdk':'sdk','fen':'fen','oAsid':'oAsid','ifrm':'ifrm'}}},"ad_click":{"paramMap":{"event":{'evt':'type'},"report":{'ct':'ct','tu':'tu','id':'id','pg':'pg','seqid':'seqid','oAsid':'oAsid','anAd':'anAd'}}},"ad_feedback":{"paramMap":{"event":{'evt':'type'},"report":{'creativeId':'creativeId','provId':'provId','tag':'tag','title':'title','l':'lineage'}}}}));define("c.trackExtComplete", 1);t.trackPage();});
//]]>
</script>
<noscript>
 <img src="//c.msn.com/c.gif?udc=true&amp;rid=39f31a574880406c91fe78e6f524d229&amp;rnd=637432057289100471&amp;rf=&amp;tp=https%253A%252F%252Fwww.msn.com%252Fvi-vn%252Fmoney%252Fcurrencyconverter&amp;di=19546&amp;lng=vi-vn&amp;activityId=39f31a574880406c91fe78e6f524d229&amp;d.dgk=tmx.pc.webkit.chrome.chrome76plus&amp;d.imd=0&amp;st.dpt=FinanceCurrencyConverter&amp;st.sdpt=&amp;subcvs=finance&amp;pg.n=currencies&amp;pg.t=data&amp;pg.c=&amp;pg.p=prime&amp;anoncknm=&amp;issso=0&amp;aadState=0" alt="image beacon" width="1" height="1" /><img src="https://sb.scorecardresearch.com/p?c1=2&amp;c2=3000001&amp;cs_ucfr=1&amp;rn=637432057289100471&amp;c7=https%253A%252F%252Fwww.msn.com%252Fvi-vn%252Fmoney%252Fcurrencyconverter&amp;c8=&amp;c9=" alt="image beacon" width="1" height="1" /><img src="https://web.vortex.data.msn.com/collect/v1/t.gif?name=%27Ms.Webi.PageView%27&amp;ver=%272.1%27&amp;appId=%27JS%3AMSN%27&amp;ext-app-env=%27prod%27&amp;ext-javascript-libver=%274.0.0-beta-10%27&amp;ext-user-localId=%27t%3A152FEF6C03EF67592249E0F002896658%27&amp;*baseType=%27Ms.Content.PageView%27&amp;*isJs=False&amp;*title=%27%27&amp;*isLoggedIn=False&amp;*isManual=True&amp;*serverImpressionGuid=%2739f31a57-4880-406c-91fe-78e6f524d229%27&amp;-ver=%271.0%27&amp;-impressionGuid=%2739f31a57-4880-406c-91fe-78e6f524d229%27&amp;-pageName=%27currencies%27&amp;-uri=%27https%253A%252F%252Fwww.msn.com%252Fvi-vn%252Fmoney%252Fcurrencyconverter%27&amp;-referrerUri=%27%27&amp;-pageTags=%27{&quot;pg.t&quot;%3A&quot;data&quot;%2C&quot;pg.p&quot;%3A&quot;prime&quot;%2C&quot;pg.c&quot;%3A&quot;&quot;%2C&quot;ex&quot;%3A&quot;&quot;%2C&quot;rid&quot;%3A&quot;39f31a574880406c91fe78e6f524d229&quot;%2C&quot;clid&quot;%3A&quot;152FEF6C03EF67592249E0F002896658&quot;%2C&quot;clidType&quot;%3A&quot;muid&quot;%2C&quot;di&quot;%3A&quot;19546&quot;%2C&quot;partner&quot;%3A&quot;&quot;%2C&quot;publcat&quot;%3A&quot;&quot;%2C&quot;cvs&quot;%3A&quot;Browser&quot;%2C&quot;subcvs&quot;%3A&quot;finance&quot;%2C&quot;entityId&quot;%3A&quot;&quot;%2C&quot;entitySrc&quot;%3A&quot;&quot;%2C&quot;provid&quot;%3A&quot;&quot;%2C&quot;dpt&quot;%3A&quot;FinanceCurrencyConverter&quot;%2C&quot;sdpt&quot;%3A&quot;&quot;%2C&quot;ar&quot;%3A&quot;0&quot;%2C&quot;dgk&quot;%3A&quot;tmx.pc.webkit.chrome.chrome76plus&quot;%2C&quot;imd&quot;%3A&quot;0&quot;%2C&quot;parentId&quot;%3A&quot;&quot;%2C&quot;pgIdx&quot;%3A&quot;&quot;%2C&quot;pgTot&quot;%3A&quot;&quot;%2C&quot;anoncknm&quot;%3A&quot;&quot;%2C&quot;afd&quot;%3A&quot;&quot;%2C&quot;issso&quot;%3A&quot;0&quot;%2C&quot;aadState&quot;%3A&quot;0&quot;}%27&amp;-behavior=0&amp;-market=%27vi-vn%27" alt="image beacon" width="1" height="1" />
</noscript>
        <div id="irisbannerph"><div id="irisbanner">
    <style type="text/css">
#Microsoft_News_NTP_for_Chrome_INTL { background: rgb(242, 242, 242); }
#Microsoft_News_NTP_for_Chrome_INTL .hl { color: rgb(26, 26, 26); }
#Microsoft_News_NTP_for_Chrome_INTL .lead { color: rgb(26, 26, 26); }
#Microsoft_News_NTP_for_Chrome_INTL .btn1 { background: rgb(0, 71, 179); color: rgb(255, 255, 255); }
#Microsoft_News_NTP_for_Chrome_INTL .dismiss { color: rgb(26, 26, 26); }

        .head,.irisbanner,#maincontent,#precontent{-webkit-transition:transform .75s linear;transition:transform .75s linear}.irisbanner{background:#1679c3;color:#fff;display:block;height:7.1rem;left:0;position:fixed;width:100%;z-index:2147483644}.irisbanner a{font-size:1.5rem;line-height:1.467;color:#fff}.irisbanner .btn1,.irisbanner .btn2{background:#fff;color:#000;opacity:.9;padding:.3rem 1.1rem}.irisbanner .btn1:focus,.irisbanner .btn1:hover,.irisbanner .btn2:focus,.irisbanner .btn2:hover{opacity:1}.irisbanner .btn1,.irisbanner .btn2,.irisbanner .dismiss{display:inline-block;min-width:12rem;text-align:center}.irisbanner .dismiss{padding:0 2.8rem 2.4rem 0;line-height:7.1rem;text-decoration:underline}.irisbanner .dismiss:hover{cursor:pointer}.irisbanner header{height:100%;margin:0 auto;position:relative}.irisbanner header>a{font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;font-size:2rem;line-height:1.3;float:left;max-width:100rem;position:absolute;top:50%;transform:translateY(-50%)}.irisbanner header>a:hover{text-decoration:underline}.irisbanner header>a span{font-size:1.5rem;line-height:1.6;color:#fff;display:block}.irisbanner header div{float:right;height:100%;line-height:7.1rem}.irisbanner header div a{margin-right:0}.irisbanner header img{display:block;float:left;height:4rem;margin-right:1.2rem;margin-top:1.5rem;width:4rem}.irisbanner header .img2{width:auto}.irisbannerbottom{bottom:-7.1rem}.irisbannertop{top:-7.2rem}.irisbactive-bottom .irisbanner{transform:translateY(-7.1rem)}.irisbactive-top .irisbanner{height:7.3rem}.irisbactive-top .irisbannertop{top:-7.2rem}.irisbactive-top .irisbannertop>a{margin-top:1rem}.irisbactive-top #foot{margin-top:7.1rem}.irisbactive-top.ap .head,.irisbactive-top.ap .irisbanner,.irisbactive-top.gp .head,.irisbactive-top.gp .irisbanner,.irisbactive-top.channelplayerpage .head,.irisbactive-top.channelplayerpage .irisbanner{margin-top:7.1rem}.irisbactive-top.ap.commonheader #precontent,.irisbactive-top.gp.commonheader #precontent,.irisbactive-top.channelplayerpage.commonheader #precontent{margin-top:18.4rem}.irisbactive-top.ap #precontent,.irisbactive-top.gp #precontent,.irisbactive-top.channelplayerpage #precontent{margin-top:15.1rem}.irisbactive-top.channelplayerpage #main{margin-top:7.3rem}.irisbactive-top.hp .head,.irisbactive-top.hp .irisbanner,.irisbactive-top.hp #maincontent,.irisbactive-top.hp #precontent,.irisbactive-top.sp .head,.irisbactive-top.sp .irisbanner,.irisbactive-top.sp #maincontent,.irisbactive-top.sp #precontent{transform:translateY(7.1rem)}@media screen and (max-width:58.865em){.irisbanner{height:7.1rem}.irisbanner .dismiss{min-width:10rem;padding:0}.irisbanner header{width:62.4rem}.irisbanner header>a{max-width:33rem;position:relative}.irisbanner header>a,.irisbanner header>a span{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.irisbanner header>a span{display:block}.irisbanner header div{margin-top:0}.irisbanner header div>a{vertical-align:middle}.irisbanner header div>a.btn1,.irisbanner header div>a.btn2{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:12rem}.irisbanner header .img2{display:none}}@media screen and (min-width:58.875em) and (max-width:78.99em){.irisbanner header{width:94.8rem}}@media screen and (min-width:79em){.irisbanner header{width:127.2rem}}@media screen and (min-width:101.5em){.irisbanner{left:-webkit-calc(50% - 80rem);left:calc(50% - 80rem);width:160rem}}
    </style>
 <div id="Microsoft_News_NTP_for_Chrome_INTL" class="irisbanner irisbannertop" data-id="1" data-m="{&quot;i&quot;:1,&quot;n&quot;:&quot;Microsoft_News_NTP_for_Chrome_INTL&quot;,&quot;y&quot;:8}" data-json="{&quot;tcb&quot;:&quot;https%3a%2f%2fris.api.iris.microsoft.com%2fv1%2fa%2fclick%3fPG%3dPC0001WD69.0000000BZC%26UNID%3d10837393%26CID%3d128000000002292769%26PID%3d425145536%26TargetID%3d700350528%26REQASID%3d7DA12DF5A7E34899B3B58DB878558C7F%26ASID%3db7b79e8cbda949f7b729e69487bd99cb%26REQT%3d20201210T140209%26UIT%3dG%26ID%3d152FEF6C03EF67592249E0F002896658%26region%3dVN%26SLOT%3d1%26RV%3d%26RS%3d%26ER_AC%3d%26%26DS_EVTID%3db7b79e8cbda949f7b729e69487bd99cb%26WFIDS%3d%26DEVOSVER%3d%26APP%3d%26lang%3dVI-VN%26oem%3d%26devFam%3d%26ossku%3d%26cmdVer%3d%26mo%3d%26cap%3d%26bSrc%3di.m&quot;,&quot;tdb&quot;:&quot;https%3a%2f%2fris.api.iris.microsoft.com%2fv1%2fa%2fdismiss%3fPG%3dPC0001WD69.0000000BZC%26UNID%3d10837393%26CID%3d128000000002292769%26PID%3d425145536%26TargetID%3d700350528%26REQASID%3d7DA12DF5A7E34899B3B58DB878558C7F%26ASID%3db7b79e8cbda949f7b729e69487bd99cb%26REQT%3d20201210T140209%26UIT%3dG%26ID%3d152FEF6C03EF67592249E0F002896658%26region%3dVN%26SLOT%3d1%26RV%3d%26RS%3d%26ER_AC%3d%26%26DS_EVTID%3db7b79e8cbda949f7b729e69487bd99cb%26WFIDS%3d%26DEVOSVER%3d%26APP%3d%26lang%3dVI-VN%26oem%3d%26devFam%3d%26ossku%3d%26cmdVer%3d%26mo%3d%26cap%3d%26bSrc%3di.m&quot;,&quot;tvb&quot;:&quot;https%3a%2f%2farc.msn.com%2fv3%2fDelivery%2fEvents%2fImpression%3fPID%3d425145536%26TID%3d700350528%26CID%3d128000000002292769%26BID%3d454917842%26PG%3dPC0001WD69.0000000BZC%26TPID%3d425145536%26REQASID%3d7DA12DF5A7E34899B3B58DB878558C7F%26ASID%3db7b79e8cbda949f7b729e69487bd99cb%26SLOT%3d1%26REQT%3d20201210T140209%26MA_Score%3d2%26%26DS_EVTID%3db7b79e8cbda949f7b729e69487bd99cb%26BCNT%3d1%26PG%3dPC0001WD69.0000000BZC%26UNID%3d10837393%26MAP_TID%3d79B32AAE-1FF4-48C9-9572-4B88A88A8760%26NCT%3d1%26ASID%3d7DA12DF5A7E34899B3B58DB878558C7F%26REQASID%3d7DA12DF5A7E34899B3B58DB878558C7F%26ARC%3d1%26EMS%3d1%26LOCALE%3dVI-VN%26COUNTRY%3dVN%26HTD%3d-1%26LANG%3d1066%26DEVLANG%3dVI%26CIP%3d13.94.34.157%26ID%3d152FEF6C03EF67592249E0F002896658%26OPTOUTSTATE%3d0%26HTTPS%3d1%26MARKETBASEDCOUNTRY%3dVN%26CFMT%3d%26H%3d0%26W%3d0%26FESVER%3d1.3%26PL%3dVI-VN%26ISSIGNEDIN%3d0%26BROWSER%3d2%26ISMOBILE%3d0%26OPSYS%3dWIN10%26MSN_CANVAS%3d8%26CHNL%3dCFD%26UIT%3dG&quot;}" data-duration="5" data-effect="SlideUp" data-position="top">
 
<header>
 <img class="img1" src="https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE4FsfD?ver=fd7a">

 <a href="https://browserdefaults.microsoft.com/extn/redirect/?xid=10&amp;br=gc&amp;channel=art&amp;pc=U556" class="hl" target="_blank">
 Tin nóng từ khắp nơi trên thế giới
<span class="lead">Tải xuống phần mở rộng Microsoft News</span>
</a>
 <div>

 <a href="#" class="dismiss" data-id="2" data-m="{&quot;i&quot;:2,&quot;p&quot;:1,&quot;n&quot;:&quot;Microsoft_News_NTP_for_Chrome_INTL_CloseButton&quot;,&quot;y&quot;:11,&quot;o&quot;:1}">Không, cảm ơn</a>


 <a href="https://browserdefaults.microsoft.com/extn/redirect/?xid=10&amp;br=gc&amp;channel=art&amp;pc=U556" class="btn1" target="_blank" data-id="3" data-m="{&quot;i&quot;:3,&quot;p&quot;:1,&quot;n&quot;:&quot;Microsoft_News_NTP_for_Chrome_INTL_ActionButton&quot;,&quot;y&quot;:11,&quot;o&quot;:2}">Thêm nó ngay bây giờ</a>

 </div>
</header>
 
</div>
 </div></div>

        

    <nav class="megamenu" data-region="megamenu_nav" data-id="23" data-m="{&quot;i&quot;:23,&quot;n&quot;:&quot;megamenu_nav&quot;,&quot;y&quot;:14}">
        <div class="start" role="menubar">
                <ul aria-label="Điều hướng Trang web">
    <li class="homepage" role="presentation" data-id="24" data-m="{&quot;i&quot;:24,&quot;n&quot;:&quot;homepage&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;homepage&quot;}">
        <a href="/vi-vn" tabindex="2">Trang chủ</a>
    </li>
    <li class="news" role="presentation" data-id="25" data-m="{&quot;i&quot;:25,&quot;n&quot;:&quot;news&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;news&quot;}">
        <a href="/vi-vn/news" tabindex="2">Tin tức</a>
    </li>
    <li class="weather" role="presentation" data-id="26" data-m="{&quot;i&quot;:26,&quot;n&quot;:&quot;weather&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;weather&quot;}">
        <a href="/vi-vn/weather" tabindex="2">Thời tiết</a>
    </li>
    <li class="entertainment" role="presentation" data-id="27" data-m="{&quot;i&quot;:27,&quot;n&quot;:&quot;entertainment&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;entertainment&quot;}">
        <a href="/vi-vn/entertainment" tabindex="2">Giải trí</a>
    </li>
    <li class="lifestyle" role="presentation" data-id="28" data-m="{&quot;i&quot;:28,&quot;n&quot;:&quot;lifestyle&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;lifestyle&quot;}">
        <a href="/vi-vn/lifestyle" tabindex="2">Đời sống</a>
    </li>
    <li class="sports" role="presentation" data-id="29" data-m="{&quot;i&quot;:29,&quot;n&quot;:&quot;sports&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;sports&quot;}">
        <a href="/vi-vn/sports" tabindex="2">Thể thao</a>
    </li>
    </ul>

                <ul aria-label="Điều hướng Trang web">
    <li class="finance" role="presentation" data-id="30" data-m="{&quot;i&quot;:30,&quot;n&quot;:&quot;finance&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;finance&quot;}">
        <a href="/vi-vn/money" tabindex="2">Tài chính</a>
    </li>
    </ul>

        </div>

 <div>


<div class="list7lines"> <h2>Lựa chọn Cổ phiếu</h2>
 <ul role="menubar">
 <li role="presentation">
 <a href="/vi-vn/money/stockscreener/52weekhighs" tabindex="2">Mức giá cao trong 52 tuần của ngày hôm nay</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/stockscreener/52weeklows" tabindex="2">Mức giá thấp trong 52 tuần của ngày hôm nay</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/stockscreener/volumeshockers" tabindex="2">Biến động Số lượng</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/stockscreener/priceshockers" tabindex="2">Biến động Giá</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/stockscreener/hdys" tabindex="2">Cổ phiếu Thu nhập Cao</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/stockscreener/blueblood" tabindex="2">Cổ phiếu Blue-chip</a>
 </li>
 </ul>
</div>


<div class="list7lines"> <h2>Khám phá</h2>
 <ul role="menubar">
 <li role="presentation">
 <a href="/vi-vn/money/markets" tabindex="2">Thị trường Thế giới</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/markets/marketmovers" tabindex="2">CP biến động mạnh nhất</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/markets/commodities" tabindex="2">Hàng hoá</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/tools/currencyconverter" tabindex="2">Đơn vị tiền tệ</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/tools/retirementplanner" tabindex="2">Lập kế hoạch Nghỉ hưu</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/fundscreener/longterm" tabindex="2">Quỹ Cổ phiếu Hiệu quả Dài hạn</a>
 </li>
 <li role="presentation">
 <a href="/vi-vn/money/fundscreener/littlefunds" tabindex="2">Quỹ Nhỏ Có Lợi nhuận Cao</a>
 </li>
 </ul>
</div>
</div>


    </nav>
    <div id="precontent" data-region="precontent" data-id="31" data-m="{&quot;i&quot;:31,&quot;n&quot;:&quot;precontent&quot;,&quot;y&quot;:6}">
        
        


        
        
    </div>

    <div id="maincontent">
         <div class="content" id="content">
            <main id="main" role="main" data-region="main" data-id="32" data-m="{&quot;i&quot;:32,&quot;n&quot;:&quot;main&quot;,&quot;y&quot;:6}">

 
<script class="loaded">
    require(["refreshPdpModules", "c.dom", "c.sso"], function(refreshPdpModules)
    {
        try
        {
            define("c.financeajaxrefreshstart", 1);
            refreshPdpModules();
        } catch (e)
        {
            define("c.financeajaxrefresherror", 1);
        }
    });
    require(["refreshPdpModules", "c.dom", "c.pdp"], function(refreshPdpModules)
    {
        try
        {
            define("c.financeajaxrefreshstart", 1);
            refreshPdpModules();
        } catch (e)
        {
            define("c.financeajaxrefresherror", 1);
        }
    });

    require(["jquery", "binding", "LocaleSettings", "c.pdpready"], function($, binding, utils)
    {
        utils.PostAjaxComplete();
    });
    require(["jquery", "binding", "LocaleSettings", "finance.ajax.done"], function($, binding, utils)
    {
        utils.PostAjaxComplete();
    });

    define("LocaleSettings", ["utils"], function()
    {
        var settings = {};
        settings.numberGroupSizes = "3".split(" ");
settings.numberDecimalSeparator = ",";
settings.numberDecimalDigits = "2";
settings.numberGroupSeparator = ".";
settings.currencyGroupSizes = "3".split(" ");
settings.currencyGroupSeparator = ".";
settings.currencyDecimalSeparator = ",";
settings.currencyDecimalDigits = parseInt("2");
settings.currencySymbol = "₫";
settings.currencyPositivePattern = parseInt("3");
settings.currencyNegativePattern = parseInt("8");
settings.percentGroupSizes = "3".split(" ");
settings.percentGroupSeparator = ".";
settings.percentDecimalSeparator = ",";
settings.percentDecimalDigits = parseInt("2");
settings.percentSymbol = "%";
settings.percentPositivePattern = parseInt("0");
settings.percentNegativePattern = parseInt("0");
settings.shortTimePattern = "h:mm tt";
settings.monthYearPattern = "MMM yyyy";
settings.monthDatePattern = "dd MMM";
settings.dayDatePattern = "ddd dd MMM";
settings.negativeSign = "-";
settings.defaultDatePattern = "dd MMMM yyyy";
settings.monthDayYearPattern = "dd/MM/yyyy";
settings.longTimePattern = "h:mm:ss tt";
settings.dateSeparator = "/";
settings.timeSeparator = ":";
settings.indexdetailsurl = "/vi-vn/money/indexdetails";
settings.stockdetailsurl = "/vi-vn/money/stockdetails";
settings.funddetailsurl = "/vi-vn/money/funddetails";
settings.etfdetailsurl = "/vi-vn/money/etfdetails";
settings.commoditydetailsurl = "/vi-vn/money/markets/commoditydetails";
settings.watchlisturl = "/vi-vn/money/watchlist";
settings.commoditiesNewsurl = "/vi-vn/money/commoditiesnews";
settings.currencyConverterUrl = "/vi-vn/money/currencyconverter";
settings.serpUrl = "/vi-vn/money/serp";
settings.milestoneDigits = "1000,1000000,1000000000,1000000000000".split(",");
settings.milestoneWords = "k,M,B,T".split(",");
settings.isUserAuthenticated = "False";
settings.currenciesUrl = "/vi-vn/money/currencydetails";
settings.marketDetailsUrl = "/vi-vn/money/marketdetails";
settings.homepageScreenersUrl = "/vi-vn/money/homepagescreeners";
settings.screenerAddFilterUrl = "/vi-vn/money/getscreenerfilters";
settings.filterResponseUrl = "/vi-vn/money/getfilterresponse";
settings.presetScreensUrl = "/vi-vn/money/getpresetscreens";
settings.realTimeQuotesUrl = "/vi-vn/money/realtimequotes";
settings.autosuggestControllerUrl = "/vi-vn/money/autosuggest";
settings.searchresultsPageUrl = "/vi-vn/money/searchresults";
settings.heroChartUrl = "/vi-vn/money/stockdetails/herochart";
settings.stockDetailsFilmstripUrl = "/vi-vn/money/stockdetailsfilmstrippartialpage?symbol=";
settings.partnerButtonUrl = "";
settings.locale = "vi-vn";
settings.language = "vi";
settings.country = "vn";

        settings.PostAjaxComplete = function(alwaysReset)
        {
            var pagingSection = binding.get("pagingSection", ".pagingsection");
            //<![CDATA[
            if (pagingSection && typeof pagingSection.teardown === "function" && typeof pagingSection.setup === "function")
            {
                pagingSection.teardown();
                pagingSection.setup();
                if (alwaysReset)
                {
                    binding("pagingSection", ".pagingsection").all();
                }
            } else
            {
                binding("pagingSection", ".pagingsection").all();
            }
            //]]>
        };

        return settings;
    });
</script>

<style class="loaded">
    .bingNewsContainer h2::after,
    [data-aop="financeportfoliobingnewsmodule"] h3::after,
    .bingNewsContainer #pdp-module h3::after
    {
        content: "Tin tức từ Web";
}
</style>
 <div class="finance-strip4 loaded">
<div class="newscontainer">
<div class="currcnvrtr">
     <script>
        define("CurrencyConverterDefaults", ["jquery", "LocaleSettings"], function ($, settings) {
            var currencyConverterDefaults = {};
            currencyConverterDefaults.currencyData = JSON.parse(JSON.stringify({"AED":{"CurrencyCode":"AED","FromCurrencyCode":null,"Change":-1.9999999999989644E-08,"ChangePercent":-0.012592872434195721,"Price":0.0001588,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001553,"YearHigh":0.0001588},"AFN":{"CurrencyCode":"AFN","FromCurrencyCode":null,"Change":-1.0000000000000026E-05,"ChangePercent":-0.30102347983142763,"Price":0.003312,"T":null,"Eeq":null,"Sec":null,"YearLow":0.003208,"YearHigh":0.003394},"ALL":{"CurrencyCode":"ALL","FromCurrencyCode":null,"Change":-1.6999999999999654E-05,"ChangePercent":-0.38496376811593425,"Price":0.004399,"T":null,"Eeq":null,"Sec":null,"YearLow":0.004369,"YearHigh":0.00497},"ARS":{"CurrencyCode":"ARS","FromCurrencyCode":null,"Change":3.2100000000000184E-06,"ChangePercent":0.090504371558508351,"Price":0.00355,"T":null,"Eeq":null,"Sec":null,"YearLow":0.002566,"YearHigh":0.00355},"AUD":{"CurrencyCode":"AUD","FromCurrencyCode":null,"Change":-4.4000000000000256E-07,"ChangePercent":-0.757967269595181,"Price":5.761E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":5.761E-05,"YearHigh":7.792E-05},"AWG":{"CurrencyCode":"AWG","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":7.7E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":7.53E-05,"YearHigh":7.74E-05},"AZN":{"CurrencyCode":"AZN","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":7.32E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":7.1E-05,"YearHigh":7.34E-05},"BAM":{"CurrencyCode":"BAM","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":6.99E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":6.88E-05,"YearHigh":7.82E-05},"BBD":{"CurrencyCode":"BBD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":8.64E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":8.41E-05,"YearHigh":8.64E-05},"BCH":{"CurrencyCode":"BCH","FromCurrencyCode":null,"Change":2.2999999999999875E-09,"ChangePercent":1.4321295143212871,"Price":1.629E-07,"T":null,"Eeq":null,"Sec":null,"YearLow":1.629E-07,"YearHigh":0.3245},"BDT":{"CurrencyCode":"BDT","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.0037,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0036,"YearHigh":0.0037},"BGN":{"CurrencyCode":"BGN","FromCurrencyCode":null,"Change":-2.6999999999999572E-07,"ChangePercent":-0.385879662712585,"Price":6.97E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":6.938E-05,"YearHigh":7.834E-05},"BHD":{"CurrencyCode":"BHD","FromCurrencyCode":null,"Change":-3.9999999999999617E-08,"ChangePercent":-0.24539877300613264,"Price":1.626E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":1.591E-05,"YearHigh":1.631E-05},"BIF":{"CurrencyCode":"BIF","FromCurrencyCode":null,"Change":-9.9999999999961231E-06,"ChangePercent":-0.012000480019196116,"Price":0.08332,"T":null,"Eeq":null,"Sec":null,"YearLow":0.07887,"YearHigh":0.08377},"BMD":{"CurrencyCode":"BMD","FromCurrencyCode":null,"Change":1.9999999999976092E-09,"ChangePercent":0.0046266308873822732,"Price":4.323E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":4.228E-05,"YearHigh":4.325E-05},"BND":{"CurrencyCode":"BND","FromCurrencyCode":null,"Change":-2.9999999999998019E-08,"ChangePercent":-0.051903114186847787,"Price":5.777E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":5.753E-05,"YearHigh":6.252E-05},"BOB":{"CurrencyCode":"BOB","FromCurrencyCode":null,"Change":-4.0000000000000972E-07,"ChangePercent":-0.1358695652173946,"Price":0.000294,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0002875,"YearHigh":0.0002966},"BSD":{"CurrencyCode":"BSD","FromCurrencyCode":null,"Change":1.9999999999976092E-09,"ChangePercent":0.0046266308873822732,"Price":4.323E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":4.228E-05,"YearHigh":4.325E-05},"BTC":{"CurrencyCode":"BTC","FromCurrencyCode":null,"Change":1.0000000000000007E-10,"ChangePercent":4.3478260869565251,"Price":2.4E-09,"T":null,"Eeq":null,"Sec":null,"YearLow":2.4E-09,"YearHigh":0.1119},"BWP":{"CurrencyCode":"BWP","FromCurrencyCode":null,"Change":2.600000000000009E-06,"ChangePercent":0.55330921472653949,"Price":0.0004725,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0004528,"YearHigh":0.0005256},"BYN":{"CurrencyCode":"BYN","FromCurrencyCode":null,"Change":-4.4999999999999739E-07,"ChangePercent":-0.40853381752155915,"Price":0.0001097,"T":null,"Eeq":null,"Sec":null,"YearLow":8.976E-05,"YearHigh":0.0001149},"BZD":{"CurrencyCode":"BZD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":8.64E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":8.41E-05,"YearHigh":8.65E-05},"CDF":{"CurrencyCode":"CDF","FromCurrencyCode":null,"Change":9.9999999999961231E-06,"ChangePercent":0.011786892975007218,"Price":0.08485,"T":null,"Eeq":null,"Sec":null,"YearLow":0.07048,"YearHigh":0.08509},"CHF":{"CurrencyCode":"CHF","FromCurrencyCode":null,"Change":-1.1999999999999885E-07,"ChangePercent":-0.31217481789801993,"Price":3.832E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":3.832E-05,"YearHigh":4.278E-05},"CLP":{"CurrencyCode":"CLP","FromCurrencyCode":null,"Change":-0.00019000000000000267,"ChangePercent":-0.59153175591532581,"Price":0.03193,"T":null,"Eeq":null,"Sec":null,"YearLow":0.03193,"YearHigh":0.03748},"CNY":{"CurrencyCode":"CNY","FromCurrencyCode":null,"Change":-8.0000000000012787E-08,"ChangePercent":-0.028290543885710725,"Price":0.0002827,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0002818,"YearHigh":0.0003078},"COP":{"CurrencyCode":"COP","FromCurrencyCode":null,"Change":-0.00020999999999998797,"ChangePercent":-0.13980427401636908,"Price":0.15,"T":null,"Eeq":null,"Sec":null,"YearLow":0.1396,"YearHigh":0.1799},"CRC":{"CurrencyCode":"CRC","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.02603,"T":null,"Eeq":null,"Sec":null,"YearLow":0.02371,"YearHigh":0.02636},"CVE":{"CurrencyCode":"CVE","FromCurrencyCode":null,"Change":-1.2999999999999991E-05,"ChangePercent":-0.32969819934060335,"Price":0.00393,"T":null,"Eeq":null,"Sec":null,"YearLow":0.003908,"YearHigh":0.004405},"CZK":{"CurrencyCode":"CZK","FromCurrencyCode":null,"Change":-2.7200000000000011E-06,"ChangePercent":-0.28920171819844354,"Price":0.0009378,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0009366,"YearHigh":0.001112},"DJF":{"CurrencyCode":"DJF","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.007674,"T":null,"Eeq":null,"Sec":null,"YearLow":0.00748,"YearHigh":0.00769},"DKK":{"CurrencyCode":"DKK","FromCurrencyCode":null,"Change":-1.0000000000000243E-06,"ChangePercent":-0.3755163349605799,"Price":0.0002653,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0002641,"YearHigh":0.0002992},"DOP":{"CurrencyCode":"DOP","FromCurrencyCode":null,"Change":2.9999999999999645E-06,"ChangePercent":0.11952191235059619,"Price":0.002513,"T":null,"Eeq":null,"Sec":null,"YearLow":0.002246,"YearHigh":0.002541},"DZD":{"CurrencyCode":"DZD","FromCurrencyCode":null,"Change":3.9999999999996635E-06,"ChangePercent":0.07080899274207228,"Price":0.005653,"T":null,"Eeq":null,"Sec":null,"YearLow":0.005085,"YearHigh":0.005668},"EGP":{"CurrencyCode":"EGP","FromCurrencyCode":null,"Change":8.0999999999996006E-07,"ChangePercent":0.11978881675268195,"Price":0.000677,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0006578,"YearHigh":0.0007018},"ETB":{"CurrencyCode":"ETB","FromCurrencyCode":null,"Change":9.9999999999991589E-07,"ChangePercent":0.060240963855416621,"Price":0.001661,"T":null,"Eeq":null,"Sec":null,"YearLow":0.001305,"YearHigh":0.001661},"ETH":{"CurrencyCode":"ETH","FromCurrencyCode":null,"Change":1.6999999999999954E-09,"ChangePercent":2.2636484687083827,"Price":7.68E-08,"T":null,"Eeq":null,"Sec":null,"YearLow":7.68E-08,"YearHigh":0.5012},"EUR":{"CurrencyCode":"EUR","FromCurrencyCode":null,"Change":-1.4000000000000205E-07,"ChangePercent":-0.39128004471772515,"Price":3.564E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":3.547E-05,"YearHigh":4.006E-05},"FJD":{"CurrencyCode":"FJD","FromCurrencyCode":null,"Change":-1.0000000000000243E-07,"ChangePercent":-0.11350737797957143,"Price":8.8E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":8.75E-05,"YearHigh":0.0001006},"GBP":{"CurrencyCode":"GBP","FromCurrencyCode":null,"Change":2.700000000000025E-07,"ChangePercent":0.836949783013027,"Price":3.253E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":3.192E-05,"YearHigh":3.746E-05},"GEL":{"CurrencyCode":"GEL","FromCurrencyCode":null,"Change":-5.9999999999998748E-07,"ChangePercent":-0.42402826855122788,"Price":0.0001409,"T":null,"Eeq":null,"Sec":null,"YearLow":0.000119,"YearHigh":0.0001471},"GMD":{"CurrencyCode":"GMD","FromCurrencyCode":null,"Change":-1.0000000000001327E-06,"ChangePercent":-0.044642857142863063,"Price":0.002239,"T":null,"Eeq":null,"Sec":null,"YearLow":0.002124,"YearHigh":0.00225},"GNF":{"CurrencyCode":"GNF","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.4283,"T":null,"Eeq":null,"Sec":null,"YearLow":0.3932,"YearHigh":0.4283},"GTQ":{"CurrencyCode":"GTQ","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.0003368,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0003236,"YearHigh":0.000338},"HKD":{"CurrencyCode":"HKD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.0003351,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0003277,"YearHigh":0.000338},"HNL":{"CurrencyCode":"HNL","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.001044,"T":null,"Eeq":null,"Sec":null,"YearLow":0.001036,"YearHigh":0.001069},"HRK":{"CurrencyCode":"HRK","FromCurrencyCode":null,"Change":-1.199999999999975E-06,"ChangePercent":-0.44444444444443526,"Price":0.0002688,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0002677,"YearHigh":0.0003047},"HTG":{"CurrencyCode":"HTG","FromCurrencyCode":null,"Change":-2.7999999999999813E-05,"ChangePercent":-0.93333333333332724,"Price":0.002972,"T":null,"Eeq":null,"Sec":null,"YearLow":0.002652,"YearHigh":0.004846},"HUF":{"CurrencyCode":"HUF","FromCurrencyCode":null,"Change":-0.00010079999999999985,"ChangePercent":-0.78991912732743919,"Price":0.01266,"T":null,"Eeq":null,"Sec":null,"YearLow":0.01246,"YearHigh":0.01447},"IDR":{"CurrencyCode":"IDR","FromCurrencyCode":null,"Change":0.00039999999999995595,"ChangePercent":0.065713816329876121,"Price":0.6091,"T":null,"Eeq":null,"Sec":null,"YearLow":0.5852,"YearHigh":0.7057},"ILS":{"CurrencyCode":"ILS","FromCurrencyCode":null,"Change":-2.0999999999999968E-07,"ChangePercent":-0.14934926392148473,"Price":0.0001404,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001402,"YearHigh":0.0001672},"INR":{"CurrencyCode":"INR","FromCurrencyCode":null,"Change":-9.3000000000011476E-07,"ChangePercent":-0.029181688960853068,"Price":0.003186,"T":null,"Eeq":null,"Sec":null,"YearLow":0.003041,"YearHigh":0.003292},"IQD":{"CurrencyCode":"IQD","FromCurrencyCode":null,"Change":-1.0000000000003062E-05,"ChangePercent":-0.019474196689392525,"Price":0.05134,"T":null,"Eeq":null,"Sec":null,"YearLow":0.05007,"YearHigh":0.05141},"ISK":{"CurrencyCode":"ISK","FromCurrencyCode":null,"Change":9.0000000000003272E-06,"ChangePercent":0.16405395552315583,"Price":0.005495,"T":null,"Eeq":null,"Sec":null,"YearLow":0.005206,"YearHigh":0.006304},"JMD":{"CurrencyCode":"JMD","FromCurrencyCode":null,"Change":-3.7999999999999839E-05,"ChangePercent":-0.6149862437287561,"Price":0.006141,"T":null,"Eeq":null,"Sec":null,"YearLow":0.005566,"YearHigh":0.006472},"JOD":{"CurrencyCode":"JOD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":3.061E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":2.989E-05,"YearHigh":3.063E-05},"JPY":{"CurrencyCode":"JPY","FromCurrencyCode":null,"Change":7.0000000000000617E-06,"ChangePercent":0.15538290788013454,"Price":0.004512,"T":null,"Eeq":null,"Sec":null,"YearLow":0.00436,"YearHigh":0.00483},"KES":{"CurrencyCode":"KES","FromCurrencyCode":null,"Change":3.9999999999996635E-06,"ChangePercent":0.0831255195344901,"Price":0.004816,"T":null,"Eeq":null,"Sec":null,"YearLow":0.004305,"YearHigh":0.004825},"KHR":{"CurrencyCode":"KHR","FromCurrencyCode":null,"Change":-0.00070000000000000617,"ChangePercent":-0.40045766590389364,"Price":0.1741,"T":null,"Eeq":null,"Sec":null,"YearLow":0.1682,"YearHigh":0.1771},"KMF":{"CurrencyCode":"KMF","FromCurrencyCode":null,"Change":-9.9999999999995925E-06,"ChangePercent":-0.056947608200453262,"Price":0.01755,"T":null,"Eeq":null,"Sec":null,"YearLow":0.01748,"YearHigh":0.01986},"KRW":{"CurrencyCode":"KRW","FromCurrencyCode":null,"Change":7.0000000000000617E-05,"ChangePercent":0.14903129657228151,"Price":0.04704,"T":null,"Eeq":null,"Sec":null,"YearLow":0.04668,"YearHigh":0.05543},"KWD":{"CurrencyCode":"KWD","FromCurrencyCode":null,"Change":9.9999999999999043E-09,"ChangePercent":0.075930144267273389,"Price":1.318E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":1.296E-05,"YearHigh":1.336E-05},"KYD":{"CurrencyCode":"KYD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":3.57E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":3.45E-05,"YearHigh":3.58E-05},"KZT":{"CurrencyCode":"KZT","FromCurrencyCode":null,"Change":-2.9999999999995308E-06,"ChangePercent":-0.016508006383093222,"Price":0.01817,"T":null,"Eeq":null,"Sec":null,"YearLow":0.01614,"YearHigh":0.0199},"LAK":{"CurrencyCode":"LAK","FromCurrencyCode":null,"Change":-0.0009000000000000119,"ChangePercent":-0.22455089820359578,"Price":0.3999,"T":null,"Eeq":null,"Sec":null,"YearLow":0.3757,"YearHigh":0.425},"LBP":{"CurrencyCode":"LBP","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.06509,"T":null,"Eeq":null,"Sec":null,"YearLow":0.06357,"YearHigh":0.06531},"LKR":{"CurrencyCode":"LKR","FromCurrencyCode":null,"Change":9.0000000000003272E-06,"ChangePercent":0.11216350947158932,"Price":0.008033,"T":null,"Eeq":null,"Sec":null,"YearLow":0.007789,"YearHigh":0.008229},"LRD":{"CurrencyCode":"LRD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.006917,"T":null,"Eeq":null,"Sec":null,"YearLow":0.006684,"YearHigh":0.008572},"LSL":{"CurrencyCode":"LSL","FromCurrencyCode":null,"Change":3.3999999999999742E-06,"ChangePercent":0.525096525096521,"Price":0.0006509,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0006009,"YearHigh":0.0008234},"LTC":{"CurrencyCode":"LTC","FromCurrencyCode":null,"Change":1.3999999999999993E-08,"ChangePercent":2.5089605734767013,"Price":5.72E-07,"T":null,"Eeq":null,"Sec":null,"YearLow":5.72E-07,"YearHigh":0.1752},"LYD":{"CurrencyCode":"LYD","FromCurrencyCode":null,"Change":-1.0000000000001598E-08,"ChangePercent":-0.017253278122846098,"Price":5.795E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":5.77E-05,"YearHigh":6.086E-05},"MAD":{"CurrencyCode":"MAD","FromCurrencyCode":null,"Change":-9.0000000000002188E-07,"ChangePercent":-0.23118417672746513,"Price":0.0003884,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0003873,"YearHigh":0.0004397},"MDL":{"CurrencyCode":"MDL","FromCurrencyCode":null,"Change":-2.2000000000000535E-06,"ChangePercent":-0.29557973935241882,"Price":0.0007421,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0007058,"YearHigh":0.0007907},"MGA":{"CurrencyCode":"MGA","FromCurrencyCode":null,"Change":-0.0050000000000000044,"ChangePercent":-2.9359953024075187,"Price":0.1653,"T":null,"Eeq":null,"Sec":null,"YearLow":0.1524,"YearHigh":0.1704},"MKD":{"CurrencyCode":"MKD","FromCurrencyCode":null,"Change":-4.9999999999997963E-06,"ChangePercent":-0.22747952684257491,"Price":0.002193,"T":null,"Eeq":null,"Sec":null,"YearLow":0.00218,"YearHigh":0.002464},"MMK":{"CurrencyCode":"MMK","FromCurrencyCode":null,"Change":-0.0001810000000000006,"ChangePercent":-0.31521568764041136,"Price":0.05724,"T":null,"Eeq":null,"Sec":null,"YearLow":0.05468,"YearHigh":0.0653},"MOP":{"CurrencyCode":"MOP","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.000345,"T":null,"Eeq":null,"Sec":null,"YearLow":0.00034,"YearHigh":0.00035},"MUR":{"CurrencyCode":"MUR","FromCurrencyCode":null,"Change":-1.0999999999999942E-05,"ChangePercent":-0.63990692262943238,"Price":0.001708,"T":null,"Eeq":null,"Sec":null,"YearLow":0.001554,"YearHigh":0.001755},"MVR":{"CurrencyCode":"MVR","FromCurrencyCode":null,"Change":-9.9999999999948221E-08,"ChangePercent":-0.014999250037490358,"Price":0.0006666,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0006427,"YearHigh":0.000667},"MWK":{"CurrencyCode":"MWK","FromCurrencyCode":null,"Change":3.0000000000002247E-05,"ChangePercent":0.092052776925444141,"Price":0.03262,"T":null,"Eeq":null,"Sec":null,"YearLow":0.03066,"YearHigh":0.034},"MXN":{"CurrencyCode":"MXN","FromCurrencyCode":null,"Change":5.4000000000000228E-06,"ChangePercent":0.62900407687827875,"Price":0.0008639,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0007959,"YearHigh":0.001097},"MYR":{"CurrencyCode":"MYR","FromCurrencyCode":null,"Change":-2.0000000000000486E-07,"ChangePercent":-0.11383039271485762,"Price":0.0001755,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001731,"YearHigh":0.0001893},"MZN":{"CurrencyCode":"MZN","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.003182,"T":null,"Eeq":null,"Sec":null,"YearLow":0.002593,"YearHigh":0.003197},"NAD":{"CurrencyCode":"NAD","FromCurrencyCode":null,"Change":4.3999999999999985E-06,"ChangePercent":0.68027210884353717,"Price":0.0006512,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0006019,"YearHigh":0.0008174},"NGN":{"CurrencyCode":"NGN","FromCurrencyCode":null,"Change":-9.9999999999995925E-06,"ChangePercent":-0.060753341433776385,"Price":0.01645,"T":null,"Eeq":null,"Sec":null,"YearLow":0.01299,"YearHigh":0.0166},"NIO":{"CurrencyCode":"NIO","FromCurrencyCode":null,"Change":-4.0000000000000972E-06,"ChangePercent":-0.26595744680851707,"Price":0.0015,"T":null,"Eeq":null,"Sec":null,"YearLow":0.00141,"YearHigh":0.001504},"NOK":{"CurrencyCode":"NOK","FromCurrencyCode":null,"Change":-7.00000000000017E-07,"ChangePercent":-0.18315018315018758,"Price":0.0003815,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0003732,"YearHigh":0.0005179},"NPR":{"CurrencyCode":"NPR","FromCurrencyCode":null,"Change":5.8999999999996555E-06,"ChangePercent":0.11593405513744386,"Price":0.005095,"T":null,"Eeq":null,"Sec":null,"YearLow":0.004867,"YearHigh":0.005259},"NZD":{"CurrencyCode":"NZD","FromCurrencyCode":null,"Change":-2.600000000000009E-07,"ChangePercent":-0.42235217673814313,"Price":6.13E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":6.079E-05,"YearHigh":7.843E-05},"OMR":{"CurrencyCode":"OMR","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":1.664E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":1.623E-05,"YearHigh":1.665E-05},"PAB":{"CurrencyCode":"PAB","FromCurrencyCode":null,"Change":1.9999999999976092E-09,"ChangePercent":0.0046266308873822732,"Price":4.323E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":4.228E-05,"YearHigh":4.325E-05},"PEN":{"CurrencyCode":"PEN","FromCurrencyCode":null,"Change":-1.0999999999999725E-07,"ChangePercent":-0.070689544373753133,"Price":0.0001555,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001407,"YearHigh":0.0001583},"PGK":{"CurrencyCode":"PGK","FromCurrencyCode":null,"Change":2.600000000000009E-06,"ChangePercent":1.7651052274270258,"Price":0.0001499,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001407,"YearHigh":0.0001517},"PHP":{"CurrencyCode":"PHP","FromCurrencyCode":null,"Change":-4.0000000000000972E-06,"ChangePercent":-0.19203072491599121,"Price":0.002079,"T":null,"Eeq":null,"Sec":null,"YearLow":0.00207,"YearHigh":0.002243},"PKR":{"CurrencyCode":"PKR","FromCurrencyCode":null,"Change":-2.6499999999999614E-05,"ChangePercent":-0.38297564852951249,"Price":0.006893,"T":null,"Eeq":null,"Sec":null,"YearLow":0.006442,"YearHigh":0.007269},"PLN":{"CurrencyCode":"PLN","FromCurrencyCode":null,"Change":-9.0999999999998959E-07,"ChangePercent":-0.57373431687787,"Price":0.0001577,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001577,"YearHigh":0.0001833},"PYG":{"CurrencyCode":"PYG","FromCurrencyCode":null,"Change":-0.0009000000000000119,"ChangePercent":-0.29605263157895129,"Price":0.3031,"T":null,"Eeq":null,"Sec":null,"YearLow":0.2735,"YearHigh":0.3044},"QAR":{"CurrencyCode":"QAR","FromCurrencyCode":null,"Change":-4.0000000000006393E-08,"ChangePercent":-0.025406504065044709,"Price":0.0001574,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001539,"YearHigh":0.0001604},"RON":{"CurrencyCode":"RON","FromCurrencyCode":null,"Change":-5.0000000000001215E-07,"ChangePercent":-0.28735632183908744,"Price":0.0001735,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001385,"YearHigh":0.0001945},"RSD":{"CurrencyCode":"RSD","FromCurrencyCode":null,"Change":-1.899999999999992E-05,"ChangePercent":-0.45173561578696914,"Price":0.004187,"T":null,"Eeq":null,"Sec":null,"YearLow":0.004164,"YearHigh":0.004705},"RUB":{"CurrencyCode":"RUB","FromCurrencyCode":null,"Change":-1.4479999999999875E-05,"ChangePercent":-0.45513408853740633,"Price":0.003167,"T":null,"Eeq":null,"Sec":null,"YearLow":0.002626,"YearHigh":0.003557},"RWF":{"CurrencyCode":"RWF","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.04256,"T":null,"Eeq":null,"Sec":null,"YearLow":0.03884,"YearHigh":0.04256},"SAR":{"CurrencyCode":"SAR","FromCurrencyCode":null,"Change":-5.0000000000001215E-08,"ChangePercent":-0.030816640986133258,"Price":0.0001622,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001587,"YearHigh":0.0001622},"SCR":{"CurrencyCode":"SCR","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.000904,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0005099,"YearHigh":0.0009326},"SGD":{"CurrencyCode":"SGD","FromCurrencyCode":null,"Change":-2.9999999999998019E-08,"ChangePercent":-0.051903114186847787,"Price":5.777E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":5.753E-05,"YearHigh":6.252E-05},"SHP":{"CurrencyCode":"SHP","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":3.224E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":3.204E-05,"YearHigh":3.668E-05},"SLL":{"CurrencyCode":"SLL","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.4324,"T":null,"Eeq":null,"Sec":null,"YearLow":0.403,"YearHigh":0.4416},"SOS":{"CurrencyCode":"SOS","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.02486,"T":null,"Eeq":null,"Sec":null,"YearLow":0.02431,"YearHigh":0.02487},"SZL":{"CurrencyCode":"SZL","FromCurrencyCode":null,"Change":4.1999999999999937E-06,"ChangePercent":0.6491499227202463,"Price":0.0006512,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0006007,"YearHigh":0.0008236},"THB":{"CurrencyCode":"THB","FromCurrencyCode":null,"Change":-2.7000000000000114E-06,"ChangePercent":-0.20758053355885381,"Price":0.0012979999999999999,"T":null,"Eeq":null,"Sec":null,"YearLow":0.001284,"YearHigh":0.001407},"TMT":{"CurrencyCode":"TMT","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.0001509,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001476,"YearHigh":0.000151},"TND":{"CurrencyCode":"TND","FromCurrencyCode":null,"Change":-3.1000000000000211E-07,"ChangePercent":-0.26403202452942859,"Price":0.0001171,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0001157,"YearHigh":0.0001259},"TRY":{"CurrencyCode":"TRY","FromCurrencyCode":null,"Change":2.1500000000000252E-06,"ChangePercent":0.63618878532328016,"Price":0.0003401,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0002474,"YearHigh":0.0003701},"TTD":{"CurrencyCode":"TTD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.0002915,"T":null,"Eeq":null,"Sec":null,"YearLow":0.0002813,"YearHigh":0.0002928},"TWD":{"CurrencyCode":"TWD","FromCurrencyCode":null,"Change":-1.2600000000001065E-06,"ChangePercent":-0.10317213369799276,"Price":0.00122,"T":null,"Eeq":null,"Sec":null,"YearLow":0.001217,"YearHigh":0.001317},"TZS":{"CurrencyCode":"TZS","FromCurrencyCode":null,"Change":3.999999999999837E-05,"ChangePercent":0.040016006402559388,"Price":0.1,"T":null,"Eeq":null,"Sec":null,"YearLow":0.09703,"YearHigh":0.1003},"UAH":{"CurrencyCode":"UAH","FromCurrencyCode":null,"Change":-1.6000000000000389E-06,"ChangePercent":-0.13183915622940334,"Price":0.001212,"T":null,"Eeq":null,"Sec":null,"YearLow":0.001001,"YearHigh":0.001237},"UGX":{"CurrencyCode":"UGX","FromCurrencyCode":null,"Change":-0.00029999999999999472,"ChangePercent":-0.18879798615481103,"Price":0.1586,"T":null,"Eeq":null,"Sec":null,"YearLow":0.157,"YearHigh":0.1669},"USD":{"CurrencyCode":"USD","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":4.323E-05,"T":null,"Eeq":null,"Sec":null,"YearLow":4.227E-05,"YearHigh":4.325E-05},"UYU":{"CurrencyCode":"UYU","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.001844,"T":null,"Eeq":null,"Sec":null,"YearLow":0.001594,"YearHigh":0.001965},"UZS":{"CurrencyCode":"UZS","FromCurrencyCode":null,"Change":-0.0038000000000000256,"ChangePercent":-0.84201196543319856,"Price":0.4475,"T":null,"Eeq":null,"Sec":null,"YearLow":0.4007,"YearHigh":0.4513},"VES":{"CurrencyCode":"VES","FromCurrencyCode":null,"Change":-0.0020499999999969987,"ChangePercent":-0.0044017250467753045,"Price":46.5706,"T":null,"Eeq":null,"Sec":null,"YearLow":1.7189,"YearHigh":46.8447},"YER":{"CurrencyCode":"YER","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":0.01056,"T":null,"Eeq":null,"Sec":null,"YearLow":0.01053,"YearHigh":0.01079},"ZAR":{"CurrencyCode":"ZAR","FromCurrencyCode":null,"Change":4.1000000000000454E-06,"ChangePercent":0.63359604388812329,"Price":0.0006512,"T":null,"Eeq":null,"Sec":null,"YearLow":0.000601,"YearHigh":0.0008236},"ZMW":{"CurrencyCode":"ZMW","FromCurrencyCode":null,"Change":2.0000000000000486E-07,"ChangePercent":0.021987686895339146,"Price":0.0009098,"T":null,"Eeq":null,"Sec":null,"YearLow":0.000563,"YearHigh":0.0009104},"VND":{"CurrencyCode":"VND","FromCurrencyCode":null,"Change":0,"ChangePercent":0,"Price":1,"T":null,"Eeq":null,"Sec":null,"YearLow":null,"YearHigh":null}}));
currencyConverterDefaults.defaultFrom = 'USD';
currencyConverterDefaults.defaultTo = 'VND';
currencyConverterDefaults.defaultFromValue = '1';
            currencyConverterDefaults.countryData = JSON.parse(JSON.stringify({"AFN":{"ID":"0","Country":"Afghanistan","Currency":"Afghani","Symbol":"؋","CountryCode":"AFG","FullCurrencyName":"Afghanistan Afghani","PMID":"NA"},"ALL":{"ID":"1","Country":"Albania","Currency":"Lek","Symbol":"ALL","CountryCode":"ALB","FullCurrencyName":"Albanian Lek","PMID":"71"},"DZD":{"ID":"2","Country":"Algeria","Currency":"Dinar_Algeria","Symbol":"د.ج.‏","CountryCode":"DZA","FullCurrencyName":"Algerian Dinar","PMID":"48"},"ARS":{"ID":"3","Country":"Argentina","Currency":"Peso_Argentina","Symbol":"$","CountryCode":"ARG","FullCurrencyName":"Argentine Peso","PMID":"10"},"AWG":{"ID":"4","Country":"Aruba","Currency":"Guilder","Symbol":"ƒ","CountryCode":"ABW","FullCurrencyName":"Aruba Florin","PMID":"72"},"AUD":{"ID":"5","Country":"Australia","Currency":"Dollar_Australia","Symbol":"$","CountryCode":"AUS","FullCurrencyName":"Australian Dollar","PMID":"8"},"AZN":{"ID":"6","Country":"Azerbaijan","Currency":"New_Manat","Symbol":"ман","CountryCode":"AZE","FullCurrencyName":"Azerbaijan New Manat","PMID":"NA"},"BSD":{"ID":"7","Country":"Bahamas The","Currency":"Dollar_Bahamas","Symbol":"B$","CountryCode":"BHS","FullCurrencyName":"Bahamian Dollar","PMID":"73"},"BHD":{"ID":"8","Country":"Bahrain","Currency":"Dinar_Bahrain","Symbol":".د.ب ","CountryCode":"BHR","FullCurrencyName":"Bahraini Dinar","PMID":"57"},"BDT":{"ID":"9","Country":"Bangladesh","Currency":"Taka","Symbol":"৳ ","CountryCode":"BGD","FullCurrencyName":"Bangladesh Taka","PMID":"74"},"BBD":{"ID":"10","Country":"Barbados","Currency":"Dollar_Barbados","Symbol":"$","CountryCode":"BRB","FullCurrencyName":"Barbados Dollar","PMID":"75"},"BYR":{"ID":"11","Country":"Belarus","Currency":"Ruble_Belarus","Symbol":"p.","CountryCode":"BLR","FullCurrencyName":"Belarus Ruble","PMID":"NA"},"BZD":{"ID":"12","Country":"Belize","Currency":"Dollar_Belize","Symbol":"BZ$","CountryCode":"BLZ","FullCurrencyName":"Belize Dollar","PMID":"76"},"BMD":{"ID":"13","Country":"Bermuda","Currency":"Dollar_Bermuda","Symbol":"$","CountryCode":"BMU","FullCurrencyName":"Bermuda Dollar","PMID":"77"},"BOB":{"ID":"14","Country":"Bolivia","Currency":"Boliviano","Symbol":"$b","CountryCode":"BOL","FullCurrencyName":"Bolivian Boliviano","PMID":"13"},"BAM":{"ID":"15","Country":"Bosnia And Herzegovina","Currency":"Convertible_Marka","Symbol":"KM","CountryCode":"BIH","FullCurrencyName":"Bosnia and Herzegovina Convertible Marka","PMID":"79"},"BWP":{"ID":"16","Country":"Botswana","Currency":"Pula","Symbol":"P","CountryCode":"BWA","FullCurrencyName":"Botswana pula","PMID":"52"},"BRL":{"ID":"17","Country":"Brazil","Currency":"Real","Symbol":"R$","CountryCode":"BRA","FullCurrencyName":"Brazilian Real","PMID":"14"},"BND":{"ID":"18","Country":"Brunei","Currency":"Dollar_Brunei","Symbol":"$","CountryCode":"BRN","FullCurrencyName":"Brunei Dollar","PMID":"80"},"BGN":{"ID":"19","Country":"Bulgaria","Currency":"Lev","Symbol":"лв","CountryCode":"BGR","FullCurrencyName":"Bulgarian Lev","PMID":"81"},"BIF":{"ID":"20","Country":"Burundi","Currency":"Franc_Burundi","Symbol":"Fbu","CountryCode":"BDI","FullCurrencyName":"Burundi Franc","PMID":"82"},"KHR":{"ID":"21","Country":"Cambodia","Currency":"Riel","Symbol":"៛","CountryCode":"KHM","FullCurrencyName":"Cambodia Riel","PMID":"83"},"CAD":{"ID":"22","Country":"Canada","Currency":"Dollar_Canada","Symbol":"$","CountryCode":"CAN","FullCurrencyName":"Canadian Dollar","PMID":"2"},"CVE":{"ID":"23","Country":"Cabo Verde","Currency":"Escudo","Symbol":"Esc","CountryCode":"CPV","FullCurrencyName":"Cape Verde Escudo","PMID":"84"},"KYD":{"ID":"24","Country":"Cayman Islands","Currency":"Dollar_Cayman Islands","Symbol":"$","CountryCode":"CYM","FullCurrencyName":"Cayman Islands Dollar","PMID":"85"},"CLP":{"ID":"25","Country":"Chile","Currency":"Peso_Chile","Symbol":"$","CountryCode":"CHL","FullCurrencyName":"Chilean Peso","PMID":"16"},"CNY":{"ID":"26","Country":"China","Currency":"Yuan","Symbol":"¥","CountryCode":"CHN","FullCurrencyName":"Chinese Yuan","PMID":"17"},"COP":{"ID":"27","Country":"Colombia","Currency":"Peso_Colombia","Symbol":"$","CountryCode":"COL","FullCurrencyName":"Colombian Peso","PMID":"18"},"KMF":{"ID":"28","Country":"Comoros","Currency":"Franc_Comoros","Symbol":"CF","CountryCode":"COM","FullCurrencyName":"Comoros Franc","PMID":"86"},"CDF":{"ID":"29","Country":"Congo","Currency":"Franc_Congo","Symbol":"F","CountryCode":"COG","FullCurrencyName":"Congo Franc","PMID":"NA"},"CRC":{"ID":"30","Country":"Costa Rica","Currency":"Colon","Symbol":"₡","CountryCode":"CRI","FullCurrencyName":"Costa Rica Colon","PMID":"87"},"HRK":{"ID":"31","Country":"Croatia","Currency":"Kuna","Symbol":"kn","CountryCode":"HRV","FullCurrencyName":"Croatian Kuna","PMID":"88"},"CZK":{"ID":"32","Country":"Czech Republic","Currency":"Koruna","Symbol":"Kč","CountryCode":"CZE","FullCurrencyName":"Czech Koruna","PMID":"19"},"DKK":{"ID":"33","Country":"Denmark","Currency":"Krone_Denmark","Symbol":"kr","CountryCode":"DNK","FullCurrencyName":"Danish Krone","PMID":"20"},"DJF":{"ID":"34","Country":"Djibouti","Currency":"Franc_Djibouti","Symbol":"Fdj","CountryCode":"DJI","FullCurrencyName":"Dijibouti Franc","PMID":"89"},"DOP":{"ID":"35","Country":"Dominican Republic","Currency":"Peso_Dominican Republic","Symbol":"RD$","CountryCode":"DOM","FullCurrencyName":"Dominican Peso","PMID":"90"},"EGP":{"ID":"36","Country":"Egypt","Currency":"Pound_Egypt","Symbol":"ج.م.‏","CountryCode":"EGY","FullCurrencyName":"Egyptian Pound","PMID":"92"},"ETB":{"ID":"38","Country":"Ethiopia","Currency":"Birr","Symbol":"ETB","CountryCode":"ETH","FullCurrencyName":"Ethiopian Birr","PMID":"94"},"EUR":{"ID":"39","Country":"Europe","Currency":"Euro","Symbol":"€","CountryCode":"EUR","FullCurrencyName":"Euro","PMID":"9"},"FJD":{"ID":"40","Country":"Fiji","Currency":"Dollar_Fiji","Symbol":"$","CountryCode":"FJI","FullCurrencyName":"Fiji Dollar","PMID":"95"},"GMD":{"ID":"41","Country":"Gambia The","Currency":"Dalasi","Symbol":"D","CountryCode":"GMB","FullCurrencyName":"Gambian Dalasi","PMID":"97"},"GEL":{"ID":"42","Country":"CGeorgia","Currency":"Lari","Symbol":"GEL","CountryCode":"GEO","FullCurrencyName":"Georgia Lari","PMID":"98"},"GHS":{"ID":"43","Country":"Ghana","Currency":"Cedi","Symbol":"¢","CountryCode":"GHA","FullCurrencyName":"Ghanian Cedi","PMID":"53"},"GTQ":{"ID":"44","Country":"Guatemala","Currency":"Quetzal","Symbol":"Q","CountryCode":"GTM","FullCurrencyName":"Guatemala Quetzal","PMID":"45"},"GNF":{"ID":"45","Country":"Guinea","Currency":"Franc_Guinea","Symbol":"FG","CountryCode":"GIN","FullCurrencyName":"Guinea Franc","PMID":"NA"},"HTG":{"ID":"46","Country":"Haiti","Currency":"Gourde","Symbol":"G","CountryCode":"HTI","FullCurrencyName":"Haiti Gourde","PMID":"100"},"HNL":{"ID":"47","Country":"Honduras","Currency":"Lempira","Symbol":"L","CountryCode":"HND","FullCurrencyName":"Honduras Lempira","PMID":"101"},"HKD":{"ID":"48","Country":"Hong Kong SAR","Currency":"Dollar_Hong_Kong_SAR","Symbol":"HK$","CountryCode":"HKG","FullCurrencyName":"Hong Kong Dollar","PMID":"24"},"HUF":{"ID":"49","Country":"Hungary","Currency":"Forint","Symbol":"Ft","CountryCode":"HUN","FullCurrencyName":"Hungarian Forint","PMID":"25"},"ISK":{"ID":"50","Country":"Iceland","Currency":"Krona_Iceland","Symbol":"kr","CountryCode":"ISL","FullCurrencyName":"Iceland Krona","PMID":"102"},"INR":{"ID":"51","Country":"India","Currency":"Rupee_India","Symbol":"₹","CountryCode":"IND","FullCurrencyName":"Indian Rupee","PMID":"59"},"IDR":{"ID":"52","Country":"Indonesia","Currency":"Rupiah","Symbol":"Rp","CountryCode":"IDN","FullCurrencyName":"Indonesian Rupiah","PMID":"26"},"IQD":{"ID":"53","Country":"Iraq","Currency":"Dinar_Iraq","Symbol":"د.ع.‏","CountryCode":"IRQ","FullCurrencyName":"Iraqi Dinar","PMID":"152"},"ILS":{"ID":"54","Country":"Israel","Currency":"Shekel","Symbol":"₪","CountryCode":"ISR","FullCurrencyName":"Israeli Shekel","PMID":"50"},"JMD":{"ID":"55","Country":"Jamaica","Currency":"Dollar_Jamaica","Symbol":"J$","CountryCode":"JAM","FullCurrencyName":"Jamaican Dollar","PMID":"104"},"JPY":{"ID":"56","Country":"Japan","Currency":"Yen","Symbol":"¥","CountryCode":"JPN","FullCurrencyName":"Japanese Yen","PMID":"7"},"JOD":{"ID":"57","Country":"Jordan","Currency":"Dinar_Jordan","Symbol":"د.ا.‏","CountryCode":"JOR","FullCurrencyName":"Jordanian Dinar","PMID":"60"},"KZT":{"ID":"58","Country":"Kazakhstan","Currency":"Tenge","Symbol":"₸","CountryCode":"KAZ","FullCurrencyName":"Kazakhstan Tenge","PMID":"105"},"KES":{"ID":"59","Country":"Kenya","Currency":"Shilling_Kenya","Symbol":"KSh","CountryCode":"KEN","FullCurrencyName":"Kenyan Shilling","PMID":"54"},"KRW":{"ID":"60","Country":"Korea","Currency":"Won","Symbol":"₩","CountryCode":"KOR","FullCurrencyName":"South Korean Won","PMID":"28"},"KWD":{"ID":"61","Country":"Kuwait","Currency":"Dinar_Kuwait","Symbol":"د.ك.‏","CountryCode":"KWT","FullCurrencyName":"Kuwaiti Dinar","PMID":"61"},"LAK":{"ID":"62","Country":"Laos","Currency":"Kip","Symbol":"₭","CountryCode":"LAO","FullCurrencyName":"Lao Kip","PMID":"106"},"LVL":{"ID":"63","Country":"Latvia","Currency":"Lat","Symbol":"Ls","CountryCode":"LVA","FullCurrencyName":"Latvian Lat","PMID":"107"},"LBP":{"ID":"64","Country":"Lebanon","Currency":"Pound_Lebanon","Symbol":" ل.ل.‏","CountryCode":"LBN","FullCurrencyName":"Lebanese Pound","PMID":"62"},"LSL":{"ID":"65","Country":"Lesotho","Currency":"Loti","Symbol":"L","CountryCode":"LSO","FullCurrencyName":"Lesotho Loti","PMID":"108"},"LRD":{"ID":"66","Country":"Liberia","Currency":"Dollar_Liberia","Symbol":"$","CountryCode":"LBR","FullCurrencyName":"Liberian Dollar","PMID":"109"},"LYD":{"ID":"67","Country":"Libya","Currency":"Dinar_Libya","Symbol":"د.ل.‏","CountryCode":"LBY","FullCurrencyName":"Libyan Dinar","PMID":"110"},"LTL":{"ID":"68","Country":"Lithuania","Currency":"Litas","Symbol":"Lt","CountryCode":"LTU","FullCurrencyName":"Lithuanian Lita","PMID":"111"},"MOP":{"ID":"69","Country":"Macao SAR","Currency":"Pataca","Symbol":"P","CountryCode":"MAC","FullCurrencyName":"Macau Pataca","PMID":"112"},"MKD":{"ID":"70","Country":"Macedonia FYRO","Currency":"Denar","Symbol":"ден","CountryCode":"MKD","FullCurrencyName":"Macedonian Denar","PMID":"NA"},"MGA":{"ID":"71","Country":"Madagascar","Currency":"Malagasy Ariary","Symbol":"Ar","CountryCode":"MDG","FullCurrencyName":"Madagascar Malagasy Ariary","PMID":"NA"},"MWK":{"ID":"72","Country":"Malawi","Currency":"Kwacha_Malawi","Symbol":"MK","CountryCode":"MWI","FullCurrencyName":"Malawi Kwacha","PMID":"114"},"MYR":{"ID":"73","Country":"Malaysia","Currency":"Ringgit","Symbol":"RM","CountryCode":"MYS","FullCurrencyName":"Malaysian Ringgit","PMID":"51"},"MVR":{"ID":"74","Country":"Maldives","Currency":"Rufiyaa","Symbol":"Rf","CountryCode":"MDV","FullCurrencyName":"Maldives Rufiyaa","PMID":"115"},"MRO":{"ID":"75","Country":"Mauritania","Currency":"Ouguiya","Symbol":"UM","CountryCode":"MRT","FullCurrencyName":"Mauritania Ougulya","PMID":"117"},"MUR":{"ID":"76","Country":"Mauritius","Currency":"Rupee_Mauritius","Symbol":"₨","CountryCode":"MUS","FullCurrencyName":"Mauritius Rupee","PMID":"118"},"MXN":{"ID":"77","Country":"Mexico","Currency":"Peso_Mexico","Symbol":"$","CountryCode":"MEX","FullCurrencyName":"Mexican Peso","PMID":"30"},"MDL":{"ID":"78","Country":"Moldova","Currency":"Leu","Symbol":"MDL","CountryCode":"MDA","FullCurrencyName":"Moldovan Leu","PMID":"119"},"MAD":{"ID":"79","Country":"Morocco","Currency":"Dirham_Morocco","Symbol":"د.م.‏","CountryCode":"MAR","FullCurrencyName":"Moroccan Dirham","PMID":"46"},"MZN":{"ID":"80","Country":"Mozambique","Currency":"Metical","Symbol":"MT","CountryCode":"MOZ","FullCurrencyName":"Mozambique Metical","PMID":"121"},"MMK":{"ID":"81","Country":"Myanmar","Currency":"Kyat","Symbol":"K","CountryCode":"MMR","FullCurrencyName":"Myanmar Kyat","PMID":"NA"},"NAD":{"ID":"82","Country":"Namibia","Currency":"Dollar_Namibia","Symbol":"$","CountryCode":"NAM","FullCurrencyName":"Namibian Dollar","PMID":"55"},"NPR":{"ID":"83","Country":"Nepal","Currency":"Rupee_Nepal","Symbol":"₨","CountryCode":"NPL","FullCurrencyName":"Nepalese Rupee","PMID":"122"},"NZD":{"ID":"84","Country":"New Zealand","Currency":"Dollar_New Zealand","Symbol":"$","CountryCode":"NZL","FullCurrencyName":"New Zealand Dollar","PMID":"32"},"NIO":{"ID":"85","Country":"Nicaragua","Currency":"Cordoba","Symbol":"C$","CountryCode":"NIC","FullCurrencyName":"Nicaragua Cordoba","PMID":"123"},"NGN":{"ID":"86","Country":"Nigeria","Currency":"Naira","Symbol":"₦","CountryCode":"NGA","FullCurrencyName":"Nigerian Naira","PMID":"124"},"NOK":{"ID":"87","Country":"Norway","Currency":"Krone_Norway","Symbol":"kr","CountryCode":"NOR","FullCurrencyName":"Norwegian Krone","PMID":"33"},"OMR":{"ID":"88","Country":"Oman","Currency":"Rial_Oman","Symbol":"ر.ع","CountryCode":"OMN","FullCurrencyName":"Omani Rial","PMID":"63"},"PKR":{"ID":"89","Country":"Pakistan","Currency":"Rupee_Pakistan","Symbol":"₨","CountryCode":"PAK","FullCurrencyName":"Pakistani Rupee","PMID":"64"},"PAB":{"ID":"90","Country":"Panama","Currency":"Balboa","Symbol":"B/.","CountryCode":"PAN","FullCurrencyName":"Panama Balboa","PMID":"154"},"PGK":{"ID":"91","Country":"Papua New Guinea","Currency":"Kina","Symbol":"K","CountryCode":"PNG","FullCurrencyName":"Papua New Guinea Kina","PMID":"125"},"PYG":{"ID":"92","Country":"Paraguay","Currency":"Guarani","Symbol":"Gs","CountryCode":"PRY","FullCurrencyName":"Paraguayan Guarani","PMID":"126"},"PEN":{"ID":"93","Country":"Peru","Currency":"Nuevo Sol","Symbol":"S/.","CountryCode":"PER","FullCurrencyName":"Peruvian Nuevo Sol","PMID":"34"},"PHP":{"ID":"94","Country":"Philippines","Currency":"Peso_Philippines","Symbol":"₱","CountryCode":"PHL","FullCurrencyName":"Philippine Peso","PMID":"65"},"PLN":{"ID":"95","Country":"Poland","Currency":"Zloty","Symbol":"zł","CountryCode":"POL","FullCurrencyName":"Polish Zloty","PMID":"35"},"QAR":{"ID":"96","Country":"Qatar","Currency":"Riyal_Qatar","Symbol":"ر.ق.‏","CountryCode":"QAT","FullCurrencyName":"Qatar Rial","PMID":"66"},"RON":{"ID":"97","Country":"Romania","Currency":"New Leu","Symbol":"lei","CountryCode":"ROU","FullCurrencyName":"RomanianNew Leu","PMID":"127"},"RUB":{"ID":"98","Country":"Russia","Currency":"Ruble_Russia","Symbol":"₽","CountryCode":"RUS","FullCurrencyName":"Russian Rouble","PMID":"37"},"RWF":{"ID":"99","Country":"Rwanda","Currency":"Franc_Rwanda","Symbol":"RF","CountryCode":"RWA","FullCurrencyName":"Rwanda Franc","PMID":"128"},"SHP":{"ID":"100","Country":"Saint Helena Ascension and Tristan da Cunha","Currency":"Pound_Saint_Helena","Symbol":"£","CountryCode":"SHN","FullCurrencyName":"Saint Helena Ascension and Tristan da Cunha Pound","PMID":"NA"},"STD":{"ID":"101","Country":"Sao Tome and Principe","Currency":"Dobra","Symbol":"Db","CountryCode":"STP","FullCurrencyName":"Sao Toma Dobra","PMID":"129"},"SAR":{"ID":"102","Country":"Saudi Arabia","Currency":"Riyal_Saudi Arabia","Symbol":"SR","CountryCode":"SAU","FullCurrencyName":"Saudi Arabian Riyal","PMID":"67"},"RSD":{"ID":"103","Country":"Serbia","Currency":"Dinar_Serbia","Symbol":"Дин.","CountryCode":"SRB","FullCurrencyName":"Serbia Dinar","PMID":"NA"},"SCR":{"ID":"104","Country":"Seychelles","Currency":"Rupee_Seychelles","Symbol":"₨","CountryCode":"SYC","FullCurrencyName":"Seychelles Rupee","PMID":"132"},"SLL":{"ID":"105","Country":"Sierra Leone","Currency":"Leone","Symbol":"Le","CountryCode":"SLE","FullCurrencyName":"Sierra Leone Leone","PMID":"133"},"SGD":{"ID":"106","Country":"Singapore","Currency":"Dollar_Singapore","Symbol":"S$","CountryCode":"SGP","FullCurrencyName":"Singapore Dollar","PMID":"40"},"SOS":{"ID":"107","Country":"Somalia","Currency":"Shilling_Somalia","Symbol":"S","CountryCode":"SOM","FullCurrencyName":"Somali Shilling","PMID":"136"},"ZAR":{"ID":"108","Country":"South Africa","Currency":"Rand","Symbol":"R","CountryCode":"ZAF","FullCurrencyName":"South African Rand","PMID":"44"},"LKR":{"ID":"109","Country":"Sri Lanka","Currency":"Rupee_Sri Lanka","Symbol":"₨","CountryCode":"LKA","FullCurrencyName":"Sri Lanka Rupee","PMID":"137"},"SZL":{"ID":"110","Country":"Swaziland","Currency":"Lilangeni","Symbol":"E","CountryCode":"SWZ","FullCurrencyName":"Swaziland Lilageni","PMID":"139"},"SEK":{"ID":"111","Country":"CSweden","Currency":"Krona_Sweden","Symbol":"kr","CountryCode":"SWE","FullCurrencyName":"Swedish Krona","PMID":"39"},"CHF":{"ID":"112","Country":"Switzerland","Currency":"Franc_Switzerland","Symbol":"CHF","CountryCode":"CHE","FullCurrencyName":"Swiss Franc","PMID":"15"},"TWD":{"ID":"113","Country":"Taiwan","Currency":"New_Dollar","Symbol":"NT$","CountryCode":"TWN","FullCurrencyName":"Taiwan Dollar","PMID":"42"},"TZS":{"ID":"114","Country":"Tanzania","Currency":"Shilling_Tanzania","Symbol":"TSh","CountryCode":"TZA","FullCurrencyName":"Tanzanian Shilling","PMID":"68"},"THB":{"ID":"115","Country":"Thailand","Currency":"Baht","Symbol":"฿","CountryCode":"THA","FullCurrencyName":"Thai Baht","PMID":"41"},"TTD":{"ID":"116","Country":"Trinidad and Tobago","Currency":"Dollar_Trinidad and Tobago","Symbol":"$","CountryCode":"TTO","FullCurrencyName":"Trinidad and Tobago Dollar","PMID":"142"},"TND":{"ID":"117","Country":"Tunisia","Currency":"Dinar_Tunisia","Symbol":"د.ت.‏","CountryCode":"TUN","FullCurrencyName":"Tunisian Dinar","PMID":"47"},"TRY":{"ID":"118","Country":"Turkey","Currency":"Lira","Symbol":"TRY","CountryCode":"TUR","FullCurrencyName":"Turkish Lira","PMID":"49"},"TMT":{"ID":"119","Country":"Turkmenistan","Currency":"Manat","Symbol":"m","CountryCode":"TKM","FullCurrencyName":"Turkmenistan Manat","PMID":"143"},"UGX":{"ID":"120","Country":"Uganda","Currency":"Shilling_Uganda","Symbol":"Ush","CountryCode":"UGA","FullCurrencyName":"Ugandan Shilling","PMID":"144"},"UAH":{"ID":"121","Country":"Ukraine","Currency":"Hryvna","Symbol":"₴","CountryCode":"UKR","FullCurrencyName":"Ukraine Hryvnia","PMID":"145"},"AED":{"ID":"122","Country":"United Arab Emirates","Currency":"Dirham_United Arab Emirates","Symbol":" د.إ.‏","CountryCode":"ARE","FullCurrencyName":"UAE Dirham","PMID":"69"},"GBP":{"ID":"123","Country":"Great Britain","Currency":"Pound_United Kingdom","Symbol":"£","CountryCode":"GBR","FullCurrencyName":"British Pound","PMID":"3"},"USD":{"ID":"124","Country":"United States","Currency":"Dollar_United States","Symbol":"$","CountryCode":"USA","FullCurrencyName":"United States Dollar","PMID":"1"},"UYU":{"ID":"125","Country":"Uruguay","Currency":"Peso_Uruguay","Symbol":"$U","CountryCode":"URY","FullCurrencyName":"Uruguayan New Peso","PMID":"146"},"UZS":{"ID":"126","Country":"Uzbekistan","Currency":"Som_Uzbekistan","Symbol":"лв","CountryCode":"UZB","FullCurrencyName":"Uzbekistan Som","PMID":"147"},"VES":{"ID":"127","Country":"Venezuela","Currency":"Bolivar Soberano","Symbol":"Bs. S","CountryCode":"VEN","FullCurrencyName":"Venezuelan Bolivar Soberano","PMID":"43"},"VND":{"ID":"128","Country":"Vietnam","Currency":"Dong","Symbol":"₫","CountryCode":"VNM","FullCurrencyName":"Vietnam Dong","PMID":"70"},"YER":{"ID":"129","Country":"Yemen","Currency":"Rial_Yemen","Symbol":"ر.ي.‏","CountryCode":"YEM","FullCurrencyName":"Yemen Riyal","PMID":"150"},"ZMK":{"ID":"130","Country":"Zambia","Currency":"Kwacha_Zambia","Symbol":"ZK","CountryCode":"ZMB","FullCurrencyName":"Zambian Kwacha","PMID":"151"},"XCD":{"ID":"132","Country":"OECS","Currency":"Dollar_OECS","Symbol":"EC$","CountryCode":"XCD","FullCurrencyName":"East Caribbean Dollar","PMID":"NA"},"XPF":{"ID":"133","Country":"CFP Franc","Currency":"Franc_CFP","Symbol":"F","CountryCode":"XPF","FullCurrencyName":"Central Pacific Franc","PMID":"NA"},"XAF":{"ID":"134","Country":"Central Africa","Currency":"Franc_CFA","Symbol":"FCFA","CountryCode":"XAF","FullCurrencyName":"Central African Franc","PMID":"NA"},"CUP":{"ID":"135","Country":"Cuba","Currency":"Peso_Cuba","Symbol":"$","CountryCode":"CUB","FullCurrencyName":"Peso Cuba","PMID":"NA"},"XOF":{"ID":"136","Country":"Western Africa","Currency":"Franc_CFA","Symbol":"CFA","CountryCode":"XOF","FullCurrencyName":"Western African Franc","PMID":"NA"},"SDG":{"ID":"137","Country":"Sudan","Currency":"Pound_Sudan","Symbol":"junaih","CountryCode":"SD","FullCurrencyName":"Sudanese Pound","PMID":"NA"},"BCH":{"ID":"138","Country":"","Currency":"Bitcoin Cash","Symbol":"","CountryCode":"","FullCurrencyName":"Bitcoin Cash","PMID":"NA"},"BTC":{"ID":"139","Country":"","Currency":"Bitcoin","Symbol":"","CountryCode":"","FullCurrencyName":"Bitcoin","PMID":"NA"},"ETH":{"ID":"140","Country":"","Currency":"Ethereum","Symbol":"","CountryCode":"","FullCurrencyName":"Ethereum","PMID":"NA"},"LTC":{"ID":"141","Country":"","Currency":"Litecoin","Symbol":"","CountryCode":"","FullCurrencyName":"Litecoin","PMID":"NA"},"XRP":{"ID":"142","Country":"","Currency":"Ripple","Symbol":"","CountryCode":"","FullCurrencyName":"Ripple","PMID":"NA"}}));
            currencyConverterDefaults.localeSettings = $.extend(true, {}, settings);
            currencyConverterDefaults.textBoxLocaleSettings = $.extend(true, {}, settings);
            currencyConverterDefaults.localeSettings.numberDecimalDigits = 4;
            currencyConverterDefaults.baseFrom = 'USD';
currencyConverterDefaults.baseTo = 'VND';
currencyConverterDefaults.baseFromValue = '1,00';
            return currencyConverterDefaults;
        });

        require(["CurrencyConverter", "c.deferred"], function (currencyConverter) {
            currencyConverter.renderCurrency();
        });
    </script>
 <div id="crrncycnvrtr" data-id="33" data-m="{&quot;i&quot;:33,&quot;p&quot;:32,&quot;n&quot;:&quot;currencyconvertermodule&quot;,&quot;t&quot;:&quot;CurrencyConverterServiceModule&quot;,&quot;o&quot;:1}">
 
<div class="crrncyheader">
<h1><span id="cchdng">Chuyển đổi Tiền tệ</span></h1>
</div>
 <div class="cconverter">
<div id="frmsection" class="ccsection">
<span id="frmrate" class="ccrate">1 USD = 23.132,0842 VND</span>
<div id="frmlist" class="cclist">
<div class="flagspace"><div id="frmflag" aria-hidden="true" class="hasflag" style="background-size: 864rem 5.3rem; background-position: -747rem -1rem;"><span>&nbsp;</span></div></div>
<div class="frmdropdown">
<select id="frmmenu" class="ccmenu" title="Chỉnh sửa Từ giá trị tiền tệ">
 <option value="BTC" data-id="34" data-m="{&quot;i&quot;:34,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBTC&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:1}">Bitcoin</option>
 <option value="BCH" data-id="35" data-m="{&quot;i&quot;:35,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBCH&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:2}">Bitcoin Cash</option>
 <option value="LBP" data-id="36" data-m="{&quot;i&quot;:36,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryLBP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:3}">Bảng Anh của Li-Băng</option>
 <option value="ETH" data-id="37" data-m="{&quot;i&quot;:37,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryETH&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:4}">Ethereum</option>
 <option value="EUR" data-id="38" data-m="{&quot;i&quot;:38,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryEUR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:5}">Euro</option>
 <option value="LTC" data-id="39" data-m="{&quot;i&quot;:39,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryLTC&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:6}">Litecoin</option>
 <option value="VES" data-id="40" data-m="{&quot;i&quot;:40,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryVES&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:7}">Venezuelan Bolivar Soberano</option>
 <option value="AFN" data-id="41" data-m="{&quot;i&quot;:41,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryAFN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:8}">Đồng Afghani của Afghanistan</option>
 <option value="THB" data-id="42" data-m="{&quot;i&quot;:42,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryTHB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:9}">Đồng Baht của Thái Lan</option>
 <option value="PAB" data-id="43" data-m="{&quot;i&quot;:43,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryPAB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:10}">Đồng Balboa của Panama</option>
 <option value="ETB" data-id="44" data-m="{&quot;i&quot;:44,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryETB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:11}">Đồng Birr của Ethiopia</option>
 <option value="BOB" data-id="45" data-m="{&quot;i&quot;:45,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBOB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:12}">Đồng Boliviano của Bolivia</option>
 <option value="CRC" data-id="46" data-m="{&quot;i&quot;:46,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCRC&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:13}">Đồng Colon của Costa Rica</option>
 <option value="NIO" data-id="47" data-m="{&quot;i&quot;:47,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryNIO&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:14}">Đồng Cordoba của Nicaragua</option>
 <option value="GMD" data-id="48" data-m="{&quot;i&quot;:48,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryGMD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:15}">Đồng Dalasi của Gambia</option>
 <option value="MKD" data-id="49" data-m="{&quot;i&quot;:49,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMKD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:16}">Đồng Denar của Macedonia</option>
 <option value="MAD" data-id="50" data-m="{&quot;i&quot;:50,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMAD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:17}">Đồng Dirham của Morocco</option>
 <option value="AED" data-id="51" data-m="{&quot;i&quot;:51,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryAED&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:18}">Đồng Dirham của các Tiểu Vương quốc Ả Rập Thống nhất</option>
 <option value="CVE" data-id="52" data-m="{&quot;i&quot;:52,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCVE&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:19}">Đồng Escudo của Cape Verde</option>
 <option value="AWG" data-id="53" data-m="{&quot;i&quot;:53,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryAWG&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:20}">Đồng Florin của Aruba</option>
 <option value="HUF" data-id="54" data-m="{&quot;i&quot;:54,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryHUF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:21}">Đồng Forint của Hungary</option>
 <option value="BIF" data-id="55" data-m="{&quot;i&quot;:55,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBIF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:22}">Đồng Franc của Burundi</option>
 <option value="KMF" data-id="56" data-m="{&quot;i&quot;:56,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryKMF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:23}">Đồng Franc của Comoros</option>
 <option value="CDF" data-id="57" data-m="{&quot;i&quot;:57,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCDF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:24}">Đồng Franc của Congo</option>
 <option value="DJF" data-id="58" data-m="{&quot;i&quot;:58,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryDJF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:25}">Đồng Franc của Dijibouti</option>
 <option value="GNF" data-id="59" data-m="{&quot;i&quot;:59,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryGNF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:26}">Đồng Franc của Guinea</option>
 <option value="RWF" data-id="60" data-m="{&quot;i&quot;:60,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryRWF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:27}">Đồng Franc của Rwanda</option>
 <option value="CHF" data-id="61" data-m="{&quot;i&quot;:61,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCHF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:28}">Đồng Franc của Thụy sĩ</option>
 <option value="HTG" data-id="62" data-m="{&quot;i&quot;:62,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryHTG&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:29}">Đồng Gourde của Haiti</option>
 <option value="PYG" data-id="63" data-m="{&quot;i&quot;:63,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryPYG&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:30}">Đồng Guarani của Paraguay</option>
 <option value="UAH" data-id="64" data-m="{&quot;i&quot;:64,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryUAH&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:31}">Đồng Hryvnia của Ukraine</option>
 <option value="PGK" data-id="65" data-m="{&quot;i&quot;:65,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryPGK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:32}">Đồng Kina của Papua New Guinea</option>
 <option value="CZK" data-id="66" data-m="{&quot;i&quot;:66,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCZK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:33}">Đồng Koruna của Séc</option>
 <option value="ISK" data-id="67" data-m="{&quot;i&quot;:67,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryISK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:34}">Đồng Krona của Iceland</option>
 <option value="NOK" data-id="68" data-m="{&quot;i&quot;:68,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryNOK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:35}">Đồng Krone của Na Uy</option>
 <option value="DKK" data-id="69" data-m="{&quot;i&quot;:69,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryDKK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:36}">Đồng Krone của Đan Mạch</option>
 <option value="HRK" data-id="70" data-m="{&quot;i&quot;:70,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryHRK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:37}">Đồng Kuna của Croatia</option>
 <option value="MWK" data-id="71" data-m="{&quot;i&quot;:71,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMWK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:38}">Đồng Kwacha của Malawi</option>
 <option value="MMK" data-id="72" data-m="{&quot;i&quot;:72,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMMK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:39}">Đồng Kyat của Myanmar</option>
 <option value="LAK" data-id="73" data-m="{&quot;i&quot;:73,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryLAK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:40}">Đồng Kíp của Lào</option>
 <option value="GEL" data-id="74" data-m="{&quot;i&quot;:74,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryGEL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:41}">Đồng Lari của Georgia</option>
 <option value="ALL" data-id="75" data-m="{&quot;i&quot;:75,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryALL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:42}">Đồng Lek của Albania</option>
 <option value="HNL" data-id="76" data-m="{&quot;i&quot;:76,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryHNL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:43}">Đồng Lempira của Honduras</option>
 <option value="SLL" data-id="77" data-m="{&quot;i&quot;:77,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountrySLL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:44}">Đồng Leone của Sierra Leone</option>
 <option value="RON" data-id="78" data-m="{&quot;i&quot;:78,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryRON&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:45}">Đồng Leu Mới của Romance</option>
 <option value="MDL" data-id="79" data-m="{&quot;i&quot;:79,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMDL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:46}">Đồng Leu của Moldova</option>
 <option value="BGN" data-id="80" data-m="{&quot;i&quot;:80,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBGN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:47}">Đồng Lev của Bulgaria</option>
 <option value="TRY" data-id="81" data-m="{&quot;i&quot;:81,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryTRY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:48}">Đồng Lia của Thổ Nhĩ Kỳ</option>
 <option value="SZL" data-id="82" data-m="{&quot;i&quot;:82,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountrySZL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:49}">Đồng Lilageni của Swaziland</option>
 <option value="LSL" data-id="83" data-m="{&quot;i&quot;:83,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryLSL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:50}">Đồng Loti của Lesotho</option>
 <option value="MGA" data-id="84" data-m="{&quot;i&quot;:84,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMGA&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:51}">Đồng Malagasy Ariary của Madagascar</option>
 <option value="AZN" data-id="85" data-m="{&quot;i&quot;:85,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryAZN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:52}">Đồng Manat Mới của Azerbaijan</option>
 <option value="TMT" data-id="86" data-m="{&quot;i&quot;:86,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryTMT&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:53}">Đồng Manat của Turkmenistan</option>
 <option value="BAM" data-id="87" data-m="{&quot;i&quot;:87,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBAM&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:54}">Đồng Marka Có thể chuyển đổi của Bosnia và Herzegovina</option>
 <option value="MZN" data-id="88" data-m="{&quot;i&quot;:88,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMZN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:55}">Đồng Metical của Mozambique</option>
 <option value="NGN" data-id="89" data-m="{&quot;i&quot;:89,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryNGN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:56}">Đồng Naira của Nigeria</option>
 <option value="PEN" data-id="90" data-m="{&quot;i&quot;:90,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryPEN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:57}">Đồng Nuevo Sol của Peruvia</option>
 <option value="MOP" data-id="91" data-m="{&quot;i&quot;:91,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMOP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:58}">Đồng Pataca của Macau</option>
 <option value="UYU" data-id="92" data-m="{&quot;i&quot;:92,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryUYU&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:59}">Đồng Peso Mới của Uruguay</option>
 <option value="ARS" data-id="93" data-m="{&quot;i&quot;:93,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryARS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:60}">Đồng Peso của Argentine</option>
 <option value="CLP" data-id="94" data-m="{&quot;i&quot;:94,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCLP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:61}">Đồng Peso của Chi Lê</option>
 <option value="COP" data-id="95" data-m="{&quot;i&quot;:95,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCOP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:62}">Đồng Peso của Colombia</option>
 <option value="DOP" data-id="96" data-m="{&quot;i&quot;:96,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryDOP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:63}">Đồng Peso của Dominica</option>
 <option value="MXN" data-id="97" data-m="{&quot;i&quot;:97,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMXN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:64}">Đồng Peso của Mexico</option>
 <option value="PHP" data-id="98" data-m="{&quot;i&quot;:98,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryPHP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:65}">Đồng Peso của Philippine</option>
 <option value="GTQ" data-id="99" data-m="{&quot;i&quot;:99,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryGTQ&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:66}">Đồng Quetzal của Guatemala</option>
 <option value="ZAR" data-id="100" data-m="{&quot;i&quot;:100,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryZAR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:67}">Đồng Rand của Nam Phi</option>
 <option value="OMR" data-id="101" data-m="{&quot;i&quot;:101,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryOMR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:68}">Đồng Rial của Omani</option>
 <option value="QAR" data-id="102" data-m="{&quot;i&quot;:102,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryQAR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:69}">Đồng Rial của Qatar</option>
 <option value="KHR" data-id="103" data-m="{&quot;i&quot;:103,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryKHR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:70}">Đồng Riel của Cam-pu-chia</option>
 <option value="MYR" data-id="104" data-m="{&quot;i&quot;:104,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMYR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:71}">Đồng Ringgit của Malaysia</option>
 <option value="YER" data-id="105" data-m="{&quot;i&quot;:105,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryYER&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:72}">Đồng Riyal của Yemen</option>
 <option value="SAR" data-id="106" data-m="{&quot;i&quot;:106,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountrySAR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:73}">Đồng Riyal của Ả-rập Xê-út</option>
 <option value="MVR" data-id="107" data-m="{&quot;i&quot;:107,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMVR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:74}">Đồng Rufiyaa của Maldives</option>
 <option value="MUR" data-id="108" data-m="{&quot;i&quot;:108,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryMUR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:75}">Đồng Rupi của Mauritius</option>
 <option value="NPR" data-id="109" data-m="{&quot;i&quot;:109,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryNPR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:76}">Đồng Rupi của Nepal</option>
 <option value="PKR" data-id="110" data-m="{&quot;i&quot;:110,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryPKR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:77}">Đồng Rupi của Pakistani</option>
 <option value="SCR" data-id="111" data-m="{&quot;i&quot;:111,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountrySCR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:78}">Đồng Rupi của Seychelles</option>
 <option value="LKR" data-id="112" data-m="{&quot;i&quot;:112,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryLKR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:79}">Đồng Rupi của Sri Lanka</option>
 <option value="INR" data-id="113" data-m="{&quot;i&quot;:113,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryINR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:80}">Đồng Rupi của Ấn Độ</option>
 <option value="IDR" data-id="114" data-m="{&quot;i&quot;:114,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryIDR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:81}">Đồng Rupia của Indonesia</option>
 <option value="RUB" data-id="115" data-m="{&quot;i&quot;:115,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryRUB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:82}">Đồng Rúp của Nga</option>
 <option value="ILS" data-id="116" data-m="{&quot;i&quot;:116,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryILS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:83}">Đồng Shekel của Israeli</option>
 <option value="KES" data-id="117" data-m="{&quot;i&quot;:117,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryKES&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:84}">Đồng Shilling của Kenya</option>
 <option value="SOS" data-id="118" data-m="{&quot;i&quot;:118,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountrySOS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:85}">Đồng Shilling của Somali</option>
 <option value="TZS" data-id="119" data-m="{&quot;i&quot;:119,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryTZS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:86}">Đồng Shilling của Tanzania </option>
 <option value="UGX" data-id="120" data-m="{&quot;i&quot;:120,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryUGX&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:87}">Đồng Shilling của Uganda</option>
 <option value="UZS" data-id="121" data-m="{&quot;i&quot;:121,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryUZS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:88}">Đồng Som của Uzbekistan</option>
 <option value="BDT" data-id="122" data-m="{&quot;i&quot;:122,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBDT&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:89}">Đồng Taka của Bangladesh</option>
 <option value="KZT" data-id="123" data-m="{&quot;i&quot;:123,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryKZT&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:90}">Đồng Tenge của Kazakhstan</option>
 <option value="KRW" data-id="124" data-m="{&quot;i&quot;:124,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryKRW&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:91}">Đồng Won của Hàn Quốc</option>
 <option value="CNY" data-id="125" data-m="{&quot;i&quot;:125,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryCNY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:92}">Đồng Yuan của Trung Quốc (RMB)</option>
 <option value="JPY" data-id="126" data-m="{&quot;i&quot;:126,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryJPY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:93}">Đồng Yên Nhật</option>
 <option value="PLN" data-id="127" data-m="{&quot;i&quot;:127,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryPLN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:94}">Đồng Zloty của Ba Lan</option>
 <option value="GBP" data-id="128" data-m="{&quot;i&quot;:128,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryGBP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:95}">Đồng bảng Anh</option>
 <option value="EGP" data-id="129" data-m="{&quot;i&quot;:129,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryEGP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:96}">Đồng bảng của Ai Cập</option>
 <option value="SHP" data-id="130" data-m="{&quot;i&quot;:130,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountrySHP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:97}">Đồng bảng của Saint Helena Ascension và Tristan da Cunha</option>
 <option value="VND" data-id="131" data-m="{&quot;i&quot;:131,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryVND&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:98}">Đồng của Việt Nam</option>
 <option value="BWP" data-id="132" data-m="{&quot;i&quot;:132,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBWP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:99}">Đồng pula của Botswana</option>
 <option value="DZD" data-id="133" data-m="{&quot;i&quot;:133,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryDZD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:100}">Đồng Đina của Algeria</option>
 <option value="BHD" data-id="134" data-m="{&quot;i&quot;:134,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBHD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:101}">Đồng Đina của Bahraini</option>
 <option value="IQD" data-id="135" data-m="{&quot;i&quot;:135,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryIQD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:102}">Đồng Đina của Iraqi</option>
 <option value="JOD" data-id="136" data-m="{&quot;i&quot;:136,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryJOD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:103}">Đồng Đina của Jordani</option>
 <option value="KWD" data-id="137" data-m="{&quot;i&quot;:137,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryKWD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:104}">Đồng Đina của Kuwait</option>
 <option value="LYD" data-id="138" data-m="{&quot;i&quot;:138,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryLYD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:105}">Đồng Đina của Li-Băng</option>
 <option value="RSD" data-id="139" data-m="{&quot;i&quot;:139,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryRSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:106}">Đồng Đina của Serbia</option>
 <option value="TND" data-id="140" data-m="{&quot;i&quot;:140,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryTND&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:107}">Đồng Đina của Tunisia</option>
 <option value="BSD" data-id="141" data-m="{&quot;i&quot;:141,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:108}">Đồng Đô la của Bahamas</option>
 <option value="BBD" data-id="142" data-m="{&quot;i&quot;:142,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBBD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:109}">Đồng Đô la của Barbados</option>
 <option value="BZD" data-id="143" data-m="{&quot;i&quot;:143,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBZD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:110}">Đồng Đô la của Belize</option>
 <option value="BMD" data-id="144" data-m="{&quot;i&quot;:144,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBMD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:111}">Đồng Đô la của Bermuda</option>
 <option value="BND" data-id="145" data-m="{&quot;i&quot;:145,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryBND&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:112}">Đồng Đô la của Brunei</option>
 <option value="FJD" data-id="146" data-m="{&quot;i&quot;:146,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryFJD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:113}">Đồng Đô la của Fiji</option>
 <option value="USD" selected="" data-id="147" data-m="{&quot;i&quot;:147,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryUSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:114}">Đồng Đô la của Hoa Kỳ</option>
 <option value="HKD" data-id="148" data-m="{&quot;i&quot;:148,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryHKD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:115}">Đồng Đô la của Hồng Kông</option>
 <option value="JMD" data-id="149" data-m="{&quot;i&quot;:149,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryJMD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:116}">Đồng Đô la của Jamaica</option>
 <option value="LRD" data-id="150" data-m="{&quot;i&quot;:150,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryLRD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:117}">Đồng Đô la của Liberia</option>
 <option value="NAD" data-id="151" data-m="{&quot;i&quot;:151,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryNAD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:118}">Đồng Đô la của Namibia</option>
 <option value="NZD" data-id="152" data-m="{&quot;i&quot;:152,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryNZD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:119}">Đồng Đô la của New Zealand</option>
 <option value="KYD" data-id="153" data-m="{&quot;i&quot;:153,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryKYD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:120}">Đồng Đô la của Quần đảo Cayman</option>
 <option value="SGD" data-id="154" data-m="{&quot;i&quot;:154,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountrySGD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:121}">Đồng Đô la của Singapore</option>
 <option value="TTD" data-id="155" data-m="{&quot;i&quot;:155,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryTTD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:122}">Đồng Đô la của Trinidad và Tobago</option>
 <option value="AUD" data-id="156" data-m="{&quot;i&quot;:156,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryAUD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:123}">Đồng Đô la của Úc</option>
 <option value="TWD" data-id="157" data-m="{&quot;i&quot;:157,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCountryTWD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:124}">Đồng Đô la Đài Loan</option>
                            </select>
                        </div>
                    </div>
                    <div id="frminput" class="ccinput">
<span id="frmccsymbol" class="ccsymbol">$</span>
<input id="frmtxtbx" class="cctxtbx" value="1,00" style="font-size: 4.2rem" data-id="158" data-m="{&quot;i&quot;:158,&quot;p&quot;:33,&quot;n&quot;:&quot;FromInput&quot;,&quot;t&quot;:&quot;Input&quot;,&quot;o&quot;:125}">
</div>
<div id="frmcurrhint" title="Quy đổi Nhanh từ">
 <a href="#" class="cchints" data-id="159" data-m="{&quot;i&quot;:159,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCurrencyHintUSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:126}">USD</a>
 <a href="#" class="cchints" data-id="160" data-m="{&quot;i&quot;:160,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCurrencyHintJPY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:127}">JPY</a>
 <a href="#" class="cchints" data-id="161" data-m="{&quot;i&quot;:161,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCurrencyHintCNY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:128}">CNY</a>
 <a href="#" class="cchints" data-id="162" data-m="{&quot;i&quot;:162,&quot;p&quot;:33,&quot;n&quot;:&quot;FromCurrencyHintEUR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:129}">EUR</a>
                    </div>
                </div>
                <div id="equalssign">
<button type="button" id="swapbutton" title="Hoán đổi Tiền tệ Quy đổi từ và Quy đổi sang" aria-label="Hoán đổi Tiền tệ Quy đổi từ và Quy đổi sang" data-id="163" data-m="{&quot;i&quot;:163,&quot;p&quot;:33,&quot;n&quot;:&quot;SwapButton&quot;,&quot;t&quot;:&quot;Button&quot;,&quot;o&quot;:130}" class="swapbutton">&nbsp;</button>
</div>
<div id="tosection" class="ccsection">
<span id="torate" class="ccrate">1 VND = 0,0000 USD</span>
<div id="tolist" class="cclist">
<div class="flagspace"><div id="toflag" aria-hidden="true" class="hasflag" style="background-size: 864rem 5.3rem; background-position: -771rem -1rem;"><span>&nbsp;</span></div></div>
<div class="todropdown">
<select id="tomenu" class="ccmenu" title="Chỉnh sửa Thành giá trị tiền tệ">
 <option value="BTC" data-id="164" data-m="{&quot;i&quot;:164,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBTC&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:131}">Bitcoin</option>
 <option value="BCH" data-id="165" data-m="{&quot;i&quot;:165,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBCH&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:132}">Bitcoin Cash</option>
 <option value="LBP" data-id="166" data-m="{&quot;i&quot;:166,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryLBP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:133}">Bảng Anh của Li-Băng</option>
 <option value="ETH" data-id="167" data-m="{&quot;i&quot;:167,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryETH&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:134}">Ethereum</option>
 <option value="EUR" data-id="168" data-m="{&quot;i&quot;:168,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryEUR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:135}">Euro</option>
 <option value="LTC" data-id="169" data-m="{&quot;i&quot;:169,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryLTC&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:136}">Litecoin</option>
 <option value="VES" data-id="170" data-m="{&quot;i&quot;:170,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryVES&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:137}">Venezuelan Bolivar Soberano</option>
 <option value="AFN" data-id="171" data-m="{&quot;i&quot;:171,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryAFN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:138}">Đồng Afghani của Afghanistan</option>
 <option value="THB" data-id="172" data-m="{&quot;i&quot;:172,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryTHB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:139}">Đồng Baht của Thái Lan</option>
 <option value="PAB" data-id="173" data-m="{&quot;i&quot;:173,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryPAB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:140}">Đồng Balboa của Panama</option>
 <option value="ETB" data-id="174" data-m="{&quot;i&quot;:174,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryETB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:141}">Đồng Birr của Ethiopia</option>
 <option value="BOB" data-id="175" data-m="{&quot;i&quot;:175,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBOB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:142}">Đồng Boliviano của Bolivia</option>
 <option value="CRC" data-id="176" data-m="{&quot;i&quot;:176,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCRC&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:143}">Đồng Colon của Costa Rica</option>
 <option value="NIO" data-id="177" data-m="{&quot;i&quot;:177,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryNIO&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:144}">Đồng Cordoba của Nicaragua</option>
 <option value="GMD" data-id="178" data-m="{&quot;i&quot;:178,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryGMD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:145}">Đồng Dalasi của Gambia</option>
 <option value="MKD" data-id="179" data-m="{&quot;i&quot;:179,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMKD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:146}">Đồng Denar của Macedonia</option>
 <option value="MAD" data-id="180" data-m="{&quot;i&quot;:180,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMAD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:147}">Đồng Dirham của Morocco</option>
 <option value="AED" data-id="181" data-m="{&quot;i&quot;:181,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryAED&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:148}">Đồng Dirham của các Tiểu Vương quốc Ả Rập Thống nhất</option>
 <option value="CVE" data-id="182" data-m="{&quot;i&quot;:182,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCVE&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:149}">Đồng Escudo của Cape Verde</option>
 <option value="AWG" data-id="183" data-m="{&quot;i&quot;:183,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryAWG&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:150}">Đồng Florin của Aruba</option>
 <option value="HUF" data-id="184" data-m="{&quot;i&quot;:184,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryHUF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:151}">Đồng Forint của Hungary</option>
 <option value="BIF" data-id="185" data-m="{&quot;i&quot;:185,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBIF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:152}">Đồng Franc của Burundi</option>
 <option value="KMF" data-id="186" data-m="{&quot;i&quot;:186,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryKMF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:153}">Đồng Franc của Comoros</option>
 <option value="CDF" data-id="187" data-m="{&quot;i&quot;:187,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCDF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:154}">Đồng Franc của Congo</option>
 <option value="DJF" data-id="188" data-m="{&quot;i&quot;:188,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryDJF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:155}">Đồng Franc của Dijibouti</option>
 <option value="GNF" data-id="189" data-m="{&quot;i&quot;:189,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryGNF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:156}">Đồng Franc của Guinea</option>
 <option value="RWF" data-id="190" data-m="{&quot;i&quot;:190,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryRWF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:157}">Đồng Franc của Rwanda</option>
 <option value="CHF" data-id="191" data-m="{&quot;i&quot;:191,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCHF&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:158}">Đồng Franc của Thụy sĩ</option>
 <option value="HTG" data-id="192" data-m="{&quot;i&quot;:192,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryHTG&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:159}">Đồng Gourde của Haiti</option>
 <option value="PYG" data-id="193" data-m="{&quot;i&quot;:193,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryPYG&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:160}">Đồng Guarani của Paraguay</option>
 <option value="UAH" data-id="194" data-m="{&quot;i&quot;:194,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryUAH&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:161}">Đồng Hryvnia của Ukraine</option>
 <option value="PGK" data-id="195" data-m="{&quot;i&quot;:195,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryPGK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:162}">Đồng Kina của Papua New Guinea</option>
 <option value="CZK" data-id="196" data-m="{&quot;i&quot;:196,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCZK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:163}">Đồng Koruna của Séc</option>
 <option value="ISK" data-id="197" data-m="{&quot;i&quot;:197,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryISK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:164}">Đồng Krona của Iceland</option>
 <option value="NOK" data-id="198" data-m="{&quot;i&quot;:198,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryNOK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:165}">Đồng Krone của Na Uy</option>
 <option value="DKK" data-id="199" data-m="{&quot;i&quot;:199,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryDKK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:166}">Đồng Krone của Đan Mạch</option>
 <option value="HRK" data-id="200" data-m="{&quot;i&quot;:200,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryHRK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:167}">Đồng Kuna của Croatia</option>
 <option value="MWK" data-id="201" data-m="{&quot;i&quot;:201,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMWK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:168}">Đồng Kwacha của Malawi</option>
 <option value="MMK" data-id="202" data-m="{&quot;i&quot;:202,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMMK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:169}">Đồng Kyat của Myanmar</option>
 <option value="LAK" data-id="203" data-m="{&quot;i&quot;:203,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryLAK&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:170}">Đồng Kíp của Lào</option>
 <option value="GEL" data-id="204" data-m="{&quot;i&quot;:204,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryGEL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:171}">Đồng Lari của Georgia</option>
 <option value="ALL" data-id="205" data-m="{&quot;i&quot;:205,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryALL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:172}">Đồng Lek của Albania</option>
 <option value="HNL" data-id="206" data-m="{&quot;i&quot;:206,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryHNL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:173}">Đồng Lempira của Honduras</option>
 <option value="SLL" data-id="207" data-m="{&quot;i&quot;:207,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountrySLL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:174}">Đồng Leone của Sierra Leone</option>
 <option value="RON" data-id="208" data-m="{&quot;i&quot;:208,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryRON&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:175}">Đồng Leu Mới của Romance</option>
 <option value="MDL" data-id="209" data-m="{&quot;i&quot;:209,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMDL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:176}">Đồng Leu của Moldova</option>
 <option value="BGN" data-id="210" data-m="{&quot;i&quot;:210,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBGN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:177}">Đồng Lev của Bulgaria</option>
 <option value="TRY" data-id="211" data-m="{&quot;i&quot;:211,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryTRY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:178}">Đồng Lia của Thổ Nhĩ Kỳ</option>
 <option value="SZL" data-id="212" data-m="{&quot;i&quot;:212,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountrySZL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:179}">Đồng Lilageni của Swaziland</option>
 <option value="LSL" data-id="213" data-m="{&quot;i&quot;:213,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryLSL&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:180}">Đồng Loti của Lesotho</option>
 <option value="MGA" data-id="214" data-m="{&quot;i&quot;:214,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMGA&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:181}">Đồng Malagasy Ariary của Madagascar</option>
 <option value="AZN" data-id="215" data-m="{&quot;i&quot;:215,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryAZN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:182}">Đồng Manat Mới của Azerbaijan</option>
 <option value="TMT" data-id="216" data-m="{&quot;i&quot;:216,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryTMT&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:183}">Đồng Manat của Turkmenistan</option>
 <option value="BAM" data-id="217" data-m="{&quot;i&quot;:217,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBAM&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:184}">Đồng Marka Có thể chuyển đổi của Bosnia và Herzegovina</option>
 <option value="MZN" data-id="218" data-m="{&quot;i&quot;:218,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMZN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:185}">Đồng Metical của Mozambique</option>
 <option value="NGN" data-id="219" data-m="{&quot;i&quot;:219,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryNGN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:186}">Đồng Naira của Nigeria</option>
 <option value="PEN" data-id="220" data-m="{&quot;i&quot;:220,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryPEN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:187}">Đồng Nuevo Sol của Peruvia</option>
 <option value="MOP" data-id="221" data-m="{&quot;i&quot;:221,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMOP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:188}">Đồng Pataca của Macau</option>
 <option value="UYU" data-id="222" data-m="{&quot;i&quot;:222,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryUYU&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:189}">Đồng Peso Mới của Uruguay</option>
 <option value="ARS" data-id="223" data-m="{&quot;i&quot;:223,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryARS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:190}">Đồng Peso của Argentine</option>
 <option value="CLP" data-id="224" data-m="{&quot;i&quot;:224,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCLP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:191}">Đồng Peso của Chi Lê</option>
 <option value="COP" data-id="225" data-m="{&quot;i&quot;:225,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCOP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:192}">Đồng Peso của Colombia</option>
 <option value="DOP" data-id="226" data-m="{&quot;i&quot;:226,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryDOP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:193}">Đồng Peso của Dominica</option>
 <option value="MXN" data-id="227" data-m="{&quot;i&quot;:227,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMXN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:194}">Đồng Peso của Mexico</option>
 <option value="PHP" data-id="228" data-m="{&quot;i&quot;:228,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryPHP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:195}">Đồng Peso của Philippine</option>
 <option value="GTQ" data-id="229" data-m="{&quot;i&quot;:229,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryGTQ&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:196}">Đồng Quetzal của Guatemala</option>
 <option value="ZAR" data-id="230" data-m="{&quot;i&quot;:230,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryZAR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:197}">Đồng Rand của Nam Phi</option>
 <option value="OMR" data-id="231" data-m="{&quot;i&quot;:231,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryOMR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:198}">Đồng Rial của Omani</option>
 <option value="QAR" data-id="232" data-m="{&quot;i&quot;:232,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryQAR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:199}">Đồng Rial của Qatar</option>
 <option value="KHR" data-id="233" data-m="{&quot;i&quot;:233,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryKHR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:200}">Đồng Riel của Cam-pu-chia</option>
 <option value="MYR" data-id="234" data-m="{&quot;i&quot;:234,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMYR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:201}">Đồng Ringgit của Malaysia</option>
 <option value="YER" data-id="235" data-m="{&quot;i&quot;:235,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryYER&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:202}">Đồng Riyal của Yemen</option>
 <option value="SAR" data-id="236" data-m="{&quot;i&quot;:236,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountrySAR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:203}">Đồng Riyal của Ả-rập Xê-út</option>
 <option value="MVR" data-id="237" data-m="{&quot;i&quot;:237,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMVR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:204}">Đồng Rufiyaa của Maldives</option>
 <option value="MUR" data-id="238" data-m="{&quot;i&quot;:238,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryMUR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:205}">Đồng Rupi của Mauritius</option>
 <option value="NPR" data-id="239" data-m="{&quot;i&quot;:239,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryNPR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:206}">Đồng Rupi của Nepal</option>
 <option value="PKR" data-id="240" data-m="{&quot;i&quot;:240,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryPKR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:207}">Đồng Rupi của Pakistani</option>
 <option value="SCR" data-id="241" data-m="{&quot;i&quot;:241,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountrySCR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:208}">Đồng Rupi của Seychelles</option>
 <option value="LKR" data-id="242" data-m="{&quot;i&quot;:242,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryLKR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:209}">Đồng Rupi của Sri Lanka</option>
 <option value="INR" data-id="243" data-m="{&quot;i&quot;:243,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryINR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:210}">Đồng Rupi của Ấn Độ</option>
 <option value="IDR" data-id="244" data-m="{&quot;i&quot;:244,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryIDR&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:211}">Đồng Rupia của Indonesia</option>
 <option value="RUB" data-id="245" data-m="{&quot;i&quot;:245,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryRUB&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:212}">Đồng Rúp của Nga</option>
 <option value="ILS" data-id="246" data-m="{&quot;i&quot;:246,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryILS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:213}">Đồng Shekel của Israeli</option>
 <option value="KES" data-id="247" data-m="{&quot;i&quot;:247,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryKES&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:214}">Đồng Shilling của Kenya</option>
 <option value="SOS" data-id="248" data-m="{&quot;i&quot;:248,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountrySOS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:215}">Đồng Shilling của Somali</option>
 <option value="TZS" data-id="249" data-m="{&quot;i&quot;:249,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryTZS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:216}">Đồng Shilling của Tanzania </option>
 <option value="UGX" data-id="250" data-m="{&quot;i&quot;:250,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryUGX&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:217}">Đồng Shilling của Uganda</option>
 <option value="UZS" data-id="251" data-m="{&quot;i&quot;:251,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryUZS&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:218}">Đồng Som của Uzbekistan</option>
 <option value="BDT" data-id="252" data-m="{&quot;i&quot;:252,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBDT&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:219}">Đồng Taka của Bangladesh</option>
 <option value="KZT" data-id="253" data-m="{&quot;i&quot;:253,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryKZT&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:220}">Đồng Tenge của Kazakhstan</option>
 <option value="KRW" data-id="254" data-m="{&quot;i&quot;:254,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryKRW&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:221}">Đồng Won của Hàn Quốc</option>
 <option value="CNY" data-id="255" data-m="{&quot;i&quot;:255,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryCNY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:222}">Đồng Yuan của Trung Quốc (RMB)</option>
 <option value="JPY" data-id="256" data-m="{&quot;i&quot;:256,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryJPY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:223}">Đồng Yên Nhật</option>
 <option value="PLN" data-id="257" data-m="{&quot;i&quot;:257,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryPLN&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:224}">Đồng Zloty của Ba Lan</option>
 <option value="GBP" data-id="258" data-m="{&quot;i&quot;:258,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryGBP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:225}">Đồng bảng Anh</option>
 <option value="EGP" data-id="259" data-m="{&quot;i&quot;:259,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryEGP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:226}">Đồng bảng của Ai Cập</option>
 <option value="SHP" data-id="260" data-m="{&quot;i&quot;:260,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountrySHP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:227}">Đồng bảng của Saint Helena Ascension và Tristan da Cunha</option>
 <option value="VND" selected="" data-id="261" data-m="{&quot;i&quot;:261,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryVND&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:228}">Đồng của Việt Nam</option>
 <option value="BWP" data-id="262" data-m="{&quot;i&quot;:262,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBWP&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:229}">Đồng pula của Botswana</option>
 <option value="DZD" data-id="263" data-m="{&quot;i&quot;:263,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryDZD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:230}">Đồng Đina của Algeria</option>
 <option value="BHD" data-id="264" data-m="{&quot;i&quot;:264,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBHD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:231}">Đồng Đina của Bahraini</option>
 <option value="IQD" data-id="265" data-m="{&quot;i&quot;:265,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryIQD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:232}">Đồng Đina của Iraqi</option>
 <option value="JOD" data-id="266" data-m="{&quot;i&quot;:266,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryJOD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:233}">Đồng Đina của Jordani</option>
 <option value="KWD" data-id="267" data-m="{&quot;i&quot;:267,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryKWD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:234}">Đồng Đina của Kuwait</option>
 <option value="LYD" data-id="268" data-m="{&quot;i&quot;:268,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryLYD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:235}">Đồng Đina của Li-Băng</option>
 <option value="RSD" data-id="269" data-m="{&quot;i&quot;:269,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryRSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:236}">Đồng Đina của Serbia</option>
 <option value="TND" data-id="270" data-m="{&quot;i&quot;:270,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryTND&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:237}">Đồng Đina của Tunisia</option>
 <option value="BSD" data-id="271" data-m="{&quot;i&quot;:271,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:238}">Đồng Đô la của Bahamas</option>
 <option value="BBD" data-id="272" data-m="{&quot;i&quot;:272,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBBD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:239}">Đồng Đô la của Barbados</option>
 <option value="BZD" data-id="273" data-m="{&quot;i&quot;:273,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBZD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:240}">Đồng Đô la của Belize</option>
 <option value="BMD" data-id="274" data-m="{&quot;i&quot;:274,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBMD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:241}">Đồng Đô la của Bermuda</option>
 <option value="BND" data-id="275" data-m="{&quot;i&quot;:275,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryBND&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:242}">Đồng Đô la của Brunei</option>
 <option value="FJD" data-id="276" data-m="{&quot;i&quot;:276,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryFJD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:243}">Đồng Đô la của Fiji</option>
 <option value="USD" data-id="277" data-m="{&quot;i&quot;:277,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryUSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:244}">Đồng Đô la của Hoa Kỳ</option>
 <option value="HKD" data-id="278" data-m="{&quot;i&quot;:278,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryHKD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:245}">Đồng Đô la của Hồng Kông</option>
 <option value="JMD" data-id="279" data-m="{&quot;i&quot;:279,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryJMD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:246}">Đồng Đô la của Jamaica</option>
 <option value="LRD" data-id="280" data-m="{&quot;i&quot;:280,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryLRD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:247}">Đồng Đô la của Liberia</option>
 <option value="NAD" data-id="281" data-m="{&quot;i&quot;:281,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryNAD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:248}">Đồng Đô la của Namibia</option>
 <option value="NZD" data-id="282" data-m="{&quot;i&quot;:282,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryNZD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:249}">Đồng Đô la của New Zealand</option>
 <option value="KYD" data-id="283" data-m="{&quot;i&quot;:283,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryKYD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:250}">Đồng Đô la của Quần đảo Cayman</option>
 <option value="SGD" data-id="284" data-m="{&quot;i&quot;:284,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountrySGD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:251}">Đồng Đô la của Singapore</option>
 <option value="TTD" data-id="285" data-m="{&quot;i&quot;:285,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryTTD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:252}">Đồng Đô la của Trinidad và Tobago</option>
 <option value="AUD" data-id="286" data-m="{&quot;i&quot;:286,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryAUD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:253}">Đồng Đô la của Úc</option>
 <option value="TWD" data-id="287" data-m="{&quot;i&quot;:287,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCountryTWD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:254}">Đồng Đô la Đài Loan</option>
                            </select>
                        </div>
                    </div>
                    <div id="toinput" class="ccinput">
<span id="toccsymbol" class="ccsymbol">₫</span>
<input id="totxtbx" class="cctxtbx" value="23.132,08" style="font-size: 4.2rem" data-id="288" data-m="{&quot;i&quot;:288,&quot;p&quot;:33,&quot;n&quot;:&quot;ToInput&quot;,&quot;t&quot;:&quot;Input&quot;,&quot;o&quot;:255}">
</div>
<div id="tocurrhint" title="Quy đổi Nhanh sang">
 <a href="#" class="cchints" data-id="289" data-m="{&quot;i&quot;:289,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCurrencyHintVND&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:256}">VND</a>
 <a href="#" class="cchints" data-id="290" data-m="{&quot;i&quot;:290,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCurrencyHintUSD&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:257}">USD</a>
 <a href="#" class="cchints" data-id="291" data-m="{&quot;i&quot;:291,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCurrencyHintJPY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:258}">JPY</a>
 <a href="#" class="cchints" data-id="292" data-m="{&quot;i&quot;:292,&quot;p&quot;:33,&quot;n&quot;:&quot;ToCurrencyHintCNY&quot;,&quot;t&quot;:&quot;Option&quot;,&quot;o&quot;:259}">CNY</a>
                    </div>
                </div>
            </div>
 
</div>
 <div class="cc-details" id="currency-details" aria-live="polite">
 


 <div class="cc-details-table">
<div class="containerborder">
 <div class="heading-text"></div>

 <div class="table-rows">
<ul>
 </ul>
<div class="table-data-rows">
<ul style="display: none"></ul>
<ul class="level0" style="" data-row-level="0" data-item-id="">
 <li style="width: 50%; " class="left-align  cc-details-heading" data-role="">
 <p class="truncated-string" title="Giá Mở cửa">Giá Mở cửa</p> 


 </li>
 <li style="width: 50%; " class="right-align  cc-details-value unchanged" data-role="">
 <p class="truncated-string" title="23.128,0000">23.128,0000</p> 


 </li>
 </ul>
<ul class="level0" style="" data-row-level="0" data-item-id="">
 <li style="width: 50%; " class="left-align  cc-details-heading" data-role="">
 <p class="truncated-string" title="Thay đổi">Thay đổi</p> 


 </li>
 <li style="width: 50%; " class="right-align  cc-details-value unchanged" data-role="">
 <p class="truncated-string" title="0,0000">0,0000</p> 


 </li>
 </ul>
<ul class="level0" style="" data-row-level="0" data-item-id="">
 <li style="width: 50%; " class="left-align  cc-details-heading" data-role="">
 <p class="truncated-string" title="Thay đổi%">Thay đổi%</p> 


 </li>
 <li style="width: 50%; " class="right-align  cc-details-value unchanged" data-role="">
 <p class="truncated-string" title="0,0000%">0,0000%</p> 


 </li>
 </ul>
<ul class="level0" style="" data-row-level="0" data-item-id="">
 <li style="width: 50%; " class="left-align  cc-details-heading" data-role="">
 <p class="truncated-string" title="52 Tuần Cao">52 Tuần Cao</p> 


 </li>
 <li style="width: 50%; " class="right-align  cc-details-value unchanged" data-role="">
 <p class="truncated-string" title="23.650,0000">23.650,0000</p> 


 </li>
 </ul>
<ul class="level0" style="" data-row-level="0" data-item-id="">
 <li style="width: 50%; " class="left-align  cc-details-heading" data-role="">
 <p class="truncated-string" title="52 Tuần Thấp">52 Tuần Thấp</p> 


 </li>
 <li style="width: 50%; " class="right-align  cc-details-value unchanged" data-role="">
 <p class="truncated-string" title="23.119,0000">23.119,0000</p> 


 </li>
 </ul>
 </div>
</div>
 <div class="footnote"></div>

</div>
</div>
    <script>
        require(["jquery", "binding", "jqBehavior", "mediator", "c.dom"], function ($, binding) {
            binding("TableView", $(".cc-details-table").first()).all({ sortkey: "", sortdir: "" });
});
</script>

</div>

<div class="addtowatchlist-section">

<div>
 <script type="text/javascript">
        require(["jquery","c.deferred"], function ($, settings)
        {
            $('.add-to-watchlist-container').css("visibility", "visible");
            $('#add-to-watchlist-outer-container').first().click('on', function () { window.location = $("#user-profile").find('a').first().attr('href'); });

        });
        </script>
 <button id="add-to-watchlist-outer-container" class="add-to-watchlist-container" style="visibility: visible;">
<span class="add-to-watchlist-notsigned">Lưu</span>
</button>
</div>
 </div>
<div class="cc-chart">
<div class="cc-chartheading-container">
<div><span id="cc-chartheading" aria-live="polite">USD / VND</span></div>
<div><span class="cc-oneyeartrend">Xu hướng 1 Năm</span></div>
                        </div>
                        <div class="currencies-chart" aria-live="polite">
 
<div class="instrumentation-wrapper" data-id="293" data-m="{&quot;i&quot;:293,&quot;p&quot;:32,&quot;n&quot;:&quot;herochart&quot;,&quot;t&quot;:&quot;FinanceChartServiceTask&quot;,&quot;o&quot;:2}" aria-label="Biểu đồ 1 năm dành cho USD / VND">
 
<div id="heropanechart" class="chartsection" aria-live="polite">
<a id="chartwrapper" class="chart-wrapper" tabindex="-1" aria-hidden="True">
<div id="C20824_innerContainer" class="innerChartContainer">
<canvas id="C1543_stockChartCanvas" width="285" height="118" class="chartCanvas" style="direction: ltr;"></canvas>
<canvas id="C98957_overlayCanvas" width="285" height="118" class="chartCanvas" style="direction: ltr;"></canvas>
<div class="chartError hide" style="color: rgb(168, 175, 184);">Dữ liệu không khả dụng</div>
<div class="chartSpinnerContainer hide"><progress class="chartSpinner win-ring"></progress></div>
</div></a>
</div>
<div id="heropanechart-mode-selector" class="modesection"></div>
<div id="colorconstants" style="display: none">
<span id="gaincolor" class="increase"></span>
<span id="losecolor" class="decrease"></span>
    </div>
    <script>
        require(["ChartRenderer", "utils", "viewAware"], function (chartRenderer, utils, viewAware) {
            var params = {
                containerId: "chartwrapper",
                chartType: "CurrencyChart",
isOtc: "False",
isEod: "False",
locale: "vi-VN",
symbol: "",
currencyString: "Đơn vị tiền tệ tính bằng {0}",
modeSelectorId: "heropanechart-mode-selector",
defaultFrom: "USD",
defaultTo: "VND",
                isImmersiveChart: false,
            };
            var chartType = "CurrencyChart";
            var symbol = utils.encodeSymbol(unescape(params.symbol));
            switch ("CurrencyChart") {
                case "StockDetails":
                    params.navigationUrl = "/vi-vn/money/stockdetails/charts" + "/fi-" + symbol;
                    break;
                case "IndexDetails":
                    params.navigationUrl = "/vi-vn/money/indexdetails/charts" + "/fi-" + symbol;
                    break;
                case "ETFDetails":
                    params.navigationUrl = "/vi-vn/money/etfdetails/charts" + "/fi-" + symbol;
                    break;
                case "FundDetails":
                    //params.navigationUrl = "/vi-vn/money/funddetails/charts" + "/fi-" + params.symbol;
                    //disabling till we enable immersive charts experience for funds.
                    break;
                case "MarketsPage":
                    params.navigationUrl = "/vi-vn/money/markets/charts";
                    break;
                case "skylineModuleChart":
                    params.navigationUrl = "/vi-vn/money/indexdetails" + "/fi-" + symbol;
                    break;
                default:
                    params.navigationUrl = "#";
                    break;
            }
            chartRenderer.initialize(params);
            var stringifiedResponse = jsonStrinigyWrapper([{"Ct":"1Y","Eeq":"Foreign Exchange Rates","EqTkr":"USDVND","Ert":"245","Et":"2020-12-09T00:00:00","Fi":"245.20.USDVNDLITE","SecType":"20","Series":[{"P":23170,"T":10487520,"V":0},{"P":23175,"T":1440,"V":0},{"P":23169,"T":2880,"V":0},{"P":23173,"T":4320,"V":0},{"P":23176,"T":8640,"V":0},{"P":23176,"T":10080,"V":0},{"P":23173,"T":11520,"V":0},{"P":23169,"T":12960,"V":0},{"P":23175,"T":14400,"V":0},{"P":23173,"T":18720,"V":0},{"P":23176,"T":20160,"V":0},{"P":23173,"T":21600,"V":0},{"P":23174,"T":23040,"V":0},{"P":23171,"T":24480,"V":0},{"P":23170,"T":28800,"V":0},{"P":23171,"T":30240,"V":0},{"P":23171,"T":31680,"V":0},{"P":23168,"T":33120,"V":0},{"P":23171,"T":34560,"V":0},{"P":23176,"T":38880,"V":0},{"P":23175,"T":40320,"V":0},{"P":23175,"T":41760,"V":0},{"P":23173,"T":43200,"V":0},{"P":23176,"T":44640,"V":0},{"P":23173,"T":48960,"V":0},{"P":23175,"T":50400,"V":0},{"P":23170,"T":51840,"V":0},{"P":23171,"T":53280,"V":0},{"P":23170,"T":54720,"V":0},{"P":23169,"T":59040,"V":0},{"P":23170,"T":60480,"V":0},{"P":23169,"T":61920,"V":0},{"P":23169,"T":63360,"V":0},{"P":23169,"T":64800,"V":0},{"P":23169,"T":69120,"V":0},{"P":23169,"T":70560,"V":0},{"P":23169,"T":72000,"V":0},{"P":23182,"T":73440,"V":0},{"P":23222,"T":74880,"V":0},{"P":23250,"T":79200,"V":0},{"P":23230,"T":80640,"V":0},{"P":23220,"T":82080,"V":0},{"P":23221,"T":83520,"V":0},{"P":23230,"T":84960,"V":0},{"P":23258,"T":89280,"V":0},{"P":23240,"T":90720,"V":0},{"P":23250,"T":92160,"V":0},{"P":23239,"T":93600,"V":0},{"P":23245,"T":95040,"V":0},{"P":23228,"T":99360,"V":0},{"P":23239,"T":100800,"V":0},{"P":23225,"T":102240,"V":0},{"P":23236,"T":103680,"V":0},{"P":23242,"T":105120,"V":0},{"P":23247,"T":109440,"V":0},{"P":23270,"T":110880,"V":0},{"P":23240,"T":112320,"V":0},{"P":23240,"T":113760,"V":0},{"P":23240,"T":115200,"V":0},{"P":23240,"T":119520,"V":0},{"P":23218,"T":120960,"V":0},{"P":23206,"T":122400,"V":0},{"P":23210,"T":123840,"V":0},{"P":23205,"T":125280,"V":0},{"P":23172,"T":129600,"V":0},{"P":23174,"T":131040,"V":0},{"P":23172,"T":132480,"V":0},{"P":23195,"T":133920,"V":0},{"P":23208,"T":135360,"V":0},{"P":23225,"T":139680,"V":0},{"P":23238,"T":141120,"V":0},{"P":23282,"T":142560,"V":0},{"P":23354,"T":144000,"V":0},{"P":23455,"T":145440,"V":0},{"P":23540,"T":149760,"V":0},{"P":23580,"T":151200,"V":0},{"P":23600,"T":152640,"V":0},{"P":23620,"T":154080,"V":0},{"P":23620,"T":155520,"V":0},{"P":23640,"T":159840,"V":0},{"P":23616,"T":161280,"V":0},{"P":23590,"T":162720,"V":0},{"P":23590,"T":164160,"V":0},{"P":23550,"T":165600,"V":0},{"P":23440,"T":169920,"V":0},{"P":23450,"T":171360,"V":0},{"P":23550,"T":172800,"V":0},{"P":23488,"T":174240,"V":0},{"P":23435,"T":175680,"V":0},{"P":23432,"T":180000,"V":0},{"P":23471,"T":181440,"V":0},{"P":23440,"T":182880,"V":0},{"P":23440,"T":184320,"V":0},{"P":23424,"T":185760,"V":0},{"P":23450,"T":190080,"V":0},{"P":23460,"T":191520,"V":0},{"P":23479,"T":192960,"V":0},{"P":23485,"T":194400,"V":0},{"P":23505,"T":195840,"V":0},{"P":23455,"T":200160,"V":0},{"P":23442,"T":201600,"V":0},{"P":23428,"T":203040,"V":0},{"P":23428,"T":204480,"V":0},{"P":23428,"T":205920,"V":0},{"P":23445,"T":210240,"V":0},{"P":23421,"T":211680,"V":0},{"P":23423,"T":213120,"V":0},{"P":23425,"T":214560,"V":0},{"P":23377,"T":216000,"V":0},{"P":23322,"T":220320,"V":0},{"P":23330,"T":221760,"V":0},{"P":23347,"T":223200,"V":0},{"P":23350,"T":224640,"V":0},{"P":23355,"T":226080,"V":0},{"P":23338,"T":230400,"V":0},{"P":23295,"T":231840,"V":0},{"P":23270,"T":233280,"V":0},{"P":23275,"T":234720,"V":0},{"P":23267,"T":236160,"V":0},{"P":23312,"T":240480,"V":0},{"P":23336,"T":241920,"V":0},{"P":23325,"T":243360,"V":0},{"P":23300,"T":244800,"V":0},{"P":23280,"T":246240,"V":0},{"P":23260,"T":250560,"V":0},{"P":23253,"T":252000,"V":0},{"P":23260,"T":253440,"V":0},{"P":23263,"T":254880,"V":0},{"P":23255,"T":256320,"V":0},{"P":23255,"T":260640,"V":0},{"P":23205,"T":262080,"V":0},{"P":23190,"T":263520,"V":0},{"P":23215,"T":264960,"V":0},{"P":23206,"T":266400,"V":0},{"P":23220,"T":270720,"V":0},{"P":23210,"T":272160,"V":0},{"P":23196,"T":273600,"V":0},{"P":23210,"T":275040,"V":0},{"P":23215,"T":276480,"V":0},{"P":23210,"T":280800,"V":0},{"P":23213,"T":282240,"V":0},{"P":23195,"T":283680,"V":0},{"P":23208,"T":285120,"V":0},{"P":23210,"T":286560,"V":0},{"P":23198,"T":290880,"V":0},{"P":23204,"T":292320,"V":0},{"P":23203,"T":293760,"V":0},{"P":23202,"T":295200,"V":0},{"P":23199,"T":296640,"V":0},{"P":23201,"T":300960,"V":0},{"P":23180,"T":302400,"V":0},{"P":23188,"T":303840,"V":0},{"P":23184,"T":305280,"V":0},{"P":23177,"T":306720,"V":0},{"P":23179,"T":311040,"V":0},{"P":23181,"T":312480,"V":0},{"P":23183,"T":313920,"V":0},{"P":23184,"T":315360,"V":0},{"P":23191,"T":316800,"V":0},{"P":23188,"T":321120,"V":0},{"P":23180,"T":322560,"V":0},{"P":23184,"T":324000,"V":0},{"P":23180,"T":325440,"V":0},{"P":23175,"T":326880,"V":0},{"P":23181,"T":331200,"V":0},{"P":23170,"T":332640,"V":0},{"P":23175,"T":334080,"V":0},{"P":23175,"T":335520,"V":0},{"P":23170,"T":336960,"V":0},{"P":23170,"T":341280,"V":0},{"P":23175,"T":342720,"V":0},{"P":23174,"T":344160,"V":0},{"P":23173,"T":345600,"V":0},{"P":23173,"T":347040,"V":0},{"P":23170,"T":351360,"V":0},{"P":23174,"T":352800,"V":0},{"P":23175,"T":354240,"V":0},{"P":23174,"T":355680,"V":0},{"P":23174,"T":357120,"V":0},{"P":23174,"T":361440,"V":0},{"P":23174,"T":362880,"V":0},{"P":23174,"T":364320,"V":0},{"P":23174,"T":365760,"V":0},{"P":23175,"T":367200,"V":0},{"P":23177,"T":371520,"V":0},{"P":23170,"T":372960,"V":0},{"P":23174,"T":374400,"V":0},{"P":23174,"T":375840,"V":0},{"P":23174,"T":377280,"V":0},{"P":23174,"T":381600,"V":0},{"P":23174,"T":383040,"V":0},{"P":23174,"T":384480,"V":0},{"P":23174,"T":385920,"V":0},{"P":23178,"T":387360,"V":0},{"P":23174,"T":391680,"V":0},{"P":23176,"T":393120,"V":0},{"P":23175,"T":394560,"V":0},{"P":23172.5,"T":396000,"V":0},{"P":23174,"T":397440,"V":0},{"P":23175,"T":401760,"V":0},{"P":23175,"T":403200,"V":0},{"P":23178,"T":404640,"V":0},{"P":23170,"T":406080,"V":0},{"P":23170,"T":407520,"V":0},{"P":23178,"T":411840,"V":0},{"P":23177,"T":413280,"V":0},{"P":23185,"T":414720,"V":0},{"P":23184,"T":416160,"V":0},{"P":23191,"T":417600,"V":0},{"P":23188,"T":421920,"V":0},{"P":23190,"T":423360,"V":0},{"P":23181,"T":424800,"V":0},{"P":23188,"T":426240,"V":0},{"P":23191,"T":427680,"V":0},{"P":23203,"T":432000,"V":0},{"P":23205,"T":433440,"V":0},{"P":23205,"T":434880,"V":0},{"P":23191,"T":436320,"V":0},{"P":23180,"T":437760,"V":0},{"P":23178,"T":442080,"V":0},{"P":23177,"T":443520,"V":0},{"P":23175,"T":444960,"V":0},{"P":23170,"T":446400,"V":0},{"P":23175,"T":447840,"V":0},{"P":23175,"T":452160,"V":0},{"P":23179,"T":453600,"V":0},{"P":23177,"T":455040,"V":0},{"P":23176,"T":456480,"V":0},{"P":23176,"T":457920,"V":0},{"P":23175,"T":462240,"V":0},{"P":23175,"T":463680,"V":0},{"P":23176,"T":465120,"V":0},{"P":23170,"T":466560,"V":0},{"P":23180,"T":468000,"V":0},{"P":23177,"T":472320,"V":0},{"P":23176,"T":473760,"V":0},{"P":23176,"T":475200,"V":0},{"P":23175,"T":476640,"V":0},{"P":23176,"T":478080,"V":0},{"P":23170,"T":482400,"V":0},{"P":23173,"T":483840,"V":0},{"P":23175,"T":485280,"V":0},{"P":23175,"T":486720,"V":0},{"P":23175,"T":488160,"V":0},{"P":23175,"T":492480,"V":0},{"P":23163,"T":493920,"V":0},{"P":23160,"T":495360,"V":0},{"P":23176,"T":496800,"V":0},{"P":23176,"T":498240,"V":0},{"P":23177,"T":502560,"V":0},{"P":23151,"T":504000,"V":0},{"P":23160,"T":505440,"V":0},{"P":23164,"T":506880,"V":0},{"P":23160,"T":508320,"V":0},{"P":23140,"T":512640,"V":0},{"P":23129,"T":514080,"V":0},{"P":23129,"T":515520,"V":0},{"P":23125,"T":516960,"V":0},{"P":23130,"T":518400,"V":0},{"P":23127,"T":522720,"V":0},{"P":23128,"T":524160,"V":0},{"P":23128,"T":525600,"V":0}],"St":"2019-12-10T00:00:00","Tkr":"USDVND","Ycp":23128}]);
            if (stringifiedResponse.length) {
                var jsonResponse = JSON.parse(stringifiedResponse);
                chartRenderer.renderChart(jsonResponse);
                setAriaLabelForChart(jsonResponse);
                require(["c.pdpready"], function () {
                    // only for hubpage stripe
                    if ("False" == "True") {
                        chartRenderer.renderChart(JSON.parse(stringifiedResponse));
                    }
                });
            }
            else {
                // deferring chart rendering as data is not available and needs to make an ajax call
                require(["c.deferred"], function () {
                    chartRenderer.renderChart();
                });
            }

            require(["c.deferred"], function () {
                if (params.navigationUrl) {
                    var linkElement = document.getElementById("chartwrapper");
                    if (linkElement) {
                        viewAware.listen(function (mode) {
                            if (chartType == "StockDetails" || chartType == "IndexDetails" || chartType == "ETFDetails")
                            {
                                if (mode & viewAware.views.SIZE4COLUMN)
                                {
                                    linkElement.setAttribute("href", "#");
                                    chartRenderer.addChartClickHandler(linkElement);
                                } else
                                {
                                    linkElement.removeAttribute("href");
                                    chartRenderer.removeClickHandler(linkElement);
                                }
                            }
                            else
                            {
                                if (mode & viewAware.views.SIZE4COLUMN & params.navigationUrl != "#") {
                                    linkElement.href = params.navigationUrl;
                                } else {
                                    linkElement.removeAttribute("href");
                                }
                            }

                        });
                    }
                    var compareStockElement = document.getElementById("compare-stock-outer-container");
                    if (compareStockElement)
                    {
                        viewAware.listen(function(mode)
                        {
                            if (chartType == "StockDetails" || chartType == "IndexDetails" || chartType == "ETFDetails")
                            {
                                if (mode & viewAware.views.SIZE4COLUMN)
                                {
                                    compareStockElement.setAttribute("href", "#");
                                    if (!window.IsCompareClick){
                                        chartRenderer.addCompareChartClickHandler(compareStockElement);
                                        window.IsCompareClick = true;
                                    }
                                } else
                                {
                                    compareStockElement.removeAttribute("href");
                                    chartRenderer.removeClickHandler(compareStockElement);
                                }
                            } else
                            {
                                if (mode & viewAware.views.SIZE4COLUMN & params.navigationUrl != "#")
                                {
                                    compareStockElement.href = params.navigationUrl;
                                } else
                                {
                                    compareStockElement.removeAttribute("href");
                                }
                            }
                        });
                    }
                }
            });

            function jsonStrinigyWrapper(data) {
                if (data == undefined) {
                    return '';
                }
                else {
                    return JSON.stringify(data);
                }

                return '';
            }

            function setAriaLabelForChart(jsonData) {
                var ChartWrapperElement = document.getElementsByClassName("instrumentation-wrapper");
                if (jsonData.length&&ChartWrapperElement.length) {
                    var labelString = "Chart";
                    switch ("CurrencyChart")
                    {
                        case "CurrencyChart":
                            return; // prevent overriding aria-label
                        case "MarketsPage":
                            var indices = "";
                            for (i = 0; i < jsonData.length; i++) {
                                if (i < jsonData.length - 1) {
                                    indices += "{0}, ".format(jsonData[i].Quotes.Cmp);
                                }
                                else {
                                    indices += "and {0}".format(jsonData[i].Quotes.Cmp);
                                }
                            }
                            labelString = "Comparison Chart for {0}".format(indices);
                            break;
                        case "CommodityDetails":
                            labelString = "CurrencyChart" + " Chart For {0}".format(jsonData[0].Quotes.Dn);
                            break;
                        case "StockDetails":
                        case "IndexDetails":
                        case "ETFDetails":
                            labelString = "CurrencyChart" + " Chart For {0}".format(jsonData[0].Quotes.Cmp);
                            break;

                    }
                    ChartWrapperElement[0].setAttribute("aria-label", labelString);
                }
            }
        });
    </script>
 
</div>

                        </div>
                    </div>
                </div>
                <div class="clearfix">
</div>
</div>

<div class="finance-strip1">
<div class="newscontainer">


<script>
    require(["MajorCurrencies", "c.deferred"], function (majorCurrencies) {
        majorCurrencies.renderFlags();
    });
</script>

<div class="newscontainer">
<div class="mjrcurrncsitem" tabindex="0" title="Các đơn vị tiền tệ Chính" data-id="294" data-m="{&quot;i&quot;:294,&quot;p&quot;:32,&quot;n&quot;:&quot;majorcurrenciesmodule&quot;,&quot;t&quot;:&quot;MajorCurrenciesServiceModule&quot;,&quot;o&quot;:3}">
 <div class="mjrcurrncsrow tblheaderrow">
<span class="mjrcurrncsheading mctblheading"><p class="truncated-string" title="Các đơn vị tiền tệ Chính">Các đơn vị tiền tệ Chính</p></span>
<span class="pricecol mctblheading"><p class="truncated-string" title="Giá">Giá</p></span>
<span class="chngcol mctblheading"><p class="truncated-string" title="Thay đổi">Thay đổi</p></span>
<span class="chpcol mctblheading"><p class="truncated-string" title="Thay đổi%">Thay đổi%</p></span>
<span class="rng52wkcol mctblheading"><p class="truncated-string" title="52 Tuần Cao">52 Tuần Cao</p></span>
<span class="rng52wkcol mctblheading"><p class="truncated-string" title="52 Tuần Thấp">52 Tuần Thấp</p></span>
</div>
 <div class="mjrcurrncsrow mjcurrncs-data">

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="USA" style="background-size: 864rem 5.3rem; background-position: -747rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Đô la của Hoa Kỳ">Đồng Đô la của Hoa Kỳ</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="USD/VND">USD/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="23.128,0000" aria-label="Giá 23.128,0000">23.128,0000</p></span>

<div class="chcpclub">
<span class="chngcol chng-value unchanged"><p class="truncated-string" title="0,0000" aria-label="Thay đổi 0,0000">0,0000</p></span>
<span class="chpcol chp-value unchanged"><p class="truncated-string" title="0,0000%" aria-label="Thay đổi% 0,0000%">0,0000%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="23.650,0000" aria-label="52 Tuần Cao 23.650,0000">23.650,0000</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="23.119,0000" aria-label="52 Tuần Thấp 23.119,0000">23.119,0000</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="JPN" style="background-size: 864rem 5.3rem; background-position: -339rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Yên Nhật">Đồng Yên Nhật</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="JPY/VND">JPY/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="221,3800" aria-label="Giá 221,3800">221,3800</p></span>

<div class="chcpclub">
<span class="chngcol chng-value decrease"><p class="truncated-string" title="-0,4900" aria-label="Thay đổi -0,4900">-0,4900</p></span>
<span class="chpcol chp-value decrease"><p class="truncated-string" title="-0,2209%" aria-label="Thay đổi% -0,2209%">-0,2209%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="228,9700" aria-label="52 Tuần Cao 228,9700">228,9700</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="207,0200" aria-label="52 Tuần Thấp 207,0200">207,0200</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="CHN" style="background-size: 864rem 5.3rem; background-position: -165rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Yuan của Trung Quốc (RMB)">Đồng Yuan của Trung Quốc (RMB)</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="CNY/VND">CNY/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="3.534,0700" aria-label="Giá 3.534,0700">3.534,0700</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+0,9200" aria-label="Thay đổi +0,9200">+0,9200</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,0260%" aria-label="Thay đổi% +0,0260%">+0,0260%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="3.546,7000" aria-label="52 Tuần Cao 3.546,7000">3.546,7000</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="3.245,8800" aria-label="52 Tuần Thấp 3.245,8800">3.245,8800</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="EUR" style="background-size: 864rem 5.3rem; background-position: -237rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Euro">Euro</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="EUR/VND">EUR/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="28.008,0100" aria-label="Giá 28.008,0100">28.008,0100</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+69,3900" aria-label="Thay đổi +69,3900">+69,3900</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,2484%" aria-label="Thay đổi% +0,2484%">+0,2484%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="28.165,4000" aria-label="52 Tuần Cao 28.165,4000">28.165,4000</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="24.874,3500" aria-label="52 Tuần Thấp 24.874,3500">24.874,3500</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="GBR" style="background-size: 864rem 5.3rem; background-position: -741rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng bảng Anh">Đồng bảng Anh</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="GBP/VND">GBP/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="30.746,0000" aria-label="Giá 30.746,0000">30.746,0000</p></span>

<div class="chcpclub">
<span class="chngcol chng-value decrease"><p class="truncated-string" title="-236,0000" aria-label="Thay đổi -236,0000">-236,0000</p></span>
<span class="chpcol chp-value decrease"><p class="truncated-string" title="-0,7617%" aria-label="Thay đổi% -0,7617%">-0,7617%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="31.316,0000" aria-label="52 Tuần Cao 31.316,0000">31.316,0000</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="26.633,0000" aria-label="52 Tuần Thấp 26.633,0000">26.633,0000</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="CAN" style="background-size: 864rem 5.3rem; background-position: -141rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Đô la của Canada">Đồng Đô la của Canada</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="CAD/VND">CAD/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="18.126,8100" aria-label="Giá 18.126,8100">18.126,8100</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+83,4300" aria-label="Thay đổi +83,4300">+83,4300</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,4624%" aria-label="Thay đổi% +0,4624%">+0,4624%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="18.126,8100" aria-label="52 Tuần Cao 18.126,8100">18.126,8100</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="15.848,6700" aria-label="52 Tuần Thấp 15.848,6700">15.848,6700</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="CHE" style="background-size: 864rem 5.3rem; background-position: -675rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Franc của Thụy sĩ">Đồng Franc của Thụy sĩ</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="CHF/VND">CHF/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="26.045,0500" aria-label="Giá 26.045,0500">26.045,0500</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+38,0800" aria-label="Thay đổi +38,0800">+38,0800</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,1464%" aria-label="Thay đổi% +0,1464%">+0,1464%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="26.052,7200" aria-label="52 Tuần Cao 26.052,7200">26.052,7200</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="23.361,9000" aria-label="52 Tuần Thấp 23.361,9000">23.361,9000</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="AUS" style="background-size: 864rem 5.3rem; background-position: -39rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Đô la của Úc">Đồng Đô la của Úc</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="AUD/VND">AUD/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="17.334,4400" aria-label="Giá 17.334,4400">17.334,4400</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+115,6400" aria-label="Thay đổi +115,6400">+115,6400</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,6716%" aria-label="Thay đổi% +0,6716%">+0,6716%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="17.334,4400" aria-label="52 Tuần Cao 17.334,4400">17.334,4400</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="12.823,4700" aria-label="52 Tuần Thấp 12.823,4700">12.823,4700</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="HKG" style="background-size: 864rem 5.3rem; background-position: -291rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Đô la của Hồng Kông">Đồng Đô la của Hồng Kông</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="HKD/VND">HKD/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="2.983,7600" aria-label="Giá 2.983,7600">2.983,7600</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+0,1200" aria-label="Thay đổi +0,1200">+0,1200</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,0040%" aria-label="Thay đổi% +0,0040%">+0,0040%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="3.049,4500" aria-label="52 Tuần Cao 3.049,4500">3.049,4500</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="2.958,1800" aria-label="52 Tuần Thấp 2.958,1800">2.958,1800</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="SGP" style="background-size: 864rem 5.3rem; background-position: -639rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Đô la của Singapore">Đồng Đô la của Singapore</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="SGD/VND">SGD/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="17.288,0000" aria-label="Giá 17.288,0000">17.288,0000</p></span>

<div class="chcpclub">
<span class="chngcol chng-value decrease"><p class="truncated-string" title="-4,0000" aria-label="Thay đổi -4,0000">-4,0000</p></span>
<span class="chpcol chp-value decrease"><p class="truncated-string" title="-0,0231%" aria-label="Thay đổi% -0,0231%">-0,0231%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="17.374,0000" aria-label="52 Tuần Cao 17.374,0000">17.374,0000</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="15.982,0000" aria-label="52 Tuần Thấp 15.982,0000">15.982,0000</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="MYS" style="background-size: 864rem 5.3rem; background-position: -441rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Ringgit của Malaysia">Đồng Ringgit của Malaysia</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="MYR/VND">MYR/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="5.693,7500" aria-label="Giá 5.693,7500">5.693,7500</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+4,2100" aria-label="Thay đổi +4,2100">+4,2100</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,0740%" aria-label="Thay đổi% +0,0740%">+0,0740%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="5.759,5100" aria-label="52 Tuần Cao 5.759,5100">5.759,5100</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="5.276,9600" aria-label="52 Tuần Thấp 5.276,9600">5.276,9600</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="IDN" style="background-size: 864rem 5.3rem; background-position: -315rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Rupia của Indonesia">Đồng Rupia của Indonesia</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="IDR/VND">IDR/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="1,6380" aria-label="Giá 1,6380">1,6380</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+0,0024" aria-label="Thay đổi +0,0024">+0,0024</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,1467%" aria-label="Thay đổi% +0,1467%">+0,1467%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="1,7067" aria-label="52 Tuần Cao 1,7067">1,7067</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="1,4120" aria-label="52 Tuần Thấp 1,4120">1,4120</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="THA" style="background-size: 864rem 5.3rem; background-position: -693rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Baht của Thái Lan">Đồng Baht của Thái Lan</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="THB/VND">THB/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="769,1400" aria-label="Giá 769,1400">769,1400</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+0,7700" aria-label="Thay đổi +0,7700">+0,7700</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,1002%" aria-label="Thay đổi% +0,1002%">+0,1002%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="778,6000" aria-label="52 Tuần Cao 778,6000">778,6000</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="709,9200" aria-label="52 Tuần Thấp 709,9200">709,9200</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="PHL" style="background-size: 864rem 5.3rem; background-position: -567rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Peso của Philippine">Đồng Peso của Philippine</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="PHP/VND">PHP/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="480,4920" aria-label="Giá 480,4920">480,4920</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+0,6580" aria-label="Thay đổi +0,6580">+0,6580</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,1371%" aria-label="Thay đổi% +0,1371%">+0,1371%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="482,1555" aria-label="52 Tuần Cao 482,1555">482,1555</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="445,5521" aria-label="52 Tuần Thấp 445,5521">445,5521</p></span>
</div>

<div class="mcrow">
<span class="flagcol" aria-hidden="True"><span class="cntryflag hasflag" id="MMR" style="background-size: 864rem 5.3rem; background-position: -489rem -1rem;">&nbsp;</span></span>
<div class="cntrycnvrsn">
<span class="cntrycol"><p class="truncated-string" title="Đồng Kyat của Myanmar">Đồng Kyat của Myanmar</p></span>
<span class="cnvrsncol"><p class="truncated-string" title="MMK/VND">MMK/VND</p></span>
</div>
<span class="pricecol"><p class="truncated-string" title="17,4400" aria-label="Giá 17,4400">17,4400</p></span>

<div class="chcpclub">
<span class="chngcol chng-value increase"><p class="truncated-string" title="+0,1300" aria-label="Thay đổi +0,1300">+0,1300</p></span>
<span class="chpcol chp-value increase"><p class="truncated-string" title="+0,7510%" aria-label="Thay đổi% +0,7510%">+0,7510%</p></span>
</div>
<span class="rng52wkcol"><p class="truncated-string" title="18,1000" aria-label="52 Tuần Cao 18,1000">18,1000</p></span>
<span class="rng52wkcol"><p class="truncated-string" title="15,2900" aria-label="52 Tuần Thấp 15,2900">15,2900</p></span>
</div>

</div>

</div>
</div>

<div class="ad" id="currncs-ad">
 <div tabindex="-1" id="rectangle1_data_financecurrencyconverter_3597d378-d8c3-492e-bbbc-d025fa1723a3" class="ad" data-aop="admodule_ad" data-id="295" data-m="{&quot;i&quot;:295,&quot;p&quot;:32,&quot;n&quot;:&quot;admodule&quot;,&quot;t&quot;:&quot;ad&quot;,&quot;o&quot;:4}" aria-hidden="true">
 
 
<div class="outeradcontainer">
 
<div id="rectangle1_data_financecurrencyconverter_container_3597d378-d8c3-492e-bbbc-d025fa1723a3" class="adcontainer" data-params="" data-width="300" data-height="600" data-options="" data-adjs="{&quot;allowedViews&quot;:&quot;SIZE234COLUMN&quot;}" tabindex="-1">
 <script class="sdkdapscript">
require(["dap"], function (dap)
{
 dap("&amp;AP=1089&amp;PG=FINVNVI11&amp;PVGUID=39f31a574880406c91fe78e6f524d229&amp;PROVIDERID=7HD66FC", 300, 600, "rectangle1_data_financecurrencyconverter_container_3597d378-d8c3-492e-bbbc-d025fa1723a3", {"isEnabled":0, "isDarkTheme":0}, {"scrollInit":true,"enableAdRefresh":true,"adaptiveRefresh":true,"adaptiveRefreshInterval":1000,"prid":"7HD66FC","adsVNextHeight":"RR","adsVNextWidth":"RR","rid":"39f31a574880406c91fe78e6f524d229","adtext":"","showmute":false,"showvolume":false,"nonviewablebehavior":"","showprogressbar":false,"allowfullscreen":false,"videothreshold":1,"videooffset":5,"skiplocation":"","skiptext":"","skipbuttontext":"","playOnMouseover":false,"audioOnMouseover":"false","playVideoVisibleThreshold":50,"disableTopBar":false,"preShowType":"none","preShowUrl":"","postShowType":"","postShowUrl":"","postShowClickUrl":"","fallbackType":"","fallbackUrl":"","fallbackClickUrl":"","vpaidTimeout":5000,"terminateUnresponsiveVPAIDCreative":false,"enableInlineVideoForIos":false,"delayExpandUntilVPAIDInit":false,"delayExpandUntilVPAIDImpression":false,"apnId":280});
                                });
                            </script>
 </div>
 
</div>
 
</div>
 </div>
 <div class="clearfix">
</div>
 </div>
    <script>
        require(["jquery", "c.deferred"], function ($) {
            $.ajax({
                url: "/vi-vn/money/footer/commonfooter/fi-",
                cache: false,
                success: function (html) {
                    $("#finance-footer").append(html);
                    callback();
                }
            });
        });

        var callback = function()
        {
            require(["FinanceFooter"], function(footer)
            {
                footer.init();
            });
        };
    </script>
 <div class="finance-footer-container">

</div>


   </div></div></main>
 </div>
</div>

    <div id="prefooter" data-region="prefooter" data-id="296" data-m="{&quot;i&quot;:296,&quot;n&quot;:&quot;prefooter&quot;,&quot;y&quot;:6}">
        

            <a class="floatingfeedback" href="#" data-id="297" data-m="{&quot;i&quot;:297,&quot;p&quot;:296,&quot;n&quot;:&quot;feedbackLink&quot;,&quot;y&quot;:12,&quot;o&quot;:1}" data-aop="floatingfeedbacklink">Phản hồi</a>


        
        
    </div>
        


        <div id="feedback-flyout" data-aop="feedback_flyout">
             <button id="feedback-close" title="đóng" data-id="311" data-m="{&quot;i&quot;:311,&quot;n&quot;:&quot;feedback&quot;,&quot;y&quot;:11,&quot;l&quot;:&quot;close&quot;}"></button>
 <div class="feedbackheader mainheader">
<h2>Gửi Phản hồi MSN</h2>
</div>
 <div class="feedbackheader thankyou">
<h2>Chúng tôi đánh giá cao ý kiến của bạn!</h2>
</div>
 <div id="feedback-feedbackarea">
<div class="feedbackarea">
<label for="feedback-inputbox">Chúng tôi có thể cải thiện như thế nào?</label>
<textarea id="feedback-inputbox" maxlength="400" placeholder="Nhập phản hồi của bạn vào đây. Để giúp bảo mật cho bạn, không đưa thông tin cá nhân, chẳng hạn như tên hoặc địa chỉ của bạn." aria-live="assertive"></textarea>
</div>
</div>
 <div id="feedback-starrating">
  <div class="stars">
<p>Vui lòng đưa ra xếp hạng trang tổng thể:</p>
<ul data-selected="0" aria-label="Vui lòng đưa ra xếp hạng trang tổng thể:" role="radiogroup">
 <li tabindex="0" class="sensoryStars" aria-label="Xếp hạng sao 1 / 5" role="radio" aria-checked="false"></li>
 <li tabindex="0" class="sensoryStars" aria-label="Xếp hạng sao 2 / 5" role="radio" aria-checked="false"></li>
 <li tabindex="0" class="sensoryStars" aria-label="Xếp hạng sao 3 / 5" role="radio" aria-checked="false"></li>
 <li tabindex="0" class="sensoryStars" aria-label="Xếp hạng sao 4 / 5" role="radio" aria-checked="false"></li>
 <li tabindex="0" class="sensoryStars" aria-label="Xếp hạng sao 5 / 5" role="radio" aria-checked="false"></li>
 </ul>
</div>
 </div>
 <button id="feedback-submit" class="footerbutton" title="gửi" data-id="312" data-m="{&quot;i&quot;:312,&quot;n&quot;:&quot;feedback&quot;,&quot;y&quot;:11,&quot;l&quot;:&quot;submit&quot;}">Gửi</button>
 <button id="feedback-ok" class="footerbutton" title="đóng" data-id="313" data-m="{&quot;i&quot;:313,&quot;n&quot;:&quot;feedback&quot;,&quot;y&quot;:11,&quot;l&quot;:&quot;ok&quot;}">Đóng</button>
 <div class="feedbackfooter">
 <div id="feedback-privacy-link">
<a href="https://go.microsoft.com/fwlink/?LinkId=521839" class="footerlink" target="_blank" data-id="314" data-m="{&quot;i&quot;:314,&quot;n&quot;:&quot;feedback&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;feedbackPrivacyLink&quot;}">Tuyên bố về Quyền riêng tư</a>
</div>
  <div id="feedback-help-link">
<a href="https://support.microsoft.com/kb/2999547/" class="footerlink" target="_blank" data-id="315" data-m="{&quot;i&quot;:315,&quot;n&quot;:&quot;feedback&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;feedbackHelpLink&quot;}">Trợ giúp</a>
</div>
  <div id="feedback-help-support-link">
<a href="https://support.microsoft.com/product/msn/msn" class="footerlink" target="_blank" data-id="316" data-m="{&quot;i&quot;:316,&quot;n&quot;:&quot;feedback&quot;,&quot;y&quot;:14,&quot;l&quot;:&quot;feedbackHelpSupportLink&quot;}">Trợ giúp &amp; Hỗ trợ</a>
</div>
  </div>

        </div>
<script>require(["imageLoad","perfMarker","perfMeasure"],function(n){n.cleanup()});require(["trackInfo","window","c.onload","c.ttvr","c.ttvr"],function(n,t){function c(){var r=n.sitePage,i,l,e;r.requestId?(i=o.setupParameters("load_time"),i&&(i.mkt=r.localeCode,i.subcvs=r.vertical,i.flightid=r.flightid,i.cu=n.client?encodeURIComponent(n.client.pageUrl()):r.pageUrl,i.pp=n.userStatic?n.userStatic.isSignedIn:"",i["d.dgk"]=r.d_dgk,r.feedId&&(i.fid=r.feedId),i.timeToOnload=u,i.timeToDomComplete=s,i.timeToFirstByte=h,l=t._pageTimings||(t._pageTimings={}),e=Object.keys(l).length?l:0,e&&e.TTVR&&e.TTVR>0&&(i.markers=e),f&&(i.timeToFirstSearchRendered=f),t.performance&&t.performance.navigation&&t.performance.navigation.type&&(i.navType=t.performance.navigation.type),o.sendUpdate(i))):t.setTimeout(c,500)}var o=n.telemetryTracking,u,s,h,f,i=(t.performance||{}).timing,r,e;i&&(u=i.loadEventStart-i.navigationStart,s=i.domComplete-i.navigationStart,h=i.responseStart-i.navigationStart,t.performance&&(r=t.performance.getEntriesByName("TimeToFirstSearchRendered","mark"),r&&(e=r.length,e&&e>0&&(f=Math.round(r[0].startTime)))),u&&c())});window._perfMarker&&window._perfMarker("TimeTocDom",!0);window._perfMeasure&&window._perfMeasure("TimeForcDom","TimeToHeadStart","TimeTocDom",!0);define("c.dom",1);window.onload=function(n){function r(){clearTimeout(t);t=0;window._perfMarker&&window._perfMarker("TimeTocDeferred");window._perfMeasure&&window._perfMeasure("TimeForcDeferred","TimeTocOnload","TimeTocDeferred");define("c.deferred",1);require(["c.deferred"],function(){i=setTimeout(f,u)})}function f(){clearTimeout(i);i=0;window._perfMarker&&window._perfMarker("TimeTocPostDeferred");window._perfMeasure&&window._perfMeasure("TimeForcPostdeferred","TimeTocDeferred","TimeTocPostDeferred");define("c.postdeferred",1)}var t,i,u=2e3;return function(n){var i;n&&(i=(window.JSON&&window.JSON.parse(n)||{}).dms,u=(window.JSON&&window.JSON.parse(n)||{}).ps);t=setTimeout(r,i||3e3)}(document.getElementsByTagName("head")[0].getAttribute("data-js")),function(i){typeof n=="function"&&n(i);window._perfMarker&&window._perfMarker("TimeTocOnload",!0);window._perfMeasure&&window._perfMeasure("TimeForcOnload","TimeTocDom","TimeTocOnload",!0);define("c.onload",1);t&&(window.setImmediate?setImmediate(r):setTimeout(r,0))}}(window.onload)</script><script>define("trackingConstants",{trackingData: {lastIndex: 316 } });</script>    <div hidden="">
        <span id="a11y0">Opens in a new window</span>
        <span id="a11y1">Opens an external site</span>
        <span id="a11y2">Opens an external site in a new window</span>
    </div>
        <script>window._perfMarker && window._perfMarker("TimeToBodyEnd");window._perfMeasure && window._perfMeasure("TimeForBody","TimeToBodyStart","TimeToBodyEnd",true);</script>

        <!--MSNAvailToken-->
    
<iframe src="//ib.adnxs.com/async_usersync_file" width="0" height="0" style="position:absolute;overflow:hidden;clip:rect(0 0 0 0);margin:0;padding:0;border:0;"></iframe></body></html>